# Autonomous intelligence workspace contract

Authority: [Autonomous Intelligence Canon](../product/AUTONOMOUS_INTELLIGENCE_CANON.md) and compatible [UI canon](UI_CANON.md). Earlier manual-pursuit interaction requirements are [archived](../../.agent/archive/AUTONOMOUS-20261026/README.md).

Opportunities presents the dense company/project table and selected intelligence detail. Horizontal navigation exposes Opportunities, automated Research and emerging Signals, plus search and account controls. Operations and source administration belong to internal diagnostics. Search must find supported companies, physical projects, contacts and intelligence with authenticated, region-eligible results. Tier, commercial disposition, numerical priority and evidence confidence remain distinct.

Each opportunity exposes company/project, physical location, power activity and supported load, plausible residual gap, need/start and duration, priority reasons, buyer/role and verified public business email/phone where available, explanation, original sources and dates, freshness and explicit unknowns. Prefer supported owner/developer identity over contractor headlines; retain contractor relationships. Generic business contact details must not imply a named buyer or delivery verification.

Research is a read-only account of autonomous investigation, questions, source-backed findings, unresolved evidence and job freshness. No trigger form, arbitrary question editor, owner review, correction or watch-maintenance flow is required to obtain routine intelligence. The pipeline schedules work independently of a user's page visit.

Evidence, buying chain, power analysis, timing, research gaps and retained audit history remain inspectable. Remove call logs, notes, operator statuses, fact drafting/correction, qualification controls and administrative pursuit logging, including their client helpers and public mutation routes. Historical facts and decisions remain attributed backend evidence. Do not replace removed workflows with renamed buttons or tabs.

Preserve URL/reload/Back/Forward state, server-cohort search/filter/sort/pagination, stale-response protection, labels, visible focus and keyboard controls. Desktop retains the dense table/detail composition. Narrow screens use readable list/detail reflow, visible contact and source actions and no horizontal overflow or permanent side rail. Loading, empty, error, stale and unknown states remain explicit. Facility totals are never temporary-power gaps; screenshots and fixtures never become production data.
