# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> grouped permit members use company-first titles while retaining each permit record
- Location: tests\project_cards.spec.ts:1415:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified', level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified', level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified', level: 1 })

```

# Test source

```ts
  1347 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1348 |       if (offset > 0) {
  1349 |         await route.fulfill({ status: 503, json: { detail: 'Later page unavailable for transition test' } })
  1350 |         return
  1351 |       }
  1352 |       const payload = serverOpportunityPage([firstPageRecord])
  1353 |       await route.fulfill({
  1354 |         status: 200,
  1355 |         contentType: 'application/json',
  1356 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25', 'X-Cohort-Token': 'transition-next-error-token' },
  1357 |         body: JSON.stringify(payload.items),
  1358 |       })
  1359 |       return
  1360 |     }
  1361 |     const path = url.pathname
  1362 |     const body = path === '/api/auth/session'
  1363 |       ? { authenticated: true }
  1364 |       : path === '/api/health'
  1365 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1366 |         : []
  1367 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1368 |   })
  1369 |   await page.goto('/?tier=Signals')
  1370 |   await expect(page.locator('[data-opportunity-id="transition-error-first-page"]')).toBeVisible()
  1371 |   await page.getByRole('button', { name: 'Next →' }).click()
  1372 |   await expect(page.getByRole('alert')).toContainText('503')
  1373 |   await expect(page.locator('[data-opportunity-id="transition-error-first-page"]')).toHaveCount(0)
  1374 |   await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  1375 |   await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  1376 |   await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  1377 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  1378 | })
  1379 | 
  1380 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  1381 |   const record = permit('roles', 'Facility construction', {
  1382 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  1383 |   })
  1384 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  1385 |   record.evidence[0].assessment_current = false
  1386 |   expect(projectTitle(record)).not.toContain('Owner Company')
  1387 | })
  1388 | 
  1389 | test('city permit company title shows source role and does not infer ownership', () => {
  1390 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  1391 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  1392 |   })
  1393 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  1394 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  1395 | 
  1396 |   const houston = permit('houston-1', 'Commercial facility construction')
  1397 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  1398 |   houston.title_company_role = 'permit-listed owner / occupant'
  1399 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  1400 | })
  1401 | 
  1402 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  1403 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  1404 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  1405 |   })
  1406 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  1407 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  1408 | 
  1409 |   const houston = permit('houston-1', 'Commercial facility construction')
  1410 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  1411 |   houston.title_company_role = 'permit-listed owner / occupant'
  1412 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  1413 | })
  1414 | 
  1415 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  1416 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  1417 |     projectId: 'dallas-campus',
  1418 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  1419 |   })
  1420 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  1421 |     projectId: 'dallas-campus',
  1422 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  1423 |   })
  1424 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  1425 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  1426 |   const records = [keeter, merichem]
  1427 |   await page.route(apiRoute, async (route) => {
  1428 |     const path = new URL(route.request().url()).pathname
  1429 |     if (path === '/api/opportunities') {
  1430 |       await fulfillServerOpportunityPage(route, records)
  1431 |       return
  1432 |     }
  1433 |     const body = path === '/api/auth/session'
  1434 |       ? { authenticated: true }
  1435 |       : path === '/api/health'
  1436 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1437 |           : []
  1438 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1439 |   })
  1440 |   await page.goto('/?tier=Signals')
  1441 |   await page.getByRole('button', { name: /KEETER INVESTMENTS LLC · LP Business Name · role unverified/ }).click()
  1442 |   const keeterMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000129"]')
  1443 |   const merichemMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000130"]')
  1444 |   await expect(keeterMember).toContainText('KEETER INVESTMENTS LLC · LP Business Name · role unverified')
  1445 |   await expect(merichemMember).toContainText('MERICHEM TECHNOLOGIES LLC · owner')
  1446 |   await keeterMember.click()
> 1447 |   await expect(page.getByRole('heading', { level: 1, name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified' })).toBeVisible()
       |                                                                                                                              ^ Error: expect(locator).toBeVisible() failed
  1448 |   await expect(page.getByText('COM-NEW-26-000129', { exact: false }).first()).toBeVisible()
  1449 | })
  1450 | 
  1451 | test('Signals default to All and keep SHOW, REVIEW, and HOLD selectable', async ({ page }) => {
  1452 |   let records = [
  1453 |     permit('hold-member', 'Routine hospital maintenance', { projectId: 'shared-project', decision: 'HOLD' }),
  1454 |     permit('show-member', 'New data center electrical buildout', { projectId: 'shared-project', decision: 'SHOW' }),
  1455 |     permit('review', 'Possible industrial expansion', { projectId: 'review-project', decision: 'REVIEW' }),
  1456 |     permit('hold', 'Marathon temporary stage', { projectId: 'hold-project', decision: 'HOLD' }),
  1457 |     permit('unknown', 'Unadjudicated project', { projectId: 'unknown-project', decision: null }),
  1458 |   ]
  1459 |   await page.route(apiRoute, async (route) => {
  1460 |     const path = new URL(route.request().url()).pathname
  1461 |     if (path === '/api/opportunities') {
  1462 |       await fulfillServerOpportunityPage(route, records)
  1463 |       return
  1464 |     }
  1465 |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  1466 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1467 |   })
  1468 |   await page.goto('/?tier=Signals')
  1469 |   await expect(page.getByRole('button', { name: 'All 4' })).toHaveAttribute('aria-pressed', 'true')
  1470 |   await expect(page.getByRole('button', { name: /Possible Industrial Expansion/ })).toBeVisible()
  1471 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
  1472 |   await page.getByRole('button', { name: 'SHOW 1' }).click()
  1473 |   const sharedProject = page.getByRole('button', { name: /New Data Center Electrical Buildout/ })
  1474 |   await expect(sharedProject).toBeVisible()
  1475 |   await sharedProject.click()
  1476 |   const holdMember = page.locator('.project-member[data-opportunity-id="hold-member"]')
  1477 |   const showMember = page.locator('.project-member[data-opportunity-id="show-member"]')
  1478 |   await expect(holdMember).toBeVisible()
  1479 |   await expect(showMember).toBeVisible()
  1480 |   await expect(holdMember).toContainText(projectTitle(records[0]))
  1481 |   await expect(showMember).toContainText(projectTitle(records[1]))
  1482 |   const groupedMemberIds = await page.locator('.project-member').evaluateAll((members) => members.map((member) => member.getAttribute('data-opportunity-id')))
  1483 |   expect(groupedMemberIds.slice(0, 2)).toEqual(['hold-member', 'show-member'])
  1484 |   await page.getByRole('button', { name: 'REVIEW 2' }).click()
  1485 |   await expect(page.getByRole('button', { name: /Possible Industrial Expansion/ })).toBeVisible()
  1486 |   await expect(page.getByRole('button', { name: /Unadjudicated Project/ })).toBeVisible()
  1487 |   await page.getByRole('button', { name: 'HOLD 1' }).click()
  1488 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
  1489 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('Marathon')
  1490 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
  1491 |   records = [permit('only-review', 'Unadjudicated campus', { projectId: 'only-review', decision: null })]
  1492 |   await page.goto('/?tier=Signals')
  1493 |   await page.getByRole('button', { name: 'SHOW 0' }).click()
  1494 |   await expect(page.getByRole('heading', { name: 'No SHOW decisions yet' })).toBeVisible()
  1495 |   await expect(page.getByText('Check REVIEW (1) for uncertain or not-yet-adjudicated projects. An unavailable Jev decision stays visible there.')).toBeVisible()
  1496 | })
  1497 | 
  1498 | test('only exact dated event evidence groups; titles describe permit work; all records stay openable', async ({ page }) => {
  1499 |   const currentYear = permit('2026-126812 BP', zilkerDescription)
  1500 |   const sameEvent = permit('2026-126791 BP', zilkerDescription)
  1501 |   const nextYear = permit('2027-126791 BP', zilkerDescription.replaceAll('2026', '2027'))
  1502 |   currentYear.group_id = 'event:zilker:2026-10'
  1503 |   sameEvent.group_id = 'event:zilker:2026-10'
  1504 |   nextYear.group_id = 'event:zilker:2027-10'
  1505 |   const records = [currentYear, sameEvent, nextYear]
  1506 |   const groups = projectCards(records)
  1507 |   expect(groups.map((group) => group.members.length)).toEqual([2, 1])
  1508 |   expect(groups[0].title).toMatch(/Zilker Park.*Oct 2026/)
  1509 |   expect(projectTitle(permit('2026-097374 BP', 'Generator replacement. Existing natural gas NG generator and its pad will be removed; a new ATS will be installed.'))).toBe('Generator Replacement')
  1510 |   expect(projectTitle(permit('3460046', 'PERMIT EXPIRES ON 11/09/2026 ERECTION STARTS: 9/26/2026, ERECTION ENDS: 9/27/2026. 2019 CBC. REINSTATEMENT OF 2025 PERMIT 101074048 FOR THE 2026 HYDE PARK JAZZ FEST STAGES AT THE MUSEUM.'))).toMatch(/Hyde Park Jazz Fest Stages/i)
  1511 |   expect(projectTitle(permit('3460191', '2026 INTL. FESTIVAL OF LIFE JERK SEAFOOD AND VEGAN FEST STAGE ON SEPT. 25-27, 2026.'))).toMatch(/International Festival of Life.*September/i)
  1512 |   expect(projectTitle(permit('3460022', '2026 ST. ALPHONSUS OKTOBERFEST STAGE ON SEPT. 25-27, 2026.'))).toMatch(/St Alphonsus Oktoberfest/i)
  1513 |   expect(projectTitle(permit('2026-118574 BP', 'CBC 2019.', { activity: 'backup-power', location: '919 E 32ND ST, AUSTIN, TX' }))).toBe('Backup power · 919 E 32ND ST, AUSTIN, TX')
  1514 |   expect(projectTitle(permit('2026-118573 BP', null, {
  1515 |     activity: 'backup-power',
  1516 |     location: '919 E 32ND ST, AUSTIN, TX',
  1517 |     abstract: 'row: 2026-118573 BP\ndate: 2026-09-14\ndescription: Remodel hospital surgery area with associated above and below ceiling work',
  1518 |   }))).toBe('Remodel Hospital Surgery Area With Associated Above And Below Ceiling Work')
  1519 |   expect(projectTitle(permit('2026-000001 BP', null, {
  1520 |     activity: 'facility-expansion',
  1521 |     location: '100 MAIN ST, AUSTIN, TX',
  1522 |     abstract: 'row: 2026-000001 BP\ndate: 2026-09-14\nstatus: Issued',
  1523 |   }))).toBe('Facility expansion · 100 MAIN ST, AUSTIN, TX')
  1524 |   expect(projectTitle(permit('2026-000002 BP', null, {
  1525 |     activity: 'facility-expansion',
  1526 |     location: '200 MAIN ST, AUSTIN, TX',
  1527 |     abstract: 'row: 2026-000002 BP\ndate: 2026-09-14\nwork: New\ntype: Building Permit',
  1528 |   }))).toBe('Facility expansion · 200 MAIN ST, AUSTIN, TX')
  1529 |   const georgia = (action: string, abstract: string, activity = 'facility-expansion', id = 'GA-1') => ({
  1530 |     ...permit(id, action, { activity, location: 'Hampton, Georgia', abstract }),
  1531 |     evidence: [{ ...permit(id, action).evidence[0], source_id: 'georgia-air-draft-title-v' }],
  1532 |   })
  1533 |   expect(projectTitle(georgia('construct a data center facility', 'Historical excerpt: equipment inventory.', 'facility-expansion'))).toBe('New data center construction')
  1534 |   expect(projectTitle(georgia('The operations will be powered with four Tier 4 certified diesel fired generator sets for the first two years after startup or until grid power is available, whichever is earlier.', 'Historical excerpt: unrelated text.', 'temporary-power'))).toBe('Generators until grid power is available')
  1535 |   expect(projectTitle(georgia('Application proposes installation of additional emergency generators for the campus.', 'Historical excerpt: unrelated text.', 'backup-power'))).toBe('Backup power · Hampton, Georgia')
  1536 |   expect(projectTitle(georgia('construction and operation of a landfill gas-to-renewable natural gas processing facility.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Renewable natural gas facility construction')
  1537 |   expect(projectTitle(georgia('construction and operation of an additional 337 emergency generators and nine fire pumps.', 'Historical excerpt: unrelated text.', 'backup-power'))).toBe('Additional emergency generators')
  1538 |   expect(projectTitle(georgia('replacing the existing permitted drum dryer and baghouse with like-kind equipment.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Asphalt plant equipment replacement')
  1539 |   expect(projectTitle(georgia('increasing the permitted production capacity at this quarry.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Quarry production capacity increase')
  1540 |   expect(projectTitle(georgia('modification and operation of this existing quarry and stone processing facility.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Quarry processing equipment modification')
  1541 |   expect(projectTitle(georgia('', 'Application purpose details are unavailable.', 'backup-power'))).toBe('Backup power · Hampton, Georgia')
  1542 |   const liveGeorgia = [
  1543 |     ['Walker County Quarry', 'Page 1 current application purpose: for increasing the permitted production (crushing) capacity of the facility. Page 1 background prospective activity: Construction of the Facility is planned to begin in Q2 2026.'],
  1544 |     ['Vulcan Construction Materials, LLC – Siloam Quarry', 'for the modification and operation of this existing quarry and associated stone processing facility. According to Application No. 29927, the proposed facility modification involves: adding a 475 ton-per-hour portable stone processing plant.'],
  1545 |     ['TADG – ATL02 / Ellenwood', 'for the construction and operation of diesel-fired emergency generators to provide backup power at a new data center located in Ellenwood, Georgia.'],
  1546 |     ['South Atlanta Asphalt Plant', 'for replacing the existing permitted drum dryer and baghouse with a like-kind new drum dryer and baghouse.'],
  1547 |     ['QTS Fayetteville I, LLC', 'for the construction and operation of an additional 337 emergency generators and nine fire pumps.'],
```