# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> late restored-page response cannot replace a newer Back/Forward destination
- Location: tests\project_cards.spec.ts:443:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Prospects' })

```

# Test source

```ts
  391 |   expect(new URL(page.url()).hash).toBe('')
  392 |   expect(detailRequests).toHaveLength(1)
  393 |   expect(detailRequests[0].searchParams.get('tier')).toBe('Signal')
  394 |   expect(detailRequests[0].searchParams.get('search')).toBe('visible')
  395 |   expect(detailRequests[0].searchParams.get('activity')).toBe('event-power')
  396 |   expect(detailRequests[0].searchParams.get('cohort_token')).toBe('fixture-server-cohort')
  397 | })
  398 | 
  399 | test('direct selected URL hydrates the exact need with the restored page cohort when it moved off-page', async ({ page }) => {
  400 |   const currentPageRecord = permit('current-page-record', 'A separate current page record')
  401 |   const selectedRecord = permit('selected-off-page', 'Exact restored off-page record')
  402 |   selectedRecord.evidence[0].title = 'Citation for the restored off-page record'
  403 |   const detailRequests: URL[] = []
  404 |   const opportunityRequests: URL[] = []
  405 |   await page.route(apiRoute, async (route) => {
  406 |     const url = new URL(route.request().url())
  407 |     if (url.pathname === '/api/opportunities') {
  408 |       opportunityRequests.push(url)
  409 |       const payload = serverOpportunityPage([currentPageRecord], url.searchParams.get('decision') ?? 'ALL')
  410 |       await route.fulfill({
  411 |         status: 200,
  412 |         contentType: 'application/json',
  413 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0', 'X-Cohort-Token': 'restored-scope-token' },
  414 |         body: JSON.stringify(payload.items),
  415 |       })
  416 |       return
  417 |     }
  418 |     if (url.pathname === '/api/opportunities/needs/selected-off-page') {
  419 |       detailRequests.push(url)
  420 |       await route.fulfill({ status: 200, json: selectedRecord })
  421 |       return
  422 |     }
  423 |     const body = url.pathname === '/api/auth/session'
  424 |       ? { authenticated: true }
  425 |       : url.pathname === '/api/health'
  426 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  427 |         : []
  428 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  429 |   })
  430 | 
  431 |   await page.goto('/?tier=Signals&offset=25&activity=event-power#selected-off-page')
  432 |   await expect(page.getByRole('link', { name: 'Citation for the restored off-page record' })).toBeVisible()
  433 |   await expect(page.getByRole('link', { name: /current-page-record/ })).toHaveCount(0)
  434 |   expect(opportunityRequests.map((url) => url.searchParams.get('offset'))).toEqual(['0', '25'])
  435 |   expect(opportunityRequests[0].searchParams.get('cohort_token')).toBeNull()
  436 |   expect(opportunityRequests[1].searchParams.get('cohort_token')).toBe('restored-scope-token')
  437 |   expect(detailRequests).toHaveLength(1)
  438 |   expect(detailRequests[0].searchParams.get('tier')).toBe('Signal')
  439 |   expect(detailRequests[0].searchParams.get('activity')).toBe('event-power')
  440 |   expect(detailRequests[0].searchParams.get('cohort_token')).toBe('restored-scope-token')
  441 | })
  442 | 
  443 | test('late restored-page response cannot replace a newer Back/Forward destination', async ({ page }) => {
  444 |   const firstSignal = permit('late-first-signal', 'First Signal page')
  445 |   const selectedSignal = permit('late-selected-signal', 'Delayed Signal detail record')
  446 |   const prospect = permit('late-prospect', 'Current Prospect destination', { tier: 'Prospect' })
  447 |   const requests: URL[] = []
  448 |   let restoreSignalPage = false
  449 |   let delayedResponseStarted = false
  450 |   let releaseDelayedResponse: (() => void) | undefined
  451 |   const delayedResponseGate = new Promise<void>((resolve) => { releaseDelayedResponse = resolve })
  452 |   await page.route(apiRoute, async (route) => {
  453 |     const url = new URL(route.request().url())
  454 |     if (url.pathname === '/api/opportunities') {
  455 |       requests.push(url)
  456 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  457 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  458 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  459 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  460 |       if (restoreSignalPage && tier === 'Signal' && offset === 25 && !delayedResponseStarted) {
  461 |         delayedResponseStarted = true
  462 |         await delayedResponseGate
  463 |       }
  464 |       await route.fulfill({
  465 |         status: 200,
  466 |         contentType: 'application/json',
  467 |         headers: {
  468 |           ...payload.headers,
  469 |           'X-Limit': '25',
  470 |           'X-Offset': String(offset),
  471 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-race-token' : 'signal-race-token',
  472 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  473 |         },
  474 |         body: JSON.stringify(payload.items),
  475 |       })
  476 |       return
  477 |     }
  478 |     const body = url.pathname === '/api/auth/session'
  479 |       ? { authenticated: true }
  480 |       : url.pathname === '/api/health'
  481 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  482 |         : url.pathname.startsWith('/api/power-needs/')
  483 |           ? { status: 'unavailable', result: null, citations: [] }
  484 |           : []
  485 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  486 |   })
  487 | 
  488 |   try {
  489 |     await page.goto('/?tier=Signals&offset=25')
  490 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
> 491 |     await page.getByRole('button', { name: 'Prospects' }).click()
      |                                                           ^ Error: locator.click: Test timeout of 30000ms exceeded.
  492 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  493 | 
  494 |     restoreSignalPage = true
  495 |     await page.goBack()
  496 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  497 |     await page.goForward()
  498 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  499 |     releaseDelayedResponse?.()
  500 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  501 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  502 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  503 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  504 |   } finally {
  505 |     releaseDelayedResponse?.()
  506 |   }
  507 | })
  508 | 
  509 | test('active first-page tier click preserves ready metadata and closes its detail without refetching', async ({ page }) => {
  510 |   const record = permit('active-tier-ready', 'Campus facility activity')
  511 |   const requests: URL[] = []
  512 |   await page.route(apiRoute, async (route) => {
  513 |     const url = new URL(route.request().url())
  514 |     if (url.pathname === '/api/opportunities') {
  515 |       requests.push(url)
  516 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  517 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  518 |       return
  519 |     }
  520 |     const body = url.pathname === '/api/auth/session'
  521 |       ? { authenticated: true }
  522 |       : url.pathname === '/api/health'
  523 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  524 |         : url.pathname.startsWith('/api/power-needs/')
  525 |           ? { status: 'unavailable', result: null, citations: [] }
  526 |           : []
  527 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  528 |   })
  529 | 
  530 |   await page.goto('/?tier=Signals')
  531 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  532 |   const initialUrl = page.url()
  533 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  534 |   await expect(csv).toBeVisible()
  535 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  536 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  537 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  538 |   await expect(csv).toBeVisible()
  539 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  540 |   expect(page.url()).toBe(initialUrl)
  541 |   expect(requests).toHaveLength(1)
  542 | 
  543 |   await page.locator('[data-opportunity-id="active-tier-ready"]').click()
  544 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  545 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  546 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  547 |   await expect(csv).toBeVisible()
  548 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  549 |   expect(requests).toHaveLength(1)
  550 | })
  551 | 
  552 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  553 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  554 |   let requestCount = 0
  555 |   let releaseRequest: (() => void) | undefined
  556 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  557 |   await page.route(apiRoute, async (route) => {
  558 |     const url = new URL(route.request().url())
  559 |     if (url.pathname === '/api/opportunities') {
  560 |       requestCount += 1
  561 |       await gate
  562 |       const payload = serverOpportunityPage([record])
  563 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  564 |       return
  565 |     }
  566 |     const body = url.pathname === '/api/auth/session'
  567 |       ? { authenticated: true }
  568 |       : url.pathname === '/api/health'
  569 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  570 |         : []
  571 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  572 |   })
  573 |   try {
  574 |     await page.goto('/?tier=Signals')
  575 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  576 |     await expect.poll(() => requestCount).toBe(1)
  577 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  578 |     await page.getByRole('button', { name: 'Signals' }).click()
  579 |     releaseRequest?.()
  580 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  581 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  582 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  583 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  584 |     expect(requestCount).toBe(1)
  585 |   } finally {
  586 |     releaseRequest?.()
  587 |   }
  588 | })
  589 | 
  590 | test('active tier click from a later page fetches first-page data before showing totals', async ({ page }) => {
  591 |   const firstPageRecord = permit('active-tier-first-page', 'First-page campus activity')
```