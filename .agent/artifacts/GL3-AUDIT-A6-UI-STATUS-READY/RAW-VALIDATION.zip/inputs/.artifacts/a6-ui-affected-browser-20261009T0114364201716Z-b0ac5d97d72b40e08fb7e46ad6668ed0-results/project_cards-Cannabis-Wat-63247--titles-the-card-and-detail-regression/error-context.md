# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> Cannabis Watch is removed and an evidence-supported applicant titles the card and detail
- Location: tests\project_cards.spec.ts:133:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Green Valley Cultivation LLC · applicant', level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Green Valley Cultivation LLC · applicant', level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Green Valley Cultivation LLC · applicant', level: 1 })

```

# Test source

```ts
  59  |   const page = serverOpportunityPage(records)
  60  |   page.items = page.items.map((item) => {
  61  |     const source = records.find((record) => record.id === item.id)
  62  |     return {
  63  |       ...item,
  64  |       group_total_filtered: source?.group_total_filtered ?? 2,
  65  |       group_loaded_on_page: records.filter((record) => record.group_id === item.group_id).length,
  66  |       group_complete_on_page: source?.group_complete_on_page ?? false,
  67  |     }
  68  |   })
  69  |   return page
  70  | }
  71  | 
  72  | function permit(id: string, action: string | null, options: { location?: string; activity?: string; tier?: string; abstract?: string; projectId?: string; decision?: string | null } = {}): Opportunity {
  73  |   return {
  74  |     id,
  75  |     project_id: options.projectId ?? '',
  76  |     name: `AUSTIN permit ${id}`,
  77  |     location: options.location ?? '2100 BARTON SPRINGS RD, AUSTIN, TX',
  78  |     tier: options.tier ?? 'Signal',
  79  |     workflow_status: 'UNKNOWN',
  80  |     activity: options.activity ?? 'event-power',
  81  |     rationale: 'Permit reports a dated powered event activity; temporary rental power is a question to investigate.',
  82  |     signal_evidence_state: 'active_evidence',
  83  |     brief_status: 'unavailable', brief_stale: false,
  84  |     signal_display_decision: options.decision === undefined ? 'SHOW' : options.decision,
  85  |     signal_display_decision_state: options.decision === undefined ? 'adjudicated' : options.decision ? 'adjudicated' : 'unadjudicated',
  86  |     required_mw: null,
  87  |     start_window: null,
  88  |     duration: null,
  89  |     supply: 'Unknown',
  90  |     next_action: 'Confirm activity power needs, timing, duration, and service plan.',
  91  |     conflict_state: 'Not assessed',
  92  |     assessment_reason: 'Permit reports a dated powered event activity; temporary rental power is a question to investigate.',
  93  |     supported_subject: `AUSTIN permit ${id}`,
  94  |     supported_action: action,
  95  |     demand_quote: null,
  96  |     supply_quote: null,
  97  |     missing_facts: ['activity-specific power requirement'],
  98  |     evidence: [{
  99  |       id: `evidence-${id}`,
  100 |       title: `Austin building permit ${id}`,
  101 |       abstract: options.abstract ?? action,
  102 |       url: `https://example.invalid/${id}`,
  103 |       published_at: '2026-09-14',
  104 |       retrieved_at: '2026-09-27T12:00:00Z',
  105 |       extraction_location: 'description',
  106 |       content_hash: `hash-${id}`,
  107 |       event_date: null,
  108 |       event_date_label: 'Unknown',
  109 |       source_id: 'austin-building-permits',
  110 |       source_origin: 'Official permit',
  111 |       document_number: id,
  112 |       assessment_current: true,
  113 |       permit_status: 'Issued',
  114 |     }],
  115 |   }
  116 | }
  117 | 
  118 | test('stable project IDs consolidate lifecycle records and decision filters default uncertain records to REVIEW', () => {
  119 |   const planning = permit('planning', 'Planning approval', { projectId: 'project-atlas', decision: 'SHOW' })
  120 |   const electrical = permit('electrical', 'Temporary electrical service', { projectId: 'project-atlas', decision: 'HOLD' })
  121 |   const similarTitle = permit('other', 'Planning approval', { projectId: 'different-project', decision: 'REVIEW' })
  122 |   const unadjudicated = permit('unknown', 'Permit under review', { decision: null })
  123 |   const cards = projectCards([planning, electrical, similarTitle, unadjudicated])
  124 | 
  125 |   expect(cards).toHaveLength(3)
  126 |   expect(cards[0].members.map((member) => member.id)).toEqual(['planning', 'electrical'])
  127 |   expect(signalDisplayDecision(cards[0].members)).toBe('SHOW')
  128 |   expect(signalDecisionCards(cards, 'SHOW')).toHaveLength(1)
  129 |   expect(signalDecisionCards(cards, 'REVIEW').map((card) => card.members[0].id)).toEqual(['other', 'unknown'])
  130 |   expect(signalDecisionCards(cards, 'HOLD')).toHaveLength(0)
  131 | })
  132 | 
  133 | test('Cannabis Watch is removed and an evidence-supported applicant titles the card and detail', async ({ page }) => {
  134 |   const record = permit('cultivation', 'Dated cultivation application at 14 Example Road', {
  135 |     location: '14 Example Road, Boston, MA',
  136 |     activity: 'facility-expansion',
  137 |     abstract: 'applicant_org: Green Valley Cultivation LLC\naddress: 14 Example Road, Boston, MA',
  138 |   })
  139 |   record.name = 'Houston permit cultivation'
  140 |   record.evidence[0].source_id = 'ma-cultivation-applications'
  141 |   record.commercial_size_status = 'unknown'
  142 |   await page.route(apiRoute, async (route) => {
  143 |     const path = new URL(route.request().url()).pathname
  144 |     const body = path === '/api/auth/session'
  145 |       ? { authenticated: true }
  146 |       : path === '/api/opportunities'
  147 |         ? [record]
  148 |         : path === '/api/health'
  149 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  150 |           : []
  151 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  152 |   })
  153 |   await page.goto('/?tier=Signals')
  154 |   await expect(page.getByRole('button', { name: 'Cannabis watch' })).toHaveCount(0)
  155 |   const card = page.getByRole('button', { name: /Green Valley Cultivation LLC · applicant/ })
  156 |   await expect(card).toBeVisible()
  157 |   await expect(card).toContainText('Activity size unknown · retained')
  158 |   await card.click()
> 159 |   await expect(page.getByRole('heading', { level: 1, name: 'Green Valley Cultivation LLC · applicant' })).toBeVisible()
      |                                                                                                           ^ Error: expect(locator).toBeVisible() failed
  160 |   await expect(page.getByText('Activity size unknown.')).toBeVisible()
  161 |   await page.getByRole('button', { name: /Back to Signals/ }).click()
  162 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('Green Valley Cultivation')
  163 |   await expect(page.getByRole('button', { name: /Green Valley Cultivation LLC · applicant/ })).toBeVisible()
  164 | })
  165 | 
  166 | test('browse filters travel through the request URL and restore with the selected detail Back state', async ({ page }) => {
  167 |   const record = permit('filter-back', 'Dated construction permit for a synthetic campus')
  168 |   record.group_id = 'opaque-filter-group'
  169 |   record.group_title = 'Synthetic campus'
  170 |   record.group_total_filtered = 1
  171 |   record.group_loaded_on_page = 1
  172 |   record.group_complete_on_page = true
  173 |   record.matched_search = true
  174 |   const requests: URL[] = []
  175 |   await page.route(apiRoute, async (route) => {
  176 |     const url = new URL(route.request().url())
  177 |     const path = url.pathname
  178 |     if (path === '/api/opportunities') requests.push(url)
  179 |     const body = path === '/api/auth/session'
  180 |       ? { authenticated: true }
  181 |       : path === '/api/opportunities'
  182 |         ? [record]
  183 |         : /^\/api\/needs\/[^/]+\/facts$/.test(path)
  184 |           ? { items: [], total: 0, limit: 50, offset: 0, next_offset: null, current_fact_version: 0,
  185 |             current_reported_timing_correction_target: {
  186 |               available: false, unavailable_reason: 'no_current_admitted_lead', need_id: record.id,
  187 |               project_id: record.project_id, project_identity_key: record.group_id ?? record.id, activity_key: record.activity,
  188 |               facility_identity: null, source_semantic_hash: null, source_evidence_hash: null, retained_evidence_id: null,
  189 |               source_id: null, earliest_possible_start: null, latest_possible_start: null,
  190 |               minimum_duration_days: null, maximum_duration_days: null, current_fact_version: 0,
  191 |             } }
  192 |         : /^\/api\/needs\/[^/]+\/workflow-status$/.test(path)
  193 |           ? { status: 'UNKNOWN', version: 0, events: [] }
  194 |         : path === '/api/health'
  195 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  196 |           : []
  197 |     await route.fulfill({
  198 |       status: 200,
  199 |       contentType: 'application/json',
  200 |       headers: path === '/api/opportunities'
  201 |         ? { 'X-Total-Count': '1', 'X-Group-Total-Count': '1', 'X-Page-Record-Count': '1', 'X-Page-Group-Count': '1', 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0', 'X-Cohort-Token': 'fixture-cohort', 'X-Decision-Counts': '{"SHOW":1,"REVIEW":0,"HOLD":0}' }
  202 |         : undefined,
  203 |       body: JSON.stringify(body),
  204 |     })
  205 |   })
  206 |   await page.goto('/?tier=Signals&q=campus&decision=SHOW&offset=25&geography=UNKNOWN&industry=data_center&activity=facility-expansion&timing=UNKNOWN&mw_status=UNKNOWN&mw_min=0.3&priority_segment=8&status=UNKNOWN')
  207 |   await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  208 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  209 |   await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('facility-expansion')
  210 |   await expect(page.getByRole('button', { name: /Back to Signals/ })).toHaveCount(0)
  211 |   await expect.poll(() => requests.some((request) => request.searchParams.get('geography') === 'UNKNOWN'
  212 |     && request.searchParams.get('industry') === 'data_center'
  213 |     && request.searchParams.get('activity') === 'facility-expansion'
  214 |     && request.searchParams.get('timing') === 'UNKNOWN'
  215 |     && request.searchParams.get('mw_status') === 'UNKNOWN'
  216 |     && request.searchParams.get('mw_min') === '0.3'
  217 |     && request.searchParams.get('priority_segment') === '8'
  218 |     && request.searchParams.get('status') === 'UNKNOWN')).toBe(true)
  219 |   const opportunityRequests = requests.filter((request) => request.pathname === '/api/opportunities')
  220 |   const laterPageIndex = opportunityRequests.findIndex((request) => request.searchParams.get('offset') === '25')
  221 |   expect(laterPageIndex).toBeGreaterThan(0)
  222 |   expect(opportunityRequests.slice(0, laterPageIndex).every((request) => (request.searchParams.get('offset') ?? '0') === '0'
  223 |     && request.searchParams.get('cohort_token') === null)).toBe(true)
  224 |   expect(opportunityRequests[laterPageIndex].searchParams.get('cohort_token')).toBe('fixture-cohort')
  225 |   await page.locator('[data-opportunity-id="filter-back"]').first().click()
  226 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  227 |   await page.getByRole('button', { name: /Back to Signals/ }).click()
  228 |   await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  229 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  230 |   await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('facility-expansion')
  231 |   const restored = new URL(page.url())
  232 |   expect(restored.searchParams.get('offset')).toBe('25')
  233 |   expect(restored.searchParams.get('geography')).toBe('UNKNOWN')
  234 |   expect(restored.searchParams.get('industry')).toBe('data_center')
  235 |   expect(restored.searchParams.get('activity')).toBe('facility-expansion')
  236 |   expect(restored.searchParams.get('timing')).toBe('UNKNOWN')
  237 |   expect(restored.searchParams.get('mw_min')).toBe('0.3')
  238 |   expect(restored.searchParams.get('priority_segment')).toBe('8')
  239 |   expect(restored.searchParams.get('status')).toBe('UNKNOWN')
  240 |   await page.goForward()
  241 |   await expect(page.getByRole('heading', { level: 1 })).toContainText(/Synthetic campus/i)
  242 |   await page.goBack()
  243 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  244 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  245 | })
  246 | 
  247 | test('stale later-page cohort restarts at page one without showing the previous cohort', async ({ page }) => {
  248 |   const staleRecord = permit('old-cohort-record', 'Old cohort construction filing')
  249 |   const currentRecord = permit('current-cohort-record', 'Current cohort construction filing')
  250 |   let changed = false
  251 |   const requests: URL[] = []
  252 |   await page.route(apiRoute, async (route) => {
  253 |     const url = new URL(route.request().url())
  254 |     if (url.pathname === '/api/opportunities') {
  255 |       requests.push(url)
  256 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  257 |       if (offset > 0 && url.searchParams.get('cohort_token') === 'old-cohort-token' && !changed) {
  258 |         changed = true
  259 |         await route.fulfill({ status: 409, json: { detail: 'Opportunity cohort changed; restart pagination' } })
```