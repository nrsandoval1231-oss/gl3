# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> only exact dated event evidence groups; titles describe permit work; all records stay openable
- Location: tests\project_cards.spec.ts:1498:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: /Zilker Park.*Oct 2026/, level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: /Zilker Park.*Oct 2026/, level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { name: /Zilker Park.*Oct 2026/, level: 1 })

```

# Test source

```ts
  1503 |   sameEvent.group_id = 'event:zilker:2026-10'
  1504 |   nextYear.group_id = 'event:zilker:2027-10'
  1505 |   const records = [currentYear, sameEvent, nextYear]
  1506 |   const groups = projectCards(records)
  1507 |   expect(groups.map((group) => group.members.length)).toEqual([2, 1])
  1508 |   expect(groups[0].title).toMatch(/Zilker Park.*Oct 2026/)
  1509 |   expect(projectTitle(permit('2026-097374 BP', 'Generator replacement. Existing natural gas NG generator and its pad will be removed; a new ATS will be installed.'))).toBe('Generator Replacement')
  1510 |   expect(projectTitle(permit('3460046', 'PERMIT EXPIRES ON 11/09/2026 ERECTION STARTS: 9/26/2026, ERECTION ENDS: 9/27/2026. 2019 CBC. REINSTATEMENT OF 2025 PERMIT 101074048 FOR THE 2026 HYDE PARK JAZZ FEST STAGES AT THE MUSEUM.'))).toMatch(/Hyde Park Jazz Fest Stages/i)
  1511 |   expect(projectTitle(permit('3460191', '2026 INTL. FESTIVAL OF LIFE JERK SEAFOOD AND VEGAN FEST STAGE ON SEPT. 25-27, 2026.'))).toMatch(/International Festival of Life.*September/i)
  1512 |   expect(projectTitle(permit('3460022', '2026 ST. ALPHONSUS OKTOBERFEST STAGE ON SEPT. 25-27, 2026.'))).toMatch(/St Alphonsus Oktoberfest/i)
  1513 |   expect(projectTitle(permit('2026-118574 BP', 'CBC 2019.', { activity: 'backup-power', location: '919 E 32ND ST, AUSTIN, TX' }))).toBe('Backup power · 919 E 32ND ST, AUSTIN, TX')
  1514 |   expect(projectTitle(permit('2026-118573 BP', null, {
  1515 |     activity: 'backup-power',
  1516 |     location: '919 E 32ND ST, AUSTIN, TX',
  1517 |     abstract: 'row: 2026-118573 BP\ndate: 2026-09-14\ndescription: Remodel hospital surgery area with associated above and below ceiling work',
  1518 |   }))).toBe('Remodel Hospital Surgery Area With Associated Above And Below Ceiling Work')
  1519 |   expect(projectTitle(permit('2026-000001 BP', null, {
  1520 |     activity: 'facility-expansion',
  1521 |     location: '100 MAIN ST, AUSTIN, TX',
  1522 |     abstract: 'row: 2026-000001 BP\ndate: 2026-09-14\nstatus: Issued',
  1523 |   }))).toBe('Facility expansion · 100 MAIN ST, AUSTIN, TX')
  1524 |   expect(projectTitle(permit('2026-000002 BP', null, {
  1525 |     activity: 'facility-expansion',
  1526 |     location: '200 MAIN ST, AUSTIN, TX',
  1527 |     abstract: 'row: 2026-000002 BP\ndate: 2026-09-14\nwork: New\ntype: Building Permit',
  1528 |   }))).toBe('Facility expansion · 200 MAIN ST, AUSTIN, TX')
  1529 |   const georgia = (action: string, abstract: string, activity = 'facility-expansion', id = 'GA-1') => ({
  1530 |     ...permit(id, action, { activity, location: 'Hampton, Georgia', abstract }),
  1531 |     evidence: [{ ...permit(id, action).evidence[0], source_id: 'georgia-air-draft-title-v' }],
  1532 |   })
  1533 |   expect(projectTitle(georgia('construct a data center facility', 'Historical excerpt: equipment inventory.', 'facility-expansion'))).toBe('New data center construction')
  1534 |   expect(projectTitle(georgia('The operations will be powered with four Tier 4 certified diesel fired generator sets for the first two years after startup or until grid power is available, whichever is earlier.', 'Historical excerpt: unrelated text.', 'temporary-power'))).toBe('Generators until grid power is available')
  1535 |   expect(projectTitle(georgia('Application proposes installation of additional emergency generators for the campus.', 'Historical excerpt: unrelated text.', 'backup-power'))).toBe('Backup power · Hampton, Georgia')
  1536 |   expect(projectTitle(georgia('construction and operation of a landfill gas-to-renewable natural gas processing facility.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Renewable natural gas facility construction')
  1537 |   expect(projectTitle(georgia('construction and operation of an additional 337 emergency generators and nine fire pumps.', 'Historical excerpt: unrelated text.', 'backup-power'))).toBe('Additional emergency generators')
  1538 |   expect(projectTitle(georgia('replacing the existing permitted drum dryer and baghouse with like-kind equipment.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Asphalt plant equipment replacement')
  1539 |   expect(projectTitle(georgia('increasing the permitted production capacity at this quarry.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Quarry production capacity increase')
  1540 |   expect(projectTitle(georgia('modification and operation of this existing quarry and stone processing facility.', 'Historical excerpt: unrelated text.', 'facility-expansion'))).toBe('Quarry processing equipment modification')
  1541 |   expect(projectTitle(georgia('', 'Application purpose details are unavailable.', 'backup-power'))).toBe('Backup power · Hampton, Georgia')
  1542 |   const liveGeorgia = [
  1543 |     ['Walker County Quarry', 'Page 1 current application purpose: for increasing the permitted production (crushing) capacity of the facility. Page 1 background prospective activity: Construction of the Facility is planned to begin in Q2 2026.'],
  1544 |     ['Vulcan Construction Materials, LLC – Siloam Quarry', 'for the modification and operation of this existing quarry and associated stone processing facility. According to Application No. 29927, the proposed facility modification involves: adding a 475 ton-per-hour portable stone processing plant.'],
  1545 |     ['TADG – ATL02 / Ellenwood', 'for the construction and operation of diesel-fired emergency generators to provide backup power at a new data center located in Ellenwood, Georgia.'],
  1546 |     ['South Atlanta Asphalt Plant', 'for replacing the existing permitted drum dryer and baghouse with a like-kind new drum dryer and baghouse.'],
  1547 |     ['QTS Fayetteville I, LLC', 'for the construction and operation of an additional 337 emergency generators and nine fire pumps.'],
  1548 |     ['QTS ATL3', 'for the construction and operation of a greenfield data center with 224 diesel-fired critical emergency generators.'],
  1549 |     ['Grady Road Renewable Energy, LLC', 'for the construction and operation of a landfill gas (LFG)-to-renewable natural gas (RNG) processing facility adjacent to the landfill.'],
  1550 |     ['Azalea Quarry', 'The operations will be powered with four Tier 4 certified diesel fired generator sets for the first two years after startup or until grid power is available, whichever is earlier.'],
  1551 |     ['Apex Site Solutions LLC', 'for the construction and operation of diesel emergency generators and diesel supporting emergency engines at a data processing facility.'],
  1552 |   ] as const
  1553 |   for (const [name, action] of liveGeorgia) {
  1554 |     const record = georgia(action, 'Historical evidence should not supply the current title.', 'facility-expansion', name)
  1555 |     expect(projectTitle(record), name).not.toBe(name)
  1556 |     expect(projectTitle(record).length).toBeLessThan(65)
  1557 |   }
  1558 |   const cityRecord = permit('100MW', 'New data center campus construction', { activity: 'facility-expansion' })
  1559 |   cityRecord.reported_power_facts = ['100 MW campus capacity', '20 MW utility service']
  1560 |   const browseRecords = [cityRecord, georgia('construct a data center facility', 'A new data center facility is proposed.', 'facility-expansion')]
  1561 |   await page.unroute(apiRoute)
  1562 |   await page.route(apiRoute, async (route) => {
  1563 |     const path = new URL(route.request().url()).pathname
  1564 |     if (path === '/api/opportunities') {
  1565 |       await fulfillServerOpportunityPage(route, browseRecords)
  1566 |       return
  1567 |     }
  1568 |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  1569 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1570 |   })
  1571 |   await page.goto('/?tier=Signals')
  1572 |   const summaryCard = page.getByRole('button', { name: /New data center construction/ }).first()
  1573 |   await expect(summaryCard).toContainText('Hampton, Georgia')
  1574 |   await expect(page.getByRole('button', { name: /New Data Center Campus Construction/ })).toContainText('100 MW campus capacity · 20 MW utility service')
  1575 |   await expect(summaryCard).not.toContainText('Load unknown')
  1576 |   await expect(summaryCard).not.toContainText('assessment')
  1577 |   await expect(summaryCard).not.toContainText('georgia-air-draft-title-v')
  1578 |   await expect(page.locator('body')).not.toHaveCSS('overflow-x', 'scroll')
  1579 | 
  1580 |   await page.route(apiRoute, async (route) => {
  1581 |     const path = new URL(route.request().url()).pathname
  1582 |     if (path === '/api/opportunities') {
  1583 |       await fulfillServerOpportunityPage(route, records)
  1584 |       return
  1585 |     }
  1586 |     const body = path === '/api/auth/session'
  1587 |       ? { authenticated: true }
  1588 |       : path === '/api/health'
  1589 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1590 |           : []
  1591 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1592 |   })
  1593 |   await page.goto('/?tier=Signals')
  1594 |   await expect(page.getByRole('heading', { name: /2 filtered project cards · 3 filtered opportunity records/ })).toBeVisible()
  1595 |   const project = page.getByRole('button', { name: /Zilker Park.*Oct 2026/ })
  1596 |   await expect(project).toBeVisible()
  1597 |   await project.click()
  1598 |   await expect(page.getByText('2 matching · 2 related permit records')).toBeVisible()
  1599 |   const currentPermitMember = page.locator('.project-member[data-opportunity-id="2026-126812 BP"]')
  1600 |   await expect(currentPermitMember).toBeVisible()
  1601 |   await expect(currentPermitMember).toContainText(projectTitle(currentYear))
  1602 |   await currentPermitMember.click()
> 1603 |   await expect(page.getByRole('heading', { level: 1, name: /Zilker Park.*Oct 2026/ })).toBeVisible()
       |                                                                                        ^ Error: expect(locator).toBeVisible() failed
  1604 |   await expect(page.getByText('austin-building-permits · 2026-126812 BP')).toBeVisible()
  1605 |   await page.getByRole('button', { name: /Back to Signals/ }).click()
  1606 | 
  1607 |   await page.getByRole('button', { name: /^SHOW \d+$/ }).click()
  1608 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('2026-126812 BP')
  1609 |   await expect(page.getByRole('heading', { name: 'Signals · 1 filtered project cards · 2 filtered opportunity records' })).toBeVisible()
  1610 |   const searchResult = page.locator('.opportunity-row').filter({ hasText: /Zilker Park.*Oct 2026/ })
  1611 |   await expect(searchResult).toBeVisible()
  1612 |   if (!(await page.getByText('1 matching · 2 related permit records').isVisible())) await searchResult.click()
  1613 |   await expect(page.getByText('1 matching · 2 related permit records')).toBeVisible()
  1614 |   await expect(currentPermitMember).toBeVisible()
  1615 | })
  1616 | 
```