# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> reclicking a pending group cancels its expansion and selected-record navigation supersedes it
- Location: tests\project_cards.spec.ts:1037:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('heading', { level: 1 })
Expected substring: "Selected Standalone Record"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('heading', { level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { level: 1 })

```

# Test source

```ts
  983  |   let releaseFirst: (() => void) | undefined
  984  |   const firstGate = new Promise<void>((resolve) => { releaseFirst = resolve })
  985  |   let firstStarted = false
  986  |   let failSecond = false
  987  |   await page.route(apiRoute, async (route) => {
  988  |     const url = new URL(route.request().url())
  989  |     if (url.pathname === '/api/opportunities') {
  990  |       const payload = partialServerOpportunityPage([first, second])
  991  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  992  |       return
  993  |     }
  994  |     if (url.pathname.startsWith('/api/opportunity-groups/')) {
  995  |       if (url.pathname.endsWith('intent-group-a')) {
  996  |         firstStarted = true
  997  |         await firstGate
  998  |         await route.fulfill({ status: 503, json: { detail: 'synthetic stale group failure' } })
  999  |         return
  1000 |       }
  1001 |       if (failSecond) {
  1002 |         await route.fulfill({ status: 503, json: { detail: 'synthetic current group failure' } })
  1003 |         return
  1004 |       }
  1005 |       await route.fulfill({ status: 200, json: { items: [second], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  1006 |       return
  1007 |     }
  1008 |     const body = url.pathname === '/api/auth/session'
  1009 |       ? { authenticated: true }
  1010 |       : url.pathname === '/api/health'
  1011 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1012 |         : []
  1013 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1014 |   })
  1015 |   try {
  1016 |     await page.goto('/?tier=Signals')
  1017 |     await page.locator('[data-opportunity-id="intent-first"]').click()
  1018 |     await expect.poll(() => firstStarted).toBe(true)
  1019 |     await page.locator('.opportunity-row[data-opportunity-id="intent-second"]').click()
  1020 |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  1021 |     releaseFirst?.()
  1022 |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  1023 |     await expect(page.locator('.project-members [data-opportunity-id="intent-first"]')).toHaveCount(0)
  1024 |     await expect(page.getByRole('alert')).toHaveCount(0)
  1025 | 
  1026 |     await page.locator('.opportunity-row[data-opportunity-id="intent-second"]').click()
  1027 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1028 |     failSecond = true
  1029 |     await page.locator('[data-opportunity-id="intent-second"]').click()
  1030 |     await expect(page.getByRole('alert')).toContainText('503')
  1031 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1032 |   } finally {
  1033 |     releaseFirst?.()
  1034 |   }
  1035 | })
  1036 | 
  1037 | test('reclicking a pending group cancels its expansion and selected-record navigation supersedes it', async ({ page }) => {
  1038 |   const grouped = permit('pending-group-member', 'Pending group member')
  1039 |   grouped.group_id = 'pending-group'
  1040 |   grouped.group_title = 'Pending group'
  1041 |   grouped.group_total_filtered = 2
  1042 |   grouped.group_loaded_on_page = 1
  1043 |   grouped.group_complete_on_page = false
  1044 |   const selected = permit('pending-selection', 'Selected standalone record')
  1045 |   selected.group_total_filtered = 1
  1046 |   selected.group_loaded_on_page = 1
  1047 |   selected.group_complete_on_page = true
  1048 |   const groupReleases: (() => void)[] = []
  1049 |   let groupRequests = 0
  1050 |   await page.route(apiRoute, async (route) => {
  1051 |     const url = new URL(route.request().url())
  1052 |     if (url.pathname === '/api/opportunities') {
  1053 |       const payload = partialServerOpportunityPage([grouped, selected])
  1054 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  1055 |       return
  1056 |     }
  1057 |     if (url.pathname === '/api/opportunity-groups/pending-group') {
  1058 |       groupRequests += 1
  1059 |       await new Promise<void>((resolve) => { groupReleases.push(resolve) })
  1060 |       await route.fulfill({ status: 200, json: { items: [grouped], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  1061 |       return
  1062 |     }
  1063 |     const body = url.pathname === '/api/auth/session'
  1064 |       ? { authenticated: true }
  1065 |       : url.pathname === '/api/health'
  1066 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1067 |         : url.pathname.startsWith('/api/opportunities/needs/')
  1068 |           ? selected
  1069 |           : []
  1070 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1071 |   })
  1072 |   try {
  1073 |     await page.goto('/?tier=Signals')
  1074 |     const group = page.locator('[data-opportunity-id="pending-group-member"]')
  1075 |     await group.click()
  1076 |     await expect.poll(() => groupRequests).toBe(1)
  1077 |     await group.click()
  1078 |     groupReleases[0]?.()
  1079 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1080 |     await group.click()
  1081 |     await expect.poll(() => groupRequests).toBe(2)
  1082 |     await page.locator('[data-opportunity-id="pending-selection"]').click()
> 1083 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
       |                                                           ^ Error: expect(locator).toContainText(expected) failed
  1084 |     groupReleases[1]?.()
  1085 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
  1086 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1087 |   } finally {
  1088 |     for (const release of groupReleases) release()
  1089 |   }
  1090 | })
  1091 | 
  1092 | test('group expansion intent is invalidated by tier, search, Signal decision, page, and view transitions', async ({ page }) => {
  1093 |   const scenarios = [
  1094 |     { name: 'tier', initialId: 'scope-signal', nextId: 'scope-prospect' },
  1095 |     { name: 'search', initialId: 'scope-signal', nextId: 'scope-search' },
  1096 |     { name: 'decision', initialId: 'scope-show', nextId: 'scope-review' },
  1097 |     { name: 'page', initialId: 'scope-page-first', nextId: 'scope-page-next' },
  1098 |     { name: 'view', initialId: 'scope-signal', nextId: '' },
  1099 |   ] as const
  1100 |   const records = new Map<string, Opportunity>()
  1101 |   for (const [id, action, options] of [
  1102 |     ['scope-signal', 'Signal scope activity', {}],
  1103 |     ['scope-prospect', 'Prospect scope activity', { tier: 'Prospect' }],
  1104 |     ['scope-search', 'newterm scope activity', {}],
  1105 |     ['scope-show', 'SHOW scope activity', { decision: 'SHOW' }],
  1106 |     ['scope-review', 'REVIEW scope activity', { decision: 'REVIEW' }],
  1107 |     ['scope-page-first', 'First page scope activity', {}],
  1108 |     ['scope-page-next', 'Next page scope activity', {}],
  1109 |   ] as const) {
  1110 |     const record = permit(id, action, options)
  1111 |     record.group_id = `group-${id}`
  1112 |     record.group_title = `Group ${id}`
  1113 |     record.group_total_filtered = 2
  1114 |     record.group_loaded_on_page = 1
  1115 |     record.group_complete_on_page = false
  1116 |     records.set(id, record)
  1117 |   }
  1118 |   let activeScenario: typeof scenarios[number] = scenarios[0]
  1119 |   let releaseGroup: (() => void) | undefined
  1120 |   let groupGate = Promise.resolve()
  1121 |   let groupStarted = false
  1122 |   let groupFinished = false
  1123 |   await page.route(apiRoute, async (route) => {
  1124 |     const url = new URL(route.request().url())
  1125 |     const path = url.pathname
  1126 |     if (path === '/api/opportunities') {
  1127 |       const tier = url.searchParams.get('tier')
  1128 |       const search = url.searchParams.get('search') ?? ''
  1129 |       const decision = url.searchParams.get('decision') ?? 'ALL'
  1130 |       const offset = Number(url.searchParams.get('offset') ?? 0)
  1131 |       const chosenId = tier?.toLowerCase() === 'prospect' ? 'scope-prospect'
  1132 |         : search ? 'scope-search'
  1133 |           : decision === 'REVIEW' ? 'scope-review'
  1134 |             : offset > 0 ? 'scope-page-next'
  1135 |               : activeScenario.name === 'decision' ? 'scope-show'
  1136 |                 : activeScenario.name === 'page' ? 'scope-page-first' : 'scope-signal'
  1137 |       const record = records.get(chosenId)!
  1138 |       const payload = partialServerOpportunityPage([record])
  1139 |       const headers: Record<string, string> = { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset) }
  1140 |       if (activeScenario.name === 'page' && offset === 0) headers['X-Next-Offset'] = '25'
  1141 |       await route.fulfill({ status: 200, contentType: 'application/json', headers, body: JSON.stringify(payload.items) })
  1142 |       return
  1143 |     }
  1144 |     if (path.startsWith('/api/opportunity-groups/')) {
  1145 |       groupStarted = true
  1146 |       await groupGate
  1147 |       const groupId = path.split('/').at(-1) ?? ''
  1148 |       const record = [...records.values()].find((candidate) => candidate.group_id === groupId)!
  1149 |       await route.fulfill({ status: 200, json: { items: [record], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  1150 |       groupFinished = true
  1151 |       return
  1152 |     }
  1153 |     const body = path === '/api/auth/session'
  1154 |       ? { authenticated: true }
  1155 |       : path === '/api/health'
  1156 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1157 |         : []
  1158 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1159 |   })
  1160 |   try {
  1161 |   for (const scenario of scenarios) {
  1162 |     activeScenario = scenario
  1163 |     groupStarted = false
  1164 |     groupFinished = false
  1165 |     groupGate = new Promise<void>((resolve) => { releaseGroup = resolve })
  1166 |     await page.goto('/?tier=Signals')
  1167 |     await page.locator(`[data-opportunity-id="${scenario.initialId}"]`).click()
  1168 |     await expect.poll(() => groupStarted).toBe(true)
  1169 |     if (scenario.name === 'tier') {
  1170 |       await page.getByRole('button', { name: 'Prospects' }).click()
  1171 |       await expect(page.locator('[data-opportunity-id="scope-prospect"]')).toBeVisible()
  1172 |     } else if (scenario.name === 'search') {
  1173 |       await page.getByRole('textbox', { name: 'Search projects' }).fill('newterm')
  1174 |       await expect(page.locator('[data-opportunity-id="scope-search"]')).toBeVisible()
  1175 |     } else if (scenario.name === 'decision') {
  1176 |       await page.getByRole('button', { name: /^REVIEW/ }).click()
  1177 |       await expect(page.locator('[data-opportunity-id="scope-review"]')).toBeVisible()
  1178 |     } else if (scenario.name === 'page') {
  1179 |       await page.getByRole('button', { name: 'Next →' }).click()
  1180 |       await expect(page.locator('[data-opportunity-id="scope-page-next"]')).toBeVisible()
  1181 |     } else {
  1182 |       await page.getByRole('button', { name: 'Ingestion' }).click()
  1183 |       await expect.poll(() => new URL(page.url()).searchParams.get('view')).toBe('ingestion')
```