# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> opening a same-cohort record during a pending Back page request does not strand loading
- Location: tests\project_cards.spec.ts:798:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '← Back to Signals' })

```

# Test source

```ts
  729 | 
  730 | test('unchanged activity filter during page load does not cancel or duplicate its request', async ({ page }) => {
  731 |   const record = permit('same-filter-pending', 'Campus facility activity')
  732 |   const requests: URL[] = []
  733 |   let releaseRequest: (() => void) | undefined
  734 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  735 |   await page.route(apiRoute, async (route) => {
  736 |     const url = new URL(route.request().url())
  737 |     if (url.pathname === '/api/opportunities') {
  738 |       requests.push(url)
  739 |       await gate
  740 |       const payload = serverOpportunityPage([record])
  741 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  742 |       return
  743 |     }
  744 |     const body = url.pathname === '/api/auth/session'
  745 |       ? { authenticated: true }
  746 |       : url.pathname === '/api/health'
  747 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  748 |         : []
  749 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  750 |   })
  751 |   try {
  752 |     await page.goto('/?tier=Signals&activity=event-power')
  753 |     await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('event-power')
  754 |     await expect.poll(() => requests.length).toBe(1)
  755 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  756 |     await page.waitForTimeout(100)
  757 |     expect(requests).toHaveLength(1)
  758 |     releaseRequest?.()
  759 |     await expect(page.locator('[data-opportunity-id="same-filter-pending"]')).toBeVisible()
  760 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  761 |   } finally {
  762 |     releaseRequest?.()
  763 |   }
  764 | })
  765 | 
  766 | test('clicking the active ingestion view during its request does not strand loading', async ({ page }) => {
  767 |   let requestStarted = false
  768 |   let releaseRequest: (() => void) | undefined
  769 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  770 |   await page.route(apiRoute, async (route) => {
  771 |     const url = new URL(route.request().url())
  772 |     if (url.pathname === '/api/ingestion') {
  773 |       requestStarted = true
  774 |       await gate
  775 |       await route.fulfill({ status: 200, json: { items: [], total: 0, limit: 25, offset: 0 } })
  776 |       return
  777 |     }
  778 |     const body = url.pathname === '/api/auth/session'
  779 |       ? { authenticated: true }
  780 |       : url.pathname === '/api/health'
  781 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  782 |         : []
  783 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  784 |   })
  785 |   try {
  786 |     await page.goto('/?view=ingestion')
  787 |     await expect(page.getByRole('button', { name: 'Ingestion' })).toBeVisible()
  788 |     await expect.poll(() => requestStarted).toBe(true)
  789 |     await page.getByRole('button', { name: 'Ingestion' }).click()
  790 |     releaseRequest?.()
  791 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  792 |     await expect(page.getByRole('heading', { name: 'No retained source items' })).toBeVisible()
  793 |   } finally {
  794 |     releaseRequest?.()
  795 |   }
  796 | })
  797 | 
  798 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  799 |   const record = permit('open-during-refresh-a', 'First campus facility activity')
  800 |   const nextRecord = permit('open-during-refresh-b', 'Second campus facility activity')
  801 |   let opportunityRequests = 0
  802 |   let secondRequestStarted = false
  803 |   let releaseSecondRequest: (() => void) | undefined
  804 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  805 |   await page.route(apiRoute, async (route) => {
  806 |     const url = new URL(route.request().url())
  807 |     if (url.pathname === '/api/opportunities') {
  808 |       opportunityRequests += 1
  809 |       if (opportunityRequests === 2) {
  810 |         secondRequestStarted = true
  811 |         await secondRequestGate
  812 |       }
  813 |       const payload = serverOpportunityPage([record, nextRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  814 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  815 |       return
  816 |     }
  817 |     const body = url.pathname === '/api/auth/session'
  818 |       ? { authenticated: true }
  819 |       : url.pathname === '/api/health'
  820 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  821 |         : url.pathname.startsWith('/api/power-needs/')
  822 |           ? { status: 'unavailable', result: null, citations: [] }
  823 |           : []
  824 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  825 |   })
  826 |   try {
  827 |     await page.goto('/?tier=Signals')
  828 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
> 829 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
      |                                                                   ^ Error: locator.click: Test timeout of 30000ms exceeded.
  830 |     await expect.poll(() => secondRequestStarted).toBe(true)
  831 |     await expect(page.locator('[data-opportunity-id="open-during-refresh-a"]')).toBeVisible()
  832 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  833 |     await expect(page.getByRole('button', { name: 'Next →' })).toBeEnabled()
  834 |     await page.getByRole('button', { name: 'Next →' }).click()
  835 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  836 |     releaseSecondRequest?.()
  837 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  838 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  839 |   } finally {
  840 |     releaseSecondRequest?.()
  841 |   }
  842 | })
  843 | 
  844 | test('late group expansion pages cannot restore members from a superseded browse filter', async ({ page }) => {
  845 |   const oldFirst = permit('scope-a-first', 'Activity A first record', { activity: 'activity-a' })
  846 |   const oldLast = permit('scope-a-last', 'Activity A later record', { activity: 'activity-a' })
  847 |   const current = permit('scope-b-current', 'Activity B current record', { activity: 'activity-b' })
  848 |   const partial = (record: Opportunity, groupId: string, total: number) => {
  849 |     record.group_id = groupId
  850 |     record.group_title = 'Stable event group'
  851 |     record.group_total_filtered = total
  852 |     record.group_loaded_on_page = 1
  853 |     record.group_complete_on_page = false
  854 |     return record
  855 |   }
  856 |   partial(oldFirst, 'stable-group', 51)
  857 |   partial(oldLast, 'stable-group', 51)
  858 |   partial(current, 'stable-group', 2)
  859 |   let releaseOldLaterPage: (() => void) | undefined
  860 |   const oldLaterPage = new Promise<void>((resolve) => { releaseOldLaterPage = resolve })
  861 |   let oldLaterPageStarted = false
  862 |   const groupRequests: URL[] = []
  863 |   await page.route(apiRoute, async (route) => {
  864 |     const url = new URL(route.request().url())
  865 |     const path = url.pathname
  866 |     if (path === '/api/opportunities') {
  867 |       const activity = url.searchParams.get('activity')
  868 |       const record = activity === 'activity-a' ? oldFirst : current
  869 |       const payload = partialServerOpportunityPage([record])
  870 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0' }, body: JSON.stringify(payload.items) })
  871 |       return
  872 |     }
  873 |     if (path === '/api/opportunity-groups/stable-group') {
  874 |       groupRequests.push(url)
  875 |       const activity = url.searchParams.get('activity')
  876 |       const groupOffset = Number(url.searchParams.get('offset'))
  877 |       if (activity === 'activity-a' && groupOffset === 50) {
  878 |         oldLaterPageStarted = true
  879 |         await oldLaterPage
  880 |         await route.fulfill({ status: 200, json: { items: [oldLast], total: 51, limit: 50, offset: 50, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  881 |         return
  882 |       }
  883 |       await route.fulfill({ status: 200, json: { items: [activity === 'activity-a' ? oldFirst : current], total: activity === 'activity-a' ? 51 : 1, limit: 50, offset: groupOffset, next_offset: activity === 'activity-a' ? 50 : null, cohort_token: 'fixture-server-cohort' } })
  884 |       return
  885 |     }
  886 |     const body = path === '/api/auth/session'
  887 |       ? { authenticated: true }
  888 |       : path === '/api/health'
  889 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  890 |         : []
  891 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  892 |   })
  893 |   try {
  894 |     await page.goto('/?tier=Signals&activity=activity-a')
  895 |     const group = page.locator('[data-opportunity-id="scope-a-first"]')
  896 |     await expect(group).toBeVisible()
  897 |     await group.click()
  898 |     await expect.poll(() => oldLaterPageStarted).toBe(true)
  899 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('activity-b')
  900 |     await expect(page.locator('[data-opportunity-id="scope-b-current"]')).toBeVisible()
  901 |     releaseOldLaterPage?.()
  902 |     await expect(page.locator('.project-members')).toHaveCount(0)
  903 |     await expect(page.locator('[data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  904 |     expect(groupRequests.every((request) => request.searchParams.get('cohort_token') === 'fixture-server-cohort')).toBe(true)
  905 |     expect(groupRequests.some((request) => request.searchParams.get('activity') === 'activity-a' && request.searchParams.get('offset') === '50')).toBe(true)
  906 |     await page.locator('[data-opportunity-id="scope-b-current"]').click()
  907 |     await expect(page.locator('.project-members [data-opportunity-id="scope-b-current"]')).toBeVisible()
  908 |     await expect(page.locator('.project-members [data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  909 |   } finally {
  910 |     releaseOldLaterPage?.()
  911 |   }
  912 | })
  913 | 
  914 | test('Back refresh with a rotated cohort token supersedes a pending group expansion', async ({ page }) => {
  915 |   const record = permit('token-rotation-member', 'Token rotation group member')
  916 |   record.group_id = 'token-rotation-group'
  917 |   record.group_title = 'Token rotation group'
  918 |   record.group_total_filtered = 2
  919 |   record.group_loaded_on_page = 1
  920 |   record.group_complete_on_page = false
  921 |   let pageRequests = 0
  922 |   let releaseGroup: (() => void) | undefined
  923 |   const groupGate = new Promise<void>((resolve) => { releaseGroup = resolve })
  924 |   let groupStarted = false
  925 |   let groupFinished = false
  926 |   const groupRequests: URL[] = []
  927 |   const pageTokens: string[] = []
  928 |   await page.route(apiRoute, async (route) => {
  929 |     const url = new URL(route.request().url())
```