# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> Back restores the exact selected need across tiers and pages with its cohort and focus
- Location: tests\project_cards.spec.ts:294:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('link', { name: 'Citation for the exact later-page Signal' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('link', { name: 'Citation for the exact later-page Signal' }) with timeout 5000ms
  - waiting for getByRole('link', { name: 'Citation for the exact later-page Signal' })

```

# Test source

```ts
  237 |   expect(restored.searchParams.get('mw_min')).toBe('0.3')
  238 |   expect(restored.searchParams.get('priority_segment')).toBe('8')
  239 |   expect(restored.searchParams.get('status')).toBe('UNKNOWN')
  240 |   await page.goForward()
  241 |   await expect(page.getByRole('heading', { level: 1 })).toContainText(/Synthetic campus/i)
  242 |   await page.goBack()
  243 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  244 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  245 | })
  246 | 
  247 | test('stale later-page cohort restarts at page one without showing the previous cohort', async ({ page }) => {
  248 |   const staleRecord = permit('old-cohort-record', 'Old cohort construction filing')
  249 |   const currentRecord = permit('current-cohort-record', 'Current cohort construction filing')
  250 |   let changed = false
  251 |   const requests: URL[] = []
  252 |   await page.route(apiRoute, async (route) => {
  253 |     const url = new URL(route.request().url())
  254 |     if (url.pathname === '/api/opportunities') {
  255 |       requests.push(url)
  256 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  257 |       if (offset > 0 && url.searchParams.get('cohort_token') === 'old-cohort-token' && !changed) {
  258 |         changed = true
  259 |         await route.fulfill({ status: 409, json: { detail: 'Opportunity cohort changed; restart pagination' } })
  260 |         return
  261 |       }
  262 |       const record = changed ? currentRecord : staleRecord
  263 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  264 |       await route.fulfill({
  265 |         status: 200,
  266 |         contentType: 'application/json',
  267 |         headers: { ...payload.headers, 'X-Offset': String(offset), 'X-Cohort-Token': changed ? 'current-cohort-token' : 'old-cohort-token', ...(offset === 0 && !changed ? { 'X-Next-Offset': '25' } : {}) },
  268 |         body: JSON.stringify(payload.items),
  269 |       })
  270 |       return
  271 |     }
  272 |     const body = url.pathname === '/api/auth/session'
  273 |       ? { authenticated: true }
  274 |       : url.pathname === '/api/health'
  275 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  276 |         : []
  277 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  278 |   })
  279 |   await page.goto('/?tier=Signals')
  280 |   const oldCard = page.getByRole('button', { name: /Old cohort construction filing/i })
  281 |   await expect(oldCard).toBeVisible()
  282 |   await page.getByRole('button', { name: /Next/ }).click()
  283 |   const currentCard = page.getByRole('button', { name: /Current cohort construction filing/i })
  284 |   await expect(currentCard).toBeVisible()
  285 |   await expect(page.getByRole('button', { name: /Old cohort construction filing/i })).toHaveCount(0)
  286 |   expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  287 |   const opportunityRequests = requests
  288 |   const laterRequest = opportunityRequests.find((request) => request.searchParams.get('offset') === '25')
  289 |   expect(laterRequest?.searchParams.get('cohort_token')).toBe('old-cohort-token')
  290 |   const restarted = opportunityRequests.find((request, index) => index > opportunityRequests.indexOf(laterRequest!) && (request.searchParams.get('offset') ?? '0') === '0')
  291 |   expect(restarted?.searchParams.get('cohort_token')).toBeNull()
  292 | })
  293 | 
  294 | test('Back restores the exact selected need across tiers and pages with its cohort and focus', async ({ page }) => {
  295 |   const firstSignal = permit('signal-first-page', 'First Signal page record')
  296 |   const selectedSignal = permit('signal-later-page', 'Exact Signal later-page record')
  297 |   selectedSignal.evidence[0].title = 'Citation for the exact later-page Signal'
  298 |   const prospect = permit('prospect-first-page', 'Distinct Prospect page record', { tier: 'Prospect' })
  299 |   const requests: URL[] = []
  300 |   await page.route(apiRoute, async (route) => {
  301 |     const url = new URL(route.request().url())
  302 |     const path = url.pathname
  303 |     if (path === '/api/opportunities') {
  304 |       requests.push(url)
  305 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  306 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  307 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  308 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  309 |       await route.fulfill({
  310 |         status: 200,
  311 |         contentType: 'application/json',
  312 |         headers: {
  313 |           ...payload.headers,
  314 |           'X-Limit': '25',
  315 |           'X-Offset': String(offset),
  316 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-scope-token' : 'signal-scope-token',
  317 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  318 |         },
  319 |         body: JSON.stringify(payload.items),
  320 |       })
  321 |       return
  322 |     }
  323 |     const body = path === '/api/auth/session'
  324 |       ? { authenticated: true }
  325 |       : path === '/api/health'
  326 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  327 |         : path.startsWith('/api/power-needs/')
  328 |           ? { status: 'unavailable', result: null, citations: [] }
  329 |           : []
  330 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  331 |   })
  332 | 
  333 |   await page.goto('/?tier=Signals&decision=SHOW&offset=25&activity=event-power')
  334 |   const selectedCard = page.locator('[data-opportunity-id="signal-later-page"]')
  335 |   await expect(selectedCard).toBeVisible()
  336 |   await selectedCard.click()
> 337 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
      |                                                                                              ^ Error: expect(locator).toBeVisible() failed
  338 |   expect(new URL(page.url()).hash).toBe('#signal-later-page')
  339 |   await page.getByRole('button', { name: 'Prospects' }).click()
  340 |   await expect(page.locator('[data-opportunity-id="prospect-first-page"]')).toBeVisible()
  341 | 
  342 |   await page.goBack()
  343 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
  344 |   expect(new URL(page.url()).searchParams.get('tier')).toBe('Signals')
  345 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  346 |   expect(new URL(page.url()).searchParams.get('decision')).toBe('SHOW')
  347 |   expect(new URL(page.url()).searchParams.get('activity')).toBe('event-power')
  348 |   expect(new URL(page.url()).hash).toBe('#signal-later-page')
  349 |   const restoreRequests = requests.filter((request) => request.searchParams.get('tier') === 'Signal').slice(-2)
  350 |   expect(restoreRequests.map((request) => request.searchParams.get('offset'))).toEqual(['0', '25'])
  351 |   expect(restoreRequests[0].searchParams.get('cohort_token')).toBeNull()
  352 |   expect(restoreRequests[1].searchParams.get('cohort_token')).toBe('signal-scope-token')
  353 | 
  354 |   await page.goBack()
  355 |   await expect(page.locator('[data-opportunity-id="signal-later-page"]')).toBeFocused()
  356 |   await page.goForward()
  357 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
  358 |   await page.goForward()
  359 |   await expect(page.locator('[data-opportunity-id="prospect-first-page"]')).toBeVisible()
  360 |   expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  361 | })
  362 | 
  363 | test('direct selected URL reports an exact need outside its filtered cohort without showing another record', async ({ page }) => {
  364 |   const visibleRecord = permit('visible-filtered-record', 'Visible record in the selected filter')
  365 |   const detailRequests: URL[] = []
  366 |   await page.route(apiRoute, async (route) => {
  367 |     const url = new URL(route.request().url())
  368 |     if (url.pathname === '/api/opportunities') {
  369 |       const payload = serverOpportunityPage([visibleRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  370 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: payload.headers, body: JSON.stringify(payload.items) })
  371 |       return
  372 |     }
  373 |     if (url.pathname === '/api/opportunities/needs/not-in-filtered-cohort') {
  374 |       detailRequests.push(url)
  375 |       await route.fulfill({ status: 404, json: { detail: 'Opportunity is outside the requested filtered cohort' } })
  376 |       return
  377 |     }
  378 |     const body = url.pathname === '/api/auth/session'
  379 |       ? { authenticated: true }
  380 |       : url.pathname === '/api/health'
  381 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  382 |         : []
  383 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  384 |   })
  385 | 
  386 |   await page.goto('/?tier=Signals&q=visible&activity=event-power#not-in-filtered-cohort')
  387 |   await expect(page.getByRole('alert')).toContainText(/selected opportunity is not available in this filtered cohort/i)
  388 |   await expect(page.getByRole('heading', { level: 1, name: 'Signals' })).toBeVisible()
  389 |   await expect(page.locator('[data-opportunity-id="visible-filtered-record"]')).toBeVisible()
  390 |   await expect(page.getByRole('link', { name: /not-in-filtered-cohort/ })).toHaveCount(0)
  391 |   expect(new URL(page.url()).hash).toBe('')
  392 |   expect(detailRequests).toHaveLength(1)
  393 |   expect(detailRequests[0].searchParams.get('tier')).toBe('Signal')
  394 |   expect(detailRequests[0].searchParams.get('search')).toBe('visible')
  395 |   expect(detailRequests[0].searchParams.get('activity')).toBe('event-power')
  396 |   expect(detailRequests[0].searchParams.get('cohort_token')).toBe('fixture-server-cohort')
  397 | })
  398 | 
  399 | test('direct selected URL hydrates the exact need with the restored page cohort when it moved off-page', async ({ page }) => {
  400 |   const currentPageRecord = permit('current-page-record', 'A separate current page record')
  401 |   const selectedRecord = permit('selected-off-page', 'Exact restored off-page record')
  402 |   selectedRecord.evidence[0].title = 'Citation for the restored off-page record'
  403 |   const detailRequests: URL[] = []
  404 |   const opportunityRequests: URL[] = []
  405 |   await page.route(apiRoute, async (route) => {
  406 |     const url = new URL(route.request().url())
  407 |     if (url.pathname === '/api/opportunities') {
  408 |       opportunityRequests.push(url)
  409 |       const payload = serverOpportunityPage([currentPageRecord], url.searchParams.get('decision') ?? 'ALL')
  410 |       await route.fulfill({
  411 |         status: 200,
  412 |         contentType: 'application/json',
  413 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0', 'X-Cohort-Token': 'restored-scope-token' },
  414 |         body: JSON.stringify(payload.items),
  415 |       })
  416 |       return
  417 |     }
  418 |     if (url.pathname === '/api/opportunities/needs/selected-off-page') {
  419 |       detailRequests.push(url)
  420 |       await route.fulfill({ status: 200, json: selectedRecord })
  421 |       return
  422 |     }
  423 |     const body = url.pathname === '/api/auth/session'
  424 |       ? { authenticated: true }
  425 |       : url.pathname === '/api/health'
  426 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  427 |         : []
  428 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  429 |   })
  430 | 
  431 |   await page.goto('/?tier=Signals&offset=25&activity=event-power#selected-off-page')
  432 |   await expect(page.getByRole('link', { name: 'Citation for the restored off-page record' })).toBeVisible()
  433 |   await expect(page.getByRole('link', { name: /current-page-record/ })).toHaveCount(0)
  434 |   expect(opportunityRequests.map((url) => url.searchParams.get('offset'))).toEqual(['0', '25'])
  435 |   expect(opportunityRequests[0].searchParams.get('cohort_token')).toBeNull()
  436 |   expect(opportunityRequests[1].searchParams.get('cohort_token')).toBe('restored-scope-token')
  437 |   expect(detailRequests).toHaveLength(1)
```