# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> active first-page tier click preserves ready metadata and closes its detail without refetching
- Location: tests\project_cards.spec.ts:509:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { level: 1 })

```

# Test source

```ts
  444 |   const firstSignal = permit('late-first-signal', 'First Signal page')
  445 |   const selectedSignal = permit('late-selected-signal', 'Delayed Signal detail record')
  446 |   const prospect = permit('late-prospect', 'Current Prospect destination', { tier: 'Prospect' })
  447 |   const requests: URL[] = []
  448 |   let restoreSignalPage = false
  449 |   let delayedResponseStarted = false
  450 |   let releaseDelayedResponse: (() => void) | undefined
  451 |   const delayedResponseGate = new Promise<void>((resolve) => { releaseDelayedResponse = resolve })
  452 |   await page.route(apiRoute, async (route) => {
  453 |     const url = new URL(route.request().url())
  454 |     if (url.pathname === '/api/opportunities') {
  455 |       requests.push(url)
  456 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  457 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  458 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  459 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  460 |       if (restoreSignalPage && tier === 'Signal' && offset === 25 && !delayedResponseStarted) {
  461 |         delayedResponseStarted = true
  462 |         await delayedResponseGate
  463 |       }
  464 |       await route.fulfill({
  465 |         status: 200,
  466 |         contentType: 'application/json',
  467 |         headers: {
  468 |           ...payload.headers,
  469 |           'X-Limit': '25',
  470 |           'X-Offset': String(offset),
  471 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-race-token' : 'signal-race-token',
  472 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  473 |         },
  474 |         body: JSON.stringify(payload.items),
  475 |       })
  476 |       return
  477 |     }
  478 |     const body = url.pathname === '/api/auth/session'
  479 |       ? { authenticated: true }
  480 |       : url.pathname === '/api/health'
  481 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  482 |         : url.pathname.startsWith('/api/power-needs/')
  483 |           ? { status: 'unavailable', result: null, citations: [] }
  484 |           : []
  485 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  486 |   })
  487 | 
  488 |   try {
  489 |     await page.goto('/?tier=Signals&offset=25')
  490 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
  491 |     await page.getByRole('button', { name: 'Prospects' }).click()
  492 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  493 | 
  494 |     restoreSignalPage = true
  495 |     await page.goBack()
  496 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  497 |     await page.goForward()
  498 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  499 |     releaseDelayedResponse?.()
  500 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  501 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  502 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  503 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  504 |   } finally {
  505 |     releaseDelayedResponse?.()
  506 |   }
  507 | })
  508 | 
  509 | test('active first-page tier click preserves ready metadata and closes its detail without refetching', async ({ page }) => {
  510 |   const record = permit('active-tier-ready', 'Campus facility activity')
  511 |   const requests: URL[] = []
  512 |   await page.route(apiRoute, async (route) => {
  513 |     const url = new URL(route.request().url())
  514 |     if (url.pathname === '/api/opportunities') {
  515 |       requests.push(url)
  516 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  517 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  518 |       return
  519 |     }
  520 |     const body = url.pathname === '/api/auth/session'
  521 |       ? { authenticated: true }
  522 |       : url.pathname === '/api/health'
  523 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  524 |         : url.pathname.startsWith('/api/power-needs/')
  525 |           ? { status: 'unavailable', result: null, citations: [] }
  526 |           : []
  527 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  528 |   })
  529 | 
  530 |   await page.goto('/?tier=Signals')
  531 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  532 |   const initialUrl = page.url()
  533 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  534 |   await expect(csv).toBeVisible()
  535 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  536 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  537 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  538 |   await expect(csv).toBeVisible()
  539 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  540 |   expect(page.url()).toBe(initialUrl)
  541 |   expect(requests).toHaveLength(1)
  542 | 
  543 |   await page.locator('[data-opportunity-id="active-tier-ready"]').click()
> 544 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
      |                                                         ^ Error: expect(locator).toBeVisible() failed
  545 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  546 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  547 |   await expect(csv).toBeVisible()
  548 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  549 |   expect(requests).toHaveLength(1)
  550 | })
  551 | 
  552 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  553 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  554 |   let requestCount = 0
  555 |   let releaseRequest: (() => void) | undefined
  556 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  557 |   await page.route(apiRoute, async (route) => {
  558 |     const url = new URL(route.request().url())
  559 |     if (url.pathname === '/api/opportunities') {
  560 |       requestCount += 1
  561 |       await gate
  562 |       const payload = serverOpportunityPage([record])
  563 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  564 |       return
  565 |     }
  566 |     const body = url.pathname === '/api/auth/session'
  567 |       ? { authenticated: true }
  568 |       : url.pathname === '/api/health'
  569 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  570 |         : []
  571 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  572 |   })
  573 |   try {
  574 |     await page.goto('/?tier=Signals')
  575 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  576 |     await expect.poll(() => requestCount).toBe(1)
  577 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  578 |     await page.getByRole('button', { name: 'Signals' }).click()
  579 |     releaseRequest?.()
  580 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  581 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  582 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  583 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  584 |     expect(requestCount).toBe(1)
  585 |   } finally {
  586 |     releaseRequest?.()
  587 |   }
  588 | })
  589 | 
  590 | test('active tier click from a later page fetches first-page data before showing totals', async ({ page }) => {
  591 |   const firstPageRecord = permit('active-tier-first-page', 'First-page campus activity')
  592 |   const laterPageRecord = permit('active-tier-later-page', 'Later-page campus activity')
  593 |   const requests: URL[] = []
  594 |   await page.route(apiRoute, async (route) => {
  595 |     const url = new URL(route.request().url())
  596 |     if (url.pathname === '/api/opportunities') {
  597 |       requests.push(url)
  598 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  599 |       const record = offset === 0 ? firstPageRecord : laterPageRecord
  600 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  601 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'active-tier-page-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) }, body: JSON.stringify(payload.items) })
  602 |       return
  603 |     }
  604 |     const body = url.pathname === '/api/auth/session'
  605 |       ? { authenticated: true }
  606 |       : url.pathname === '/api/health'
  607 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  608 |         : []
  609 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  610 |   })
  611 | 
  612 |   await page.goto('/?tier=Signals&offset=25')
  613 |   await expect(page.locator('[data-opportunity-id="active-tier-later-page"]')).toBeVisible()
  614 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  615 |   await expect(page.locator('[data-opportunity-id="active-tier-first-page"]')).toBeVisible()
  616 |   await expect(page.locator('[data-opportunity-id="active-tier-later-page"]')).toHaveCount(0)
  617 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  618 |   await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  619 |   expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  620 |   expect(requests.map((url) => url.searchParams.get('offset'))).toEqual(['0', '25', '0'])
  621 |   expect(requests[1].searchParams.get('cohort_token')).toBe('active-tier-page-token')
  622 |   expect(requests[2].searchParams.get('cohort_token')).toBeNull()
  623 | })
  624 | 
  625 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  626 |   const record = permit('same-decision-search', 'Campus facility activity')
  627 |   const requests: URL[] = []
  628 |   await page.route(apiRoute, async (route) => {
  629 |     const url = new URL(route.request().url())
  630 |     if (url.pathname === '/api/opportunities') {
  631 |       requests.push(url)
  632 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  633 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  634 |       return
  635 |     }
  636 |     const body = url.pathname === '/api/auth/session'
  637 |       ? { authenticated: true }
  638 |       : url.pathname === '/api/health'
  639 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  640 |         : []
  641 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  642 |   })
  643 |   await page.goto('/?tier=Signals&q=campus&activity=event-power')
  644 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
```