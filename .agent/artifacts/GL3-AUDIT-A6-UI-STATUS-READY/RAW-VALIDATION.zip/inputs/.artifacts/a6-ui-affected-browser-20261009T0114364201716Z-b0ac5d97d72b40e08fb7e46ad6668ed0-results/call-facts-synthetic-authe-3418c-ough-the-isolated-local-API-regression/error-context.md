# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: call-facts.spec.ts >> synthetic authenticated browser writes persist through the isolated local API
- Location: tests\call-facts.spec.ts:444:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Fact history version: 0')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Fact history version: 0') with timeout 5000ms
  - waiting for getByText('Fact history version: 0')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Signal · construction · REVIEW
  - heading "Synthetic UI Facility 2c0405d8" [level=1]
  - paragraph: Synthetic current retained evidence.
  - button "← Back to Signals"
  - heading "Opportunity brief" [level=2]
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - article:
    - paragraph: AI-assisted · source cited
    - heading "Concise evidence brief" [level=3]
    - text: Not generated
    - paragraph: The brief has not been generated.
    - button "Generate or retry brief"
    - region "Exact-Need facts and operator status":
      - paragraph: Current exact-Need record · separate from saved evaluation history
      - heading "Attributed facts and live workflow" [level=3]
      - paragraph: Need 144e26ae-e8a3-4654-b497-14069d8ebd9f · project ecd36292-2b58-41b6-a35a-f7325cb73cee · construction. Facts and operator status are separate from public evidence; neither a note nor a status is a qualification input.
      - region "Reported timing correction target":
        - heading "Correct reported timing" [level=4]
        - paragraph: "Correction unavailable: A current, replayable source-supported Lead is unavailable. Ordinary timing facts remain separate from any source correction."
        - paragraph: "Fact history version: 2. A timing correction needs a reason and review of the current reported dates."
      - heading "Record an attributed fact draft" [level=4]
      - text: Fact type
      - combobox "Fact type":
        - option "Activity demand" [selected]
        - option "Suitable supply"
        - option "Unsuitable supply"
        - option "Activity timing"
        - option "Buyer organization and role"
        - option "Reported closure state"
      - text: Facility
      - textbox "Facility": Test City
      - text: Reporter name
      - textbox "Reporter name"
      - text: Reporter organization
      - textbox "Reporter organization"
      - text: Reporter role
      - textbox "Reporter role"
      - text: Confirmation channel
      - textbox "Confirmation channel": phone
      - text: Reported demand (MW or bounded range)
      - textbox "Reported demand (MW or bounded range)"
      - text: Basis
      - textbox "Basis"
      - text: Source quote
      - textbox "Source quote"
      - text: Source reference
      - textbox "Source reference"
      - text: Source date
      - textbox "Source date"
      - text: Confirmed at
      - textbox "Confirmed at": 2026-10-08T20:14
      - text: Effective from
      - textbox "Effective from": 2026-10-08T20:14
      - text: Effective until (optional)
      - textbox "Effective until (optional)"
      - text: Predecessor fact version (for correction)
      - combobox "Predecessor fact version (for correction)":
        - option "No predecessor" [selected]
        - option "v2 · demand · accepted"
      - button "Save fact draft"
      - region "Attributed fact history":
        - heading "Fact history · 1 total · showing 1 · version 2" [level=4]
        - text: Reason for retraction
        - textbox "Reason for retraction"
        - article:
          - strong: demand · accepted · User-confirmed
          - paragraph: "Reported activity demand: 22 MW. · Test City · confirmed by Synthetic browser operator (role unrecorded)"
          - paragraph: "Recorded by Nick Sandoval · 10/8/2026, 8:14:04 PM · decision 2 by Nick Sandoval: Synthetic isolated API persistence verification."
          - button "Retract this accepted version" [disabled]
        - button "Newer fact versions" [disabled]
        - button "Older fact versions" [disabled]
        - button "Reload exact-Need history"
      - region "Live operator workflow status":
        - heading "Live workflow status" [level=4]
        - paragraph: "Current status: Investigating · version 1. No event is UNKNOWN, not New. Status and reason do not establish or close an evidence need."
        - text: Set operator status
        - combobox "Set operator status":
          - option "Choose status" [selected]
          - option "New"
          - option "Investigating"
          - option "Contacted"
          - option "Qualified"
          - option "Won"
          - option "Lost"
          - option "Closed"
        - text: Status reason
        - textbox "Status reason"
        - button "Save live status" [disabled]
        - list:
          - listitem: Investigating · Synthetic live status persistence verification. · Nick Sandoval · 10/8/2026, 8:14:04 PM
    - text: Signal
    - paragraph: construction
    - heading "Synthetic UI Facility 2c0405d8" [level=2]
    - paragraph: Test City
    - text: Required power
    - strong: 20 to 25 MW
    - text: Start
    - strong: 2027-01-01 to 2027-02-01
    - text: Duration
    - strong: 31 to 62 days
    - text: Suitable supply
    - strong: Insufficient
    - paragraph: Evidence-based assessment
    - paragraph: Synthetic current retained evidence.
    - paragraph: Power need is not established. A Signal does not imply a power gap.
    - region "Buying chain":
      - paragraph: Project-specific relationships
      - heading "Buying chain" [level=3]
      - button "Enrich buying chain"
      - paragraph: Organization involvement, current job role, and a person’s assignment to this project are separate claims. A relevant role does not establish purchasing authority or an open temporary-power package.
      - group: Add supporting source links
      - heading "Retained permit facts" [level=4]
      - paragraph: Permit dates describe permitting, not the power start date. Listed parties are source roles; employment, purchasing authority and an open power package require separate evidence.
      - paragraph: No supported permit fields retained for this project yet.
      - paragraph: Unlisted applicant, operator, GC, electrical contractor, EPC, engineer, named person and business contact fields remain unknown. Permit scope alone does not establish temporary load, fuel suitability, commissioning dates or an unmet supply gap.
      - paragraph: "Research status: not researched"
      - paragraph: No supported buying-chain candidates retained yet. Buyer and project contacts remain unknown.
      - list
      - group:
        - text: Unresolved questions (1)
        - list:
          - listitem: Buying chain has not been researched for this project.
      - paragraph:
        - link "Inspect retained claim history":
          - /url: /api/projects/ecd36292-2b58-41b6-a35a-f7325cb73cee/buying-chain?history=true
    - paragraph: Next action
    - paragraph: Confirm source facts with the exact facility.
    - paragraph: Source evidence
    - heading "1 record" [level=3]
    - text: "Conflicts: No conflict"
    - heading "Synthetic source filing" [level=4]:
      - link "Synthetic source filing":
        - /url: https://example.test/source
    - text: "Published 2026-10-01 Retrieved 10/7/2026, 7:00:00 PM Described event: Unknown Synthetic fixture · description synthetic-source · synthetic-a · aaaaaaaaaaaa"
    - paragraph: Test City construction filing.
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  375 |   await expect(page.getByRole('alert')).toContainText('503')
  376 |   await expect(page.getByLabel('Reporter name')).toHaveValue('Avery Chen')
  377 |   await page.getByRole('button', { name: 'Save fact draft' }).click()
  378 |   await expect(page.getByText(/Draft persisted and confirmed in this exact Need history/)).toBeVisible()
  379 |   const ambiguousPosts = ambiguous.requests.filter((request) => request.method === 'POST' && request.path === '/api/needs/need-a/facts')
  380 |   expect(ambiguousPosts).toHaveLength(2)
  381 |   expect(ambiguousPosts.map((request) => request.body?.client_id)).toEqual([ambiguousPosts[0].body?.client_id, ambiguousPosts[0].body?.client_id])
  382 |   expect(ambiguous.facts.total).toBe(1)
  383 | 
  384 |   const stalePage = await page.context().newPage()
  385 |   const stale = await installFactsFixture(stalePage, 'stale')
  386 |   await stalePage.goto('/?tier=Leads')
  387 |   await stalePage.locator('[data-opportunity-id="need-a"]').first().click()
  388 |   await stalePage.getByLabel('Reporter name').fill('Avery Chen')
  389 |   await stalePage.getByLabel('Reported demand (MW or bounded range)').fill('22')
  390 |   await stalePage.getByRole('button', { name: 'Save fact draft' }).click()
  391 |   await expect(stalePage.getByRole('alert')).toContainText('409')
  392 |   await expect(stalePage.getByLabel('Reporter name')).toHaveValue('Avery Chen')
  393 |   await stalePage.getByRole('button', { name: 'Save fact draft' }).click()
  394 |   await expect(stalePage.getByText(/Draft persisted and confirmed in this exact Need history/)).toBeVisible()
  395 |   const stalePosts = stale.requests.filter((request) => request.method === 'POST' && request.path === '/api/needs/need-a/facts')
  396 |   expect(stalePosts.map((request) => request.body?.expected_version)).toEqual([0, 1])
  397 |   expect(stalePosts[0].body?.client_id).toBe(stalePosts[1].body?.client_id)
  398 |   await stalePage.close()
  399 | })
  400 | 
  401 | test('all seven workflow filters and UNKNOWN round-trip through the browse URL', async ({ page }) => {
  402 |   const fixture = await installFactsFixture(page)
  403 |   await page.goto('/?tier=Leads&status=UNKNOWN')
  404 |   await expect(page.getByLabel('Filter by workflow status')).toHaveValue('UNKNOWN')
  405 |   for (const status of workflow) {
  406 |     const value = status.toUpperCase()
  407 |     await page.getByLabel('Filter by workflow status').selectOption(value)
  408 |     await expect.poll(() => fixture.requests.some((request) => request.path === '/api/opportunities'
  409 |       && new URL(request.url).searchParams.get('status') === value)).toBe(true)
  410 |     await expect.poll(() => new URL(page.url()).searchParams.get('status')).toBe(value)
  411 |   }
  412 |   await page.goBack()
  413 |   await expect.poll(() => page.getByLabel('Filter by workflow status').inputValue()).toBe('LOST')
  414 |   await expect.poll(() => new URL(page.url()).searchParams.get('status')).toBe('LOST')
  415 | })
  416 | 
  417 | test('fact drafts stay isolated by exact Need while navigating away and back', async ({ page }) => {
  418 |   await installFactsFixture(page)
  419 |   await page.goto('/?tier=Leads')
  420 |   await page.locator('[data-opportunity-id="need-a"]').first().click()
  421 |   await page.getByLabel('Reporter name').fill('Avery for Need A')
  422 |   await page.getByRole('button', { name: /Back to Leads/ }).click()
  423 |   await page.locator('[data-opportunity-id="need-b"]').first().click()
  424 |   await expect(page.getByLabel('Reporter name')).not.toHaveValue('Avery for Need A')
  425 |   await page.getByRole('button', { name: /Back to Leads/ }).click()
  426 |   await page.locator('[data-opportunity-id="need-a"]').first().click()
  427 |   await expect(page.getByLabel('Reporter name')).toHaveValue('Avery for Need A')
  428 | })
  429 | 
  430 | test('late fact-history response from a prior Need cannot overwrite the selected sibling', async ({ page }) => {
  431 |   const fixture = await installFactsFixture(page, 'none', true)
  432 |   await page.goto('/?tier=Leads')
  433 |   await page.locator('[data-opportunity-id="need-a"]').first().click()
  434 |   await expect.poll(() => fixture.requests.some((request) => request.path === '/api/needs/need-a/facts' && request.method === 'GET')).toBe(true)
  435 |   await page.getByRole('button', { name: /Back to Leads/ }).click()
  436 |   await page.locator('[data-opportunity-id="need-b"]').first().click()
  437 |   await expect(page.getByText(/Need need-b · project project-a/)).toBeVisible()
  438 |   await expect(page.getByText(/Correction unavailable: A current, replayable source-supported Lead is unavailable/)).toBeVisible()
  439 |   await page.waitForTimeout(1000)
  440 |   await expect(page.getByText(/Need need-b · project project-a/)).toBeVisible()
  441 |   await expect(page.getByText(/earliest possible start 2027-01-01/)).toHaveCount(0)
  442 | })
  443 | 
  444 | test('synthetic authenticated browser writes persist through the isolated local API', async ({ page }) => {
  445 |   const needId = process.env.A6_UI_PERSISTED_NEED_ID
  446 |   const projectId = process.env.A6_UI_PERSISTED_PROJECT_ID
  447 |   const facility = process.env.A6_UI_PERSISTED_NAME
  448 |   const password = process.env.A6_UI_PERSISTED_PASSWORD
  449 |   test.skip(!needId || !projectId || !facility || !password, 'requires the explicitly seeded disposable UI application database')
  450 |   const item = { ...opportunity(needId!), project_id: projectId!, name: facility!, tier: 'Signal' }
  451 |   const readCurrentNeed = async () => page.evaluate(async (selectedNeedId) => {
  452 |     const response = await fetch(`/api/opportunities/needs/${encodeURIComponent(selectedNeedId)}?tier=Signal&search=&decision=ALL`, { credentials: 'include' })
  453 |     if (!response.ok) throw new Error(`Selected Need read-back failed with ${response.status}`)
  454 |     return response.json() as Promise<Opportunity>
  455 |   }, needId!)
  456 |   await page.route('**/api/opportunities*', async (route) => {
  457 |     if (new URL(route.request().url()).pathname !== '/api/opportunities') return route.continue()
  458 |     return route.fulfill({ json: [item], headers: {
  459 |       'X-Total-Count': '1', 'X-Group-Total-Count': '1', 'X-Page-Record-Count': '1', 'X-Page-Group-Count': '1',
  460 |       'X-Limit': '50', 'X-Offset': '0', 'X-Cohort-Token': 'synthetic-browser-only-cohort',
  461 |       'X-Decision-Counts': '{"SHOW":0,"REVIEW":0,"HOLD":0}',
  462 |     } })
  463 |   })
  464 |   await page.route('**/api/health', (route) => route.fulfill({ json: { sources: [], backlog: 0, pending_interpretations: 0 } }))
  465 |   await page.route('**/api/changes', (route) => route.fulfill({ json: [] }))
  466 |   await page.goto('/?tier=Signals')
  467 |   await page.getByLabel('Password').fill(password!)
  468 |   await page.getByRole('button', { name: 'Continue' }).click()
  469 |   await page.locator(`[data-opportunity-id="${needId}"]`).click()
  470 |   await expect(page.getByText(new RegExp(`Need ${needId} · project ${projectId}`))).toBeVisible()
  471 |   const selectedNeedBefore = await readCurrentNeed()
  472 |   expect(selectedNeedBefore.tier).toBe('Signal')
  473 |   const beforeDecision = selectedNeedBefore
  474 |   expect(beforeDecision.tier).toBe('Signal')
> 475 |   await expect(page.getByText('Fact history version: 0')).toBeVisible()
      |                                                           ^ Error: expect(locator).toBeVisible() failed
  476 |   await page.getByLabel('Reporter name').fill('Synthetic browser operator')
  477 |   await page.getByLabel('Reported demand (MW or bounded range)').fill('22')
  478 |   await page.getByRole('button', { name: 'Save fact draft' }).click()
  479 |   await expect(page.getByText(/Draft persisted and confirmed in this exact Need history/)).toBeVisible()
  480 |   await page.getByLabel('Reason for decision').fill('Synthetic isolated API persistence verification.')
  481 |   await page.getByRole('button', { name: 'Accept fact' }).click()
  482 |   await expect(page.getByText(/Server read-back confirmed accepted version 2/)).toBeVisible()
  483 |   const afterFact = await readCurrentNeed()
  484 |   expect(afterFact.tier).toBe(beforeDecision.tier)
  485 |   await expect(page.getByText('Fact history version: 2')).toBeVisible()
  486 |   await page.getByLabel('Set operator status').selectOption('Investigating')
  487 |   await page.getByLabel('Status reason').fill('Synthetic live status persistence verification.')
  488 |   await page.getByRole('button', { name: 'Save live status' }).click()
  489 |   await expect(page.getByText(/Live operator status Investigating was read back at version 1/)).toBeVisible()
  490 |   const afterStatus = await readCurrentNeed()
  491 |   expect(afterStatus.tier).toBe(beforeDecision.tier)
  492 |   await expect(page.getByText(/Status and reason do not qualify the Need/)).toBeVisible()
  493 | })
  494 | 
```