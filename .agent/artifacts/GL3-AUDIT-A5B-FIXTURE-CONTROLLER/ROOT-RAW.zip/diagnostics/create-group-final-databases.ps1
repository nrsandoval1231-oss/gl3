$ErrorActionPreference='Stop'
$taskPsql='C:/Program Files/PostgreSQL/18/bin/psql.exe'
$taskNames=@('gl3audit_a5b_group_final_test','gl3audit_a5b_group_final_migration','gl3audit_a5b_group_final_browser')
foreach($taskDatabase in $taskNames){
 $taskLog=Join-Path $PSScriptRoot "root-group-$taskDatabase-zero-tables.log"
 if(Test-Path -LiteralPath $taskLog){throw 'Refusing bootstrap log overwrite'}
 $taskPresent=& $taskPsql -h 127.0.0.1 -p 55437 -U gl3audit -d postgres -At -c "SELECT count(*) FROM pg_database WHERE datname='$taskDatabase';"
 if($LASTEXITCODE -ne 0 -or $taskPresent -ne '0'){throw 'Disposable name not proven absent'}
 & 'C:/Program Files/PostgreSQL/18/bin/createdb.exe' -h 127.0.0.1 -p 55437 -U gl3audit $taskDatabase
 if($LASTEXITCODE -ne 0){throw 'Create failed; no blind retry'}
 & $taskPsql -h 127.0.0.1 -p 55437 -U gl3audit -d $taskDatabase -At -c "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';" *> $taskLog
 if($LASTEXITCODE -ne 0){throw 'Empty catalog proof failed'}
 Get-Content -LiteralPath $taskLog
}


