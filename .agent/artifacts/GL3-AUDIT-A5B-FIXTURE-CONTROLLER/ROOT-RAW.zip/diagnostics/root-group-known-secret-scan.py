"""No application imports. Never prints or persists known credential values."""
import json
import io
import os
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]

def extended(path):
    value = str(path.absolute())
    return Path("\\\\?\\" + value) if os.name == "nt" and not value.startswith("\\\\?\\") else path

filesystem_root = extended(root)
parent = root.parent / "gl3-audit-repair-20261007"
output = Path(sys.argv[1])
if output.exists():
    raise RuntimeError("Refusing overwrite")
known = [os.environ.get(key, "") for key in ("FIRECRAWL_API_KEY", "OPENAI_API_KEY", "TYPESAFE_API_KEY")]
for line in (parent / ".env").read_text().splitlines():
    if line.startswith(("APP_PASSWORD_HASH=", "SESSION_SECRET=")):
        known.append(line.split("=", 1)[1])
auth = (parent / ".artifacts/local-auth.txt").read_text().splitlines()
if len(auth) > 1:
    known.append(auth[1])
needles = set()
short_values = 0
for value in known:
    if value and len(value) < 8:
        short_values += 1
    if len(value) >= 8:
        for representation in (value, json.dumps(value)[1:-1]):
            needles.update((representation.encode(), representation.encode("utf-16-le")))
        if len(value) >= 40:
            for fragment in (value[:24], value[-24:]):
                needles.update((fragment.encode(), fragment.encode("utf-16-le")))
hits = []
scanned = 0
def scan(label, data):
    global scanned
    scanned += 1
    if any(needle in data for needle in needles):
        hits.append(label)
    if data.startswith(b"PK") and zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as nested:
            for entry in nested.infolist():
                if not entry.is_dir():
                    scan(label + ":nested:" + entry.filename, nested.read(entry))
def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])
base = "fb65ceb70a58c5c8d7f414a4b46cc7e3aa9e2f39"
commits = git("rev-list", f"{base}..HEAD").decode().splitlines()
for commit in commits:
    paths = git("diff-tree", "--no-commit-id", "--name-only", "-r", commit).decode().splitlines()
    for path in paths:
        if subprocess.run(["git", "-C", str(root), "cat-file", "-e", f"{commit}:{path}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            scan(f"git:{commit}:{path}", git("show", f"{commit}:{path}"))
for directory in (root / "backend/src", root / "backend/tests", root / "web/src", root / "web/test-results", root / ".artifacts", root / ".agent/artifacts"):
    for path in extended(directory).rglob("*"):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix in {".pyc", ".gz"}:
            continue
        label = str(path.relative_to(filesystem_root))
        if path.suffix == ".zip":
            with zipfile.ZipFile(path) as archive:
                for entry in archive.infolist():
                    if not entry.is_dir():
                        scan(f"zip:{label}:{entry.filename}", archive.read(entry))
        elif path.stat().st_size < 10_000_000:
            scan(label, path.read_bytes())
report = {"scope": "Current task source/diagnostics, all new commit changed blobs, unpacked proof ZIP entries; tool history excluded", "head": git("rev-parse", "HEAD").decode().strip(), "commits": len(commits), "entries_scanned": scanned, "known_secret_match_files": hits, "short_known_values_not_scanned": short_values, "unretained_tool_incident_bytes": "UNKNOWN"}
with output.open("x") as target:
    json.dump(report, target, indent=2)
print(json.dumps(report))
raise SystemExit(bool(hits))

