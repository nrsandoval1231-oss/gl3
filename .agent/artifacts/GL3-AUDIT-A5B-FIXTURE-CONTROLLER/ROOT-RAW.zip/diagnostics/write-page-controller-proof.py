import json
import re
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / '.agent/artifacts/GL3-AUDIT-A5B-PAGE-CONTROLLER'
manifest = json.loads((out / 'TESTED-SOURCE-MANIFEST.json').read_text())
head = manifest['tested_head']
tree = subprocess.check_output(['git', '-C', str(root), 'rev-parse', head + '^{tree}'], text=True).strip()
def receipt(prefix):
    paths = list((root / '.artifacts').glob(prefix + '-*-python.log'))
    assert len(paths) == 1, paths
    return json.loads(paths[0].read_text().strip().splitlines()[-1])
backend_text = (root / '.artifacts/root-page-final-full.log').read_text()
backend = re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', backend_text)
assert backend
browser_text = (root / '.artifacts/root-page-final-browser.log').read_text()
browser = re.search(r'(\d+) passed \(([\d.]+)s\)', browser_text)
assert browser
commercial = receipt('root-page-final-commercial')
public = receipt('root-page-final-public')
traversal = receipt('root-page-final-traversal')
completion = {
    'node': 'GL3-AUDIT-A5B page-transition repair', 'state': 'DETERMINISTIC_PASS_REVIEW_PENDING',
    'tested_head': head, 'tested_tree': tree,
    'backend': {'passed': int(backend[1]), 'skipped': int(backend[2]), 'warnings': int(backend[3]), 'seconds': float(backend[4])},
    'browser': {'passed': int(browser[1]), 'seconds': float(browser[2]), 'ports_closed': [55523, 55524]},
    'static_contract_migration_dependency_gates': 'PASS',
    'retained_records': 1167, 'retained_opportunity_groups': 1149, 'retained_pages': 24,
    'commercial_measurements': commercial, 'public_measurements': public,
    'traversal': traversal, 'original_column_scope_table_differences': 0,
    'integration_repair_packets': 6, 'independent_acceptance': 'PENDING', 'parent_objective': 'OPEN',
    'model': 'UNKNOWN', 'config_identity': 'UNKNOWN', 'tokens': 'UNKNOWN', 'elapsed_to_accepted': 'UNKNOWN',
    'authority': 'Draft publication after independent acceptance only; no merge, deployment, paid activation, external messages or original application-data mutation'
}
with (out / 'COMPLETION.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(completion, f, indent=2)
gates = f'''# A5B page-transition repair — root gates, independent acceptance pending

Tested HEAD {head} / tree {tree}. The source/test/migration/workflow/dependency manifest binds exact tested bytes. Builder completion and focused proof are in GL3-AUDIT-A5B-PAGE-TRANSITION-REPAIR. Four prior independent FIX receipts and all prior candidate proofs remain negative evidence, not acceptance.

This slice enforces requested-page versus held-page identity across both paging directions and Back/forward, pending/failed replacement requests and stale responses. No-op controls must preserve valid page metadata and matching requests; exact selected-need intent, token bootstrap and 409 handling remain required. Product/test ownership is App.tsx/project_cards.spec.ts; any strictly necessary client change is identified in the builder completion. No backend policy, migration, auth or styling change is authorized by this repair.

Root backend: {backend[1]} passed, {backend[2]} environmental skips, {backend[3]} warnings, {backend[4]} seconds. Browser: {browser[1]} passed, {browser[2]} seconds. Mandatory Ruff including backend scripts, mypy src, web typecheck/build, exact OpenAPI, fresh/repeat/drift migration and locked dependency audits passed. Fresh root-only disposable databases and ports 55523/55524 were isolated; ports closed after browser completion. Existing optional NC access-probe and Windows symlink skips/deprecations remain documented. The earlier exploratory test-tree typing failure is not a whole-test-tree typing PASS. No A7 visual acceptance is claimed.

Read-only retained stream matches 1,167 records, 1,149 public groups, exact membership/titles/decisions and 17 searches. All 24 pages match exact order, counts, group metadata and tokens with no duplicates. Commercial grouping remains separately 1,144 groups. Quiet matched commercial/public receipts in COMPLETION.json preserve exact SQL, latency, allocation, response bytes and hashes. Each handler remains below 200 SQL. Distinct workloads; first process does not evict database/disk cache, Python allocation is not RSS, handler bytes are not compressed HTTP, no production SLO/speedup. Navigation bootstrap and one scoped off-page selected-need request are outside single-handler measurements.

All 24 original-column fingerprints match accepted after-0016 baseline; preserved dump SHA256 828beace65cd2b06182f30e4713857656a993d3969c8cbecb02e6ee40ff8a886 remains unchanged. Thirteen builder log/trace hashes independently match. A first root manifest reader assumed the prior packet schema and failed an assertion before reading files; the corrected recursive reader passed and both logs are retained. Builder output-path/preflight/test-assertion mistakes and their limits are preserved in its raw manifest. Raw archive preserves all available diagnostics and native fixtures without private configuration/corpus payloads. Prior overwritten native traces and unretained bootstrap/path/tool-fragment bytes remain UNKNOWN. The prior wrong Python-runtime fingerprint failure and corrected locked-runtime result are preserved. Known-secret scans recursively unpack proof/native ZIPs; tool history is excluded, no removal claim. Prior root Markdown newline bookkeeping failure was repaired before the preceding freeze; original archived state bytes remain unchanged.

Six distinct integration-repair packets are retained. Measured command times/raw UTC logs govern timing; model/config/tokens and elapsed-to-accepted remain UNKNOWN unless separately evidenced. Independent exact-candidate review is PENDING. A6 facts/seven-state workflow/functional UI/bulk status, A7 original PNG/HTML, A8 operations/recovery and real feed/quality/seven-day/customer Lead gates remain OPEN. UNKNOWN-only status is partial, not a waiver. No parent completion, merge, deployment, paid activation or external communication.
'''
with (out / 'GATES.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write(gates)
for name in ('CURRENT_STATE.md', 'WORK_GRAPH.md'):
    old = (root / '.artifacts/a5b-page-controller-before' / (name + '.bin')).read_bytes().decode('utf-8').replace('\r', '')
    prefix = f'# Current page-transition repair frontier — October 8, 2026\n\nA5A accepted / draft PR40 / recorded CI PASS. Four prior A5B independent FIX receipts are preserved. Tested {head} passes root {backend[1]} backend tests ({backend[2]} environmental skips), {browser[1]} browser tests and mandatory gates, retained parity and query bounds. Exact proof: .agent/artifacts/GL3-AUDIT-A5B-PAGE-CONTROLLER. Fresh independent review PENDING; A5B is not accepted or published. Supersedes earlier pending states below.\n\nDirection VALIDATE exact proof descendant. A6 facts/workflow → functional UI/bulk status → A8 remain dependent; A7 original assets and real launch gates OPEN. UNKNOWN-only status is partial. Parent OPEN. No original data mutation, merge, deploy, paid activation or external messages.\n\n## Historical checkpoints\n\n'
    (root / '.agent' / name).write_bytes((prefix + old).encode('utf-8'))
print(json.dumps({'docs_written': True, 'review': 'PENDING', 'tested_head': head}))
