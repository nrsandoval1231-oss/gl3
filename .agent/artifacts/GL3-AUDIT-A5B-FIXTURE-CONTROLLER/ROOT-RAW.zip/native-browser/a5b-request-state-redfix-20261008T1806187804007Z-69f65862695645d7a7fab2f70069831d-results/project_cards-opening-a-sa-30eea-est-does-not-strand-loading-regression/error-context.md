# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> opening a same-cohort record during a pending Back page request does not strand loading
- Location: tests\project_cards.spec.ts:594:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('Updating this view…')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByText('Updating this view…') with timeout 5000ms
  - waiting for getByText('Updating this view…')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - generic [ref=e18]:
        - paragraph [ref=e19]: Signal · event power · SHOW
        - heading "Campus Facility Activity" [level=1] [ref=e20]
        - paragraph [ref=e21]: Permit reports a dated powered event activity; temporary rental power is a question to investigate.
      - button "← Back to Signals" [ref=e22] [cursor=pointer]
    - generic [ref=e23]:
      - heading "Opportunity brief" [level=2] [ref=e25]
      - generic [ref=e26]:
        - generic [ref=e27]: Search projects
        - textbox "Search projects" [ref=e28]:
          - /placeholder: Search projects, work, or permit ID
    - status [ref=e29]: Updating this view…
    - article [ref=e30]:
      - generic [ref=e31]:
        - generic [ref=e32]:
          - generic [ref=e33]:
            - paragraph [ref=e34]: AI-assisted · source cited
            - heading "Concise evidence brief" [level=3] [ref=e35]
          - generic [ref=e36]: Not generated
        - paragraph [ref=e37]: The brief has not been generated.
        - button "Generate or retry brief" [ref=e38] [cursor=pointer]
      - generic [ref=e39]:
        - generic [ref=e40]:
          - generic [ref=e41]: Signal
          - paragraph [ref=e42]: event power
          - heading "Campus Facility Activity" [level=2] [ref=e43]
          - paragraph [ref=e44]: 2100 BARTON SPRINGS RD, AUSTIN, TX
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: Required power
            - strong [ref=e48]: Unknown
          - generic [ref=e49]:
            - generic [ref=e50]: Start
            - strong [ref=e51]: Unknown
          - generic [ref=e52]:
            - generic [ref=e53]: Duration
            - strong [ref=e54]: Unknown
          - generic [ref=e55]:
            - generic [ref=e56]: Suitable supply
            - strong [ref=e57]: Unknown
      - generic [ref=e58]:
        - paragraph [ref=e59]: Evidence-based assessment
        - paragraph [ref=e60]: Permit reports a dated powered event activity; temporary rental power is a question to investigate.
        - paragraph [ref=e61]: "Supported subject: AUSTIN permit open-during-refresh · Campus facility activity"
        - paragraph [ref=e62]: Power need is not established. A Signal does not imply a power gap.
      - generic [ref=e63]:
        - paragraph [ref=e64]: Next action
        - paragraph [ref=e65]: Confirm activity power needs, timing, duration, and service plan.
      - generic [ref=e66]:
        - generic [ref=e67]:
          - generic [ref=e68]:
            - paragraph [ref=e69]: Source evidence
            - heading "1 record" [level=3] [ref=e70]
          - generic [ref=e71]: "Conflicts: Not assessed"
        - generic [ref=e72]:
          - heading [level=4] [ref=e73]:
            - link "Austin building permit open-during-refresh" [ref=e74] [cursor=pointer]:
              - /url: https://example.invalid/open-during-refresh
          - generic [ref=e75]:
            - generic [ref=e76]: Permit issue date unknown · source publication time unknown
            - generic [ref=e77]: Retrieved 9/27/2026, 7:00:00 AM
            - generic [ref=e78]: "Permit event date: Unknown"
            - generic [ref=e79]: Official permit · description
            - generic [ref=e80]: austin-building-permits · open-during-refresh · hash-open-du
          - paragraph [ref=e81]: Campus facility activity
      - generic [ref=e82]:
        - heading "Still unknown" [level=3] [ref=e83]
        - list [ref=e84]:
          - listitem [ref=e85]: Activity-specific power requirement
          - listitem [ref=e86]: Suitable utility supply
          - listitem [ref=e87]: Start window
          - listitem [ref=e88]: Duration
    - generic [ref=e89]:
      - button "← Previous" [disabled] [ref=e90]
      - button "Next →" [disabled] [ref=e91]
  - contentinfo [ref=e92]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  530 |   let releaseRequest: (() => void) | undefined
  531 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  532 |   await page.route(apiRoute, async (route) => {
  533 |     const url = new URL(route.request().url())
  534 |     if (url.pathname === '/api/opportunities') {
  535 |       requestStarted = true
  536 |       await gate
  537 |       const payload = serverOpportunityPage([record])
  538 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  539 |       return
  540 |     }
  541 |     const body = url.pathname === '/api/auth/session'
  542 |       ? { authenticated: true }
  543 |       : url.pathname === '/api/health'
  544 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  545 |         : []
  546 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  547 |   })
  548 |   try {
  549 |     await page.goto('/?tier=Signals')
  550 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  551 |     await expect.poll(() => requestStarted).toBe(true)
  552 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  553 |     await page.getByRole('button', { name: 'Signals' }).click()
  554 |     releaseRequest?.()
  555 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  556 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  557 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  558 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  559 |   } finally {
  560 |     releaseRequest?.()
  561 |   }
  562 | })
  563 | 
  564 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  565 |   const record = permit('same-decision-search', 'Campus facility activity')
  566 |   const requests: URL[] = []
  567 |   await page.route(apiRoute, async (route) => {
  568 |     const url = new URL(route.request().url())
  569 |     if (url.pathname === '/api/opportunities') {
  570 |       requests.push(url)
  571 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  572 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  573 |       return
  574 |     }
  575 |     const body = url.pathname === '/api/auth/session'
  576 |       ? { authenticated: true }
  577 |       : url.pathname === '/api/health'
  578 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  579 |         : []
  580 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  581 |   })
  582 |   await page.goto('/?tier=Signals&q=campus')
  583 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
  584 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  585 |   await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  586 |   await expect(csv).toBeVisible()
  587 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  588 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  589 |   await expect(csv).toBeVisible()
  590 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  591 |   expect(requests).toHaveLength(1)
  592 | })
  593 | 
  594 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  595 |   const record = permit('open-during-refresh', 'Campus facility activity')
  596 |   let opportunityRequests = 0
  597 |   let secondRequestStarted = false
  598 |   let releaseSecondRequest: (() => void) | undefined
  599 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  600 |   await page.route(apiRoute, async (route) => {
  601 |     const url = new URL(route.request().url())
  602 |     if (url.pathname === '/api/opportunities') {
  603 |       opportunityRequests += 1
  604 |       if (opportunityRequests === 2) {
  605 |         secondRequestStarted = true
  606 |         await secondRequestGate
  607 |       }
  608 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  609 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  610 |       return
  611 |     }
  612 |     const body = url.pathname === '/api/auth/session'
  613 |       ? { authenticated: true }
  614 |       : url.pathname === '/api/health'
  615 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  616 |         : url.pathname.startsWith('/api/power-needs/')
  617 |           ? { status: 'unavailable', result: null, citations: [] }
  618 |           : []
  619 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  620 |   })
  621 |   try {
  622 |     await page.goto('/?tier=Signals')
  623 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  624 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  625 |     await expect.poll(() => secondRequestStarted).toBe(true)
  626 |     await expect(page.locator('[data-opportunity-id="open-during-refresh"]')).toBeVisible()
  627 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  628 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  629 |     releaseSecondRequest?.()
> 630 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
      |                                                         ^ Error: expect(locator).toHaveCount(expected) failed
  631 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  632 |   } finally {
  633 |     releaseSecondRequest?.()
  634 |   }
  635 | })
  636 | 
  637 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  638 |   const record = permit('roles', 'Facility construction', {
  639 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  640 |   })
  641 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  642 |   record.evidence[0].assessment_current = false
  643 |   expect(projectTitle(record)).not.toContain('Owner Company')
  644 | })
  645 | 
  646 | test('city permit company title shows source role and does not infer ownership', () => {
  647 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  648 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  649 |   })
  650 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  651 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  652 | 
  653 |   const houston = permit('houston-1', 'Commercial facility construction')
  654 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  655 |   houston.title_company_role = 'permit-listed owner / occupant'
  656 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  657 | })
  658 | 
  659 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  660 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  661 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  662 |   })
  663 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  664 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  665 | 
  666 |   const houston = permit('houston-1', 'Commercial facility construction')
  667 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  668 |   houston.title_company_role = 'permit-listed owner / occupant'
  669 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  670 | })
  671 | 
  672 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  673 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  674 |     projectId: 'dallas-campus',
  675 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  676 |   })
  677 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  678 |     projectId: 'dallas-campus',
  679 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  680 |   })
  681 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  682 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  683 |   const records = [keeter, merichem]
  684 |   await page.route(apiRoute, async (route) => {
  685 |     const path = new URL(route.request().url()).pathname
  686 |     if (path === '/api/opportunities') {
  687 |       await fulfillServerOpportunityPage(route, records)
  688 |       return
  689 |     }
  690 |     const body = path === '/api/auth/session'
  691 |       ? { authenticated: true }
  692 |       : path === '/api/health'
  693 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  694 |           : []
  695 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  696 |   })
  697 |   await page.goto('/?tier=Signals')
  698 |   await page.getByRole('button', { name: /KEETER INVESTMENTS LLC · LP Business Name · role unverified/ }).click()
  699 |   const keeterMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000129"]')
  700 |   const merichemMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000130"]')
  701 |   await expect(keeterMember).toContainText('KEETER INVESTMENTS LLC · LP Business Name · role unverified')
  702 |   await expect(merichemMember).toContainText('MERICHEM TECHNOLOGIES LLC · owner')
  703 |   await keeterMember.click()
  704 |   await expect(page.getByRole('heading', { level: 1, name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified' })).toBeVisible()
  705 |   await expect(page.getByText('COM-NEW-26-000129', { exact: false }).first()).toBeVisible()
  706 | })
  707 | 
  708 | test('Signals default to All and keep SHOW, REVIEW, and HOLD selectable', async ({ page }) => {
  709 |   let records = [
  710 |     permit('hold-member', 'Routine hospital maintenance', { projectId: 'shared-project', decision: 'HOLD' }),
  711 |     permit('show-member', 'New data center electrical buildout', { projectId: 'shared-project', decision: 'SHOW' }),
  712 |     permit('review', 'Possible industrial expansion', { projectId: 'review-project', decision: 'REVIEW' }),
  713 |     permit('hold', 'Marathon temporary stage', { projectId: 'hold-project', decision: 'HOLD' }),
  714 |     permit('unknown', 'Unadjudicated project', { projectId: 'unknown-project', decision: null }),
  715 |   ]
  716 |   await page.route(apiRoute, async (route) => {
  717 |     const path = new URL(route.request().url()).pathname
  718 |     if (path === '/api/opportunities') {
  719 |       await fulfillServerOpportunityPage(route, records)
  720 |       return
  721 |     }
  722 |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  723 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  724 |   })
  725 |   await page.goto('/?tier=Signals')
  726 |   await expect(page.getByRole('button', { name: 'All 4' })).toHaveAttribute('aria-pressed', 'true')
  727 |   await expect(page.getByRole('button', { name: /Possible Industrial Expansion/ })).toBeVisible()
  728 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
  729 |   await page.getByRole('button', { name: 'SHOW 1' }).click()
  730 |   const sharedProject = page.getByRole('button', { name: /New Data Center Electrical Buildout/ })
```