# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> Previous hides later-page rows and metadata until the first-page request settles
- Location: tests\project_cards.spec.ts:819:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-opportunity-id="transition-later-page"]')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-opportunity-id="transition-later-page"]') with timeout 5000ms
  - waiting for locator('[data-opportunity-id="transition-later-page"]')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - generic [ref=e19]:
        - paragraph [ref=e20]: Evidence-led project discovery
        - heading "Signals" [level=1] [ref=e21]
        - paragraph [ref=e22]: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Today
          - strong [ref=e26]: 0 material changes
        - generic [ref=e27]: No material opportunity changes today.
    - generic [ref=e28]:
      - generic [ref=e29]:
        - heading "Signals · 1 filtered project cards · 1 filtered opportunity records" [level=2] [ref=e30]
        - paragraph [ref=e31]: All · 1 cards and 1 records on this page of 1 filtered cards and 1 records. SHOW means worth investigating, not qualified.
      - generic [ref=e32]:
        - generic [ref=e33]: Search projects
        - textbox "Search projects" [ref=e34]:
          - /placeholder: Search projects, work, or permit ID
      - link "Download filtered CSV" [ref=e35] [cursor=pointer]:
        - /url: /api/opportunities/export.csv?tier=Signal&search=&decision=ALL&cohort_token=transition-token
    - generic "Filter opportunity records" [ref=e36]:
      - generic [ref=e37]:
        - text: Geography
        - combobox "Select unknown geography" [ref=e38]:
          - option "Any exact location" [selected]
          - option "Unknown"
        - textbox "Filter by exact geography" [ref=e39]:
          - /placeholder: Exact stored location
      - generic [ref=e40]:
        - text: Industry
        - combobox "Select unknown industry" [ref=e41]:
          - option "Any exact asset type" [selected]
          - option "Unknown"
        - textbox "Filter by exact project asset type" [ref=e42]:
          - /placeholder: Exact stored asset type
      - generic [ref=e43]:
        - text: Activity
        - combobox "Select unknown activity" [ref=e44]:
          - option "Any exact activity" [selected]
          - option "Unknown"
        - textbox "Filter by exact power activity" [ref=e45]:
          - /placeholder: Exact stored activity
      - generic [ref=e46]:
        - text: Timing
        - combobox "Filter by supported timing availability" [ref=e47]:
          - option "Any timing" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e48]:
        - text: Required MW
        - combobox "Filter by required MW availability" [ref=e49]:
          - option "Any MW status" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e50]:
        - text: MW minimum
        - textbox "Minimum overlapping required MW" [ref=e51]:
          - /placeholder: MW minimum
      - generic [ref=e52]:
        - text: MW maximum
        - textbox "Maximum overlapping required MW" [ref=e53]:
          - /placeholder: MW maximum
      - generic [ref=e54]:
        - text: Priority
        - combobox "Filter by canonical priority segment" [ref=e55]:
          - option "Any priority" [selected]
          - option "Segment 0"
          - option "Segment 1"
          - option "Segment 2"
          - option "Segment 3"
          - option "Segment 4"
          - option "Segment 5"
          - option "Segment 6"
          - option "Segment 7"
          - option "Segment 8"
      - generic [ref=e56]:
        - text: Workflow status
        - combobox "Filter by workflow status" [ref=e57]:
          - option "Any status" [selected]
          - option "Unknown"
    - group "Filter Signals by review decision" [ref=e58]:
      - button "All 1" [pressed] [ref=e59] [cursor=pointer]
      - button "SHOW 1" [ref=e60] [cursor=pointer]
      - button "REVIEW 0" [ref=e61] [cursor=pointer]
      - button "HOLD 0" [ref=e62] [cursor=pointer]
    - status [ref=e63]: Updating this view…
    - 'button "First Page Transition Fixture 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal" [ref=e66] [cursor=pointer]':
      - generic [ref=e68]:
        - strong [ref=e69]: First Page Transition Fixture
        - generic [ref=e70]: 2100 BARTON SPRINGS RD, AUSTIN, TX
      - generic [ref=e71]:
        - strong [ref=e73]: "Decision: SHOW"
        - generic [ref=e74]: Signal
      - generic [aria-hidden] [ref=e75]: →
    - generic [ref=e76]:
      - generic [ref=e77]: 1 filtered records · page 1
      - button "← Previous" [disabled] [ref=e78]
      - button "Next →" [disabled] [ref=e79]
  - contentinfo [ref=e80]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  760 |   try {
  761 |     await page.goto('/?view=ingestion')
  762 |     await expect(page.getByRole('button', { name: 'Ingestion' })).toBeVisible()
  763 |     await expect.poll(() => requestStarted).toBe(true)
  764 |     await page.getByRole('button', { name: 'Ingestion' }).click()
  765 |     releaseRequest?.()
  766 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  767 |     await expect(page.getByRole('heading', { name: 'No retained source items' })).toBeVisible()
  768 |   } finally {
  769 |     releaseRequest?.()
  770 |   }
  771 | })
  772 | 
  773 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  774 |   const record = permit('open-during-refresh-a', 'First campus facility activity')
  775 |   const nextRecord = permit('open-during-refresh-b', 'Second campus facility activity')
  776 |   let opportunityRequests = 0
  777 |   let secondRequestStarted = false
  778 |   let releaseSecondRequest: (() => void) | undefined
  779 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  780 |   await page.route(apiRoute, async (route) => {
  781 |     const url = new URL(route.request().url())
  782 |     if (url.pathname === '/api/opportunities') {
  783 |       opportunityRequests += 1
  784 |       if (opportunityRequests === 2) {
  785 |         secondRequestStarted = true
  786 |         await secondRequestGate
  787 |       }
  788 |       const payload = serverOpportunityPage([record, nextRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  789 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  790 |       return
  791 |     }
  792 |     const body = url.pathname === '/api/auth/session'
  793 |       ? { authenticated: true }
  794 |       : url.pathname === '/api/health'
  795 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  796 |         : url.pathname.startsWith('/api/power-needs/')
  797 |           ? { status: 'unavailable', result: null, citations: [] }
  798 |           : []
  799 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  800 |   })
  801 |   try {
  802 |     await page.goto('/?tier=Signals')
  803 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  804 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  805 |     await expect.poll(() => secondRequestStarted).toBe(true)
  806 |     await expect(page.locator('[data-opportunity-id="open-during-refresh-a"]')).toBeVisible()
  807 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  808 |     await expect(page.getByRole('button', { name: 'Next →' })).toBeEnabled()
  809 |     await page.getByRole('button', { name: 'Next →' }).click()
  810 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  811 |     releaseSecondRequest?.()
  812 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  813 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  814 |   } finally {
  815 |     releaseSecondRequest?.()
  816 |   }
  817 | })
  818 | 
  819 | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  820 |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  821 |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  822 |   let pageZeroRequests = 0
  823 |   let releasePrevious: (() => void) | undefined
  824 |   let previousStarted = false
  825 |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  826 |   await page.route(apiRoute, async (route) => {
  827 |     const url = new URL(route.request().url())
  828 |     if (url.pathname === '/api/opportunities') {
  829 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  830 |       if (offset === 0) {
  831 |         pageZeroRequests += 1
  832 |         if (pageZeroRequests > 1) {
  833 |           previousStarted = true
  834 |           await previousGate
  835 |         }
  836 |       }
  837 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  838 |       await route.fulfill({
  839 |         status: 200,
  840 |         contentType: 'application/json',
  841 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  842 |         body: JSON.stringify(payload.items),
  843 |       })
  844 |       return
  845 |     }
  846 |     const path = url.pathname
  847 |     const body = path === '/api/auth/session'
  848 |       ? { authenticated: true }
  849 |       : path === '/api/health'
  850 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  851 |         : []
  852 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  853 |   })
  854 |   try {
  855 |     await page.goto('/?tier=Signals&offset=25')
  856 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toBeVisible()
  857 |     await page.getByRole('button', { name: '← Previous' }).click()
  858 |     await expect.poll(() => previousStarted).toBe(true)
  859 |     await expect(page.getByText('Updating this view…')).toBeVisible()
> 860 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toHaveCount(0)
      |                                                                                 ^ Error: expect(locator).toHaveCount(expected) failed
  861 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  862 |     await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  863 |     expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  864 |     expect(new URL(page.url()).hash).toBe('')
  865 |     releasePrevious?.()
  866 |     await expect(page.locator('[data-opportunity-id="transition-first-page"]')).toBeVisible()
  867 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  868 |     await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  869 |   } finally {
  870 |     releasePrevious?.()
  871 |   }
  872 | })
  873 | 
  874 | test('failed Previous clears the later page and reports unavailable instead of an empty cohort', async ({ page }) => {
  875 |   const laterPageRecord = permit('transition-error-later-page', 'Later page error fixture')
  876 |   let pageZeroRequests = 0
  877 |   await page.route(apiRoute, async (route) => {
  878 |     const url = new URL(route.request().url())
  879 |     if (url.pathname === '/api/opportunities') {
  880 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  881 |       if (offset === 0 && ++pageZeroRequests > 1) {
  882 |         await route.fulfill({ status: 503, json: { detail: 'First page unavailable for transition test' } })
  883 |         return
  884 |       }
  885 |       const payload = serverOpportunityPage([laterPageRecord])
  886 |       await route.fulfill({
  887 |         status: 200,
  888 |         contentType: 'application/json',
  889 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-error-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  890 |         body: JSON.stringify(payload.items),
  891 |       })
  892 |       return
  893 |     }
  894 |     const path = url.pathname
  895 |     const body = path === '/api/auth/session'
  896 |       ? { authenticated: true }
  897 |       : path === '/api/health'
  898 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  899 |         : []
  900 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  901 |   })
  902 |   await page.goto('/?tier=Signals&offset=25')
  903 |   await expect(page.locator('[data-opportunity-id="transition-error-later-page"]')).toBeVisible()
  904 |   await page.getByRole('button', { name: '← Previous' }).click()
  905 |   await expect(page.getByRole('alert')).toContainText('First page unavailable for transition test')
  906 |   await expect(page.locator('[data-opportunity-id="transition-error-later-page"]')).toHaveCount(0)
  907 |   await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  908 |   await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  909 |   await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  910 |   expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  911 |   expect(new URL(page.url()).hash).toBe('')
  912 | })
  913 | 
  914 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  915 |   const record = permit('roles', 'Facility construction', {
  916 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  917 |   })
  918 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  919 |   record.evidence[0].assessment_current = false
  920 |   expect(projectTitle(record)).not.toContain('Owner Company')
  921 | })
  922 | 
  923 | test('city permit company title shows source role and does not infer ownership', () => {
  924 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  925 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  926 |   })
  927 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  928 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  929 | 
  930 |   const houston = permit('houston-1', 'Commercial facility construction')
  931 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  932 |   houston.title_company_role = 'permit-listed owner / occupant'
  933 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  934 | })
  935 | 
  936 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  937 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  938 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  939 |   })
  940 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  941 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  942 | 
  943 |   const houston = permit('houston-1', 'Commercial facility construction')
  944 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  945 |   houston.title_company_role = 'permit-listed owner / occupant'
  946 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  947 | })
  948 | 
  949 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  950 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  951 |     projectId: 'dallas-campus',
  952 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  953 |   })
  954 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  955 |     projectId: 'dallas-campus',
  956 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  957 |   })
  958 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  959 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  960 |   const records = [keeter, merichem]
```