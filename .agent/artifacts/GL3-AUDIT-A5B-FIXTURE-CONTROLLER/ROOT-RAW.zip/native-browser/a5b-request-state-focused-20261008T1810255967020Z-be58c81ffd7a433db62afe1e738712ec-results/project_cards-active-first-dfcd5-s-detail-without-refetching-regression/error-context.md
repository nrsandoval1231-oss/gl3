# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> active first-page tier click preserves ready metadata and closes its detail without refetching
- Location: tests\project_cards.spec.ts:484:1

# Error details

```
Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Signals' }) resolved to 2 elements:
    1) <button class="nav-active" aria-current="page">Signals</button> aka getByRole('button', { name: 'Signals', exact: true })
    2) <button class="back-button">← Back to Signals</button> aka getByRole('button', { name: '← Back to Signals' })

Call log:
  - waiting for getByRole('button', { name: 'Signals' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - generic [ref=e18]:
        - paragraph [ref=e19]: Signal · event power · SHOW
        - heading "Campus Facility Activity" [level=1] [ref=e20]
        - paragraph [ref=e21]: Permit reports a dated powered event activity; temporary rental power is a question to investigate.
      - button "← Back to Signals" [ref=e22] [cursor=pointer]
    - generic [ref=e23]:
      - heading "Opportunity brief" [level=2] [ref=e25]
      - generic [ref=e26]:
        - generic [ref=e27]: Search projects
        - textbox "Search projects" [ref=e28]:
          - /placeholder: Search projects, work, or permit ID
    - article [ref=e29]:
      - generic [ref=e30]:
        - generic [ref=e31]:
          - generic [ref=e32]:
            - paragraph [ref=e33]: AI-assisted · source cited
            - heading "Concise evidence brief" [level=3] [ref=e34]
          - generic [ref=e35]: Not generated
        - paragraph [ref=e36]: The brief has not been generated.
        - button "Generate or retry brief" [ref=e37] [cursor=pointer]
      - generic [ref=e38]:
        - generic [ref=e39]:
          - generic [ref=e40]: Signal
          - paragraph [ref=e41]: event power
          - heading "Campus Facility Activity" [level=2] [ref=e42]
          - paragraph [ref=e43]: 2100 BARTON SPRINGS RD, AUSTIN, TX
        - generic [ref=e44]:
          - generic [ref=e45]:
            - generic [ref=e46]: Required power
            - strong [ref=e47]: Unknown
          - generic [ref=e48]:
            - generic [ref=e49]: Start
            - strong [ref=e50]: Unknown
          - generic [ref=e51]:
            - generic [ref=e52]: Duration
            - strong [ref=e53]: Unknown
          - generic [ref=e54]:
            - generic [ref=e55]: Suitable supply
            - strong [ref=e56]: Unknown
      - generic [ref=e57]:
        - paragraph [ref=e58]: Evidence-based assessment
        - paragraph [ref=e59]: Permit reports a dated powered event activity; temporary rental power is a question to investigate.
        - paragraph [ref=e60]: "Supported subject: AUSTIN permit active-tier-ready · Campus facility activity"
        - paragraph [ref=e61]: Power need is not established. A Signal does not imply a power gap.
      - generic [ref=e62]:
        - paragraph [ref=e63]: Next action
        - paragraph [ref=e64]: Confirm activity power needs, timing, duration, and service plan.
      - generic [ref=e65]:
        - generic [ref=e66]:
          - generic [ref=e67]:
            - paragraph [ref=e68]: Source evidence
            - heading "1 record" [level=3] [ref=e69]
          - generic [ref=e70]: "Conflicts: Not assessed"
        - generic [ref=e71]:
          - heading [level=4] [ref=e72]:
            - link "Austin building permit active-tier-ready" [ref=e73] [cursor=pointer]:
              - /url: https://example.invalid/active-tier-ready
          - generic [ref=e74]:
            - generic [ref=e75]: Permit issue date unknown · source publication time unknown
            - generic [ref=e76]: Retrieved 9/27/2026, 7:00:00 AM
            - generic [ref=e77]: "Permit event date: Unknown"
            - generic [ref=e78]: Official permit · description
            - generic [ref=e79]: austin-building-permits · active-tier-ready · hash-active-
          - paragraph [ref=e80]: Campus facility activity
      - generic [ref=e81]:
        - heading "Still unknown" [level=3] [ref=e82]
        - list [ref=e83]:
          - listitem [ref=e84]: Activity-specific power requirement
          - listitem [ref=e85]: Suitable utility supply
          - listitem [ref=e86]: Start window
          - listitem [ref=e87]: Duration
    - generic [ref=e88]:
      - button "← Previous" [disabled] [ref=e89]
      - button "Next →" [disabled] [ref=e90]
  - contentinfo [ref=e91]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  420 |   const selectedSignal = permit('late-selected-signal', 'Delayed Signal detail record')
  421 |   const prospect = permit('late-prospect', 'Current Prospect destination', { tier: 'Prospect' })
  422 |   const requests: URL[] = []
  423 |   let restoreSignalPage = false
  424 |   let delayedResponseStarted = false
  425 |   let releaseDelayedResponse: (() => void) | undefined
  426 |   const delayedResponseGate = new Promise<void>((resolve) => { releaseDelayedResponse = resolve })
  427 |   await page.route(apiRoute, async (route) => {
  428 |     const url = new URL(route.request().url())
  429 |     if (url.pathname === '/api/opportunities') {
  430 |       requests.push(url)
  431 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  432 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  433 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  434 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  435 |       if (restoreSignalPage && tier === 'Signal' && offset === 25 && !delayedResponseStarted) {
  436 |         delayedResponseStarted = true
  437 |         await delayedResponseGate
  438 |       }
  439 |       await route.fulfill({
  440 |         status: 200,
  441 |         contentType: 'application/json',
  442 |         headers: {
  443 |           ...payload.headers,
  444 |           'X-Limit': '25',
  445 |           'X-Offset': String(offset),
  446 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-race-token' : 'signal-race-token',
  447 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  448 |         },
  449 |         body: JSON.stringify(payload.items),
  450 |       })
  451 |       return
  452 |     }
  453 |     const body = url.pathname === '/api/auth/session'
  454 |       ? { authenticated: true }
  455 |       : url.pathname === '/api/health'
  456 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  457 |         : url.pathname.startsWith('/api/power-needs/')
  458 |           ? { status: 'unavailable', result: null, citations: [] }
  459 |           : []
  460 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  461 |   })
  462 | 
  463 |   try {
  464 |     await page.goto('/?tier=Signals&offset=25')
  465 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
  466 |     await page.getByRole('button', { name: 'Prospects' }).click()
  467 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  468 | 
  469 |     restoreSignalPage = true
  470 |     await page.goBack()
  471 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  472 |     await page.goForward()
  473 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  474 |     releaseDelayedResponse?.()
  475 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  476 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  477 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  478 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  479 |   } finally {
  480 |     releaseDelayedResponse?.()
  481 |   }
  482 | })
  483 | 
  484 | test('active first-page tier click preserves ready metadata and closes its detail without refetching', async ({ page }) => {
  485 |   const record = permit('active-tier-ready', 'Campus facility activity')
  486 |   const requests: URL[] = []
  487 |   await page.route(apiRoute, async (route) => {
  488 |     const url = new URL(route.request().url())
  489 |     if (url.pathname === '/api/opportunities') {
  490 |       requests.push(url)
  491 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  492 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  493 |       return
  494 |     }
  495 |     const body = url.pathname === '/api/auth/session'
  496 |       ? { authenticated: true }
  497 |       : url.pathname === '/api/health'
  498 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  499 |         : url.pathname.startsWith('/api/power-needs/')
  500 |           ? { status: 'unavailable', result: null, citations: [] }
  501 |           : []
  502 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  503 |   })
  504 | 
  505 |   await page.goto('/?tier=Signals')
  506 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  507 |   const initialUrl = page.url()
  508 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  509 |   await expect(csv).toBeVisible()
  510 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  511 |   await page.getByRole('button', { name: 'Signals' }).click()
  512 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  513 |   await expect(csv).toBeVisible()
  514 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  515 |   expect(page.url()).toBe(initialUrl)
  516 |   expect(requests).toHaveLength(1)
  517 | 
  518 |   await page.locator('[data-opportunity-id="active-tier-ready"]').click()
  519 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
> 520 |   await page.getByRole('button', { name: 'Signals' }).click()
      |                                                       ^ Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Signals' }) resolved to 2 elements:
  521 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  522 |   await expect(csv).toBeVisible()
  523 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  524 |   expect(requests).toHaveLength(1)
  525 | })
  526 | 
  527 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  528 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  529 |   let requestStarted = false
  530 |   let releaseRequest: (() => void) | undefined
  531 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  532 |   await page.route(apiRoute, async (route) => {
  533 |     const url = new URL(route.request().url())
  534 |     if (url.pathname === '/api/opportunities') {
  535 |       requestStarted = true
  536 |       await gate
  537 |       const payload = serverOpportunityPage([record])
  538 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  539 |       return
  540 |     }
  541 |     const body = url.pathname === '/api/auth/session'
  542 |       ? { authenticated: true }
  543 |       : url.pathname === '/api/health'
  544 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  545 |         : []
  546 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  547 |   })
  548 |   try {
  549 |     await page.goto('/?tier=Signals')
  550 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  551 |     await expect.poll(() => requestStarted).toBe(true)
  552 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  553 |     await page.getByRole('button', { name: 'Signals' }).click()
  554 |     releaseRequest?.()
  555 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  556 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  557 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  558 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  559 |   } finally {
  560 |     releaseRequest?.()
  561 |   }
  562 | })
  563 | 
  564 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  565 |   const record = permit('same-decision-search', 'Campus facility activity')
  566 |   const requests: URL[] = []
  567 |   await page.route(apiRoute, async (route) => {
  568 |     const url = new URL(route.request().url())
  569 |     if (url.pathname === '/api/opportunities') {
  570 |       requests.push(url)
  571 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  572 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  573 |       return
  574 |     }
  575 |     const body = url.pathname === '/api/auth/session'
  576 |       ? { authenticated: true }
  577 |       : url.pathname === '/api/health'
  578 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  579 |         : []
  580 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  581 |   })
  582 |   await page.goto('/?tier=Signals&q=campus&activity=event-power')
  583 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
  584 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  585 |   await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  586 |   await expect(csv).toBeVisible()
  587 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  588 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  589 |   await expect(csv).toBeVisible()
  590 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  591 |   await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  592 |   await expect(csv).toBeVisible()
  593 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  594 |   expect(requests).toHaveLength(1)
  595 | })
  596 | 
  597 | test('active decision and unchanged activity filter during page load preserve the request', async ({ page }) => {
  598 |   const record = permit('same-controls-pending', 'Campus facility activity')
  599 |   let requestStarted = false
  600 |   let releaseRequest: (() => void) | undefined
  601 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  602 |   await page.route(apiRoute, async (route) => {
  603 |     const url = new URL(route.request().url())
  604 |     if (url.pathname === '/api/opportunities') {
  605 |       requestStarted = true
  606 |       await gate
  607 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  608 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  609 |       return
  610 |     }
  611 |     const body = url.pathname === '/api/auth/session'
  612 |       ? { authenticated: true }
  613 |       : url.pathname === '/api/health'
  614 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  615 |         : []
  616 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  617 |   })
  618 |   try {
  619 |     await page.goto('/?tier=Signals&activity=event-power')
  620 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
```