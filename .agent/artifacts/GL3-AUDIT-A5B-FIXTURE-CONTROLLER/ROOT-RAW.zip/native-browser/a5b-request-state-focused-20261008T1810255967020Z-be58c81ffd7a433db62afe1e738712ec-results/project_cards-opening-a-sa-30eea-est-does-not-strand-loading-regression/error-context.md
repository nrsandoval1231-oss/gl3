# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> opening a same-cohort record during a pending Back page request does not strand loading
- Location: tests\project_cards.spec.ts:737:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('heading', { level: 1 })
Expected substring: "open-during-refresh-b"
Received string:    "Second Campus Facility Activity"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('heading', { level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { level: 1 })
    14 × locator resolved to <h1>Second Campus Facility Activity</h1>
       - unexpected value "Second Campus Facility Activity"

```

```yaml
- heading "Second Campus Facility Activity" [level=1]
```

# Test source

```ts
  674 |   await page.route(apiRoute, async (route) => {
  675 |     const url = new URL(route.request().url())
  676 |     if (url.pathname === '/api/opportunities') {
  677 |       requests.push(url)
  678 |       await gate
  679 |       const payload = serverOpportunityPage([record])
  680 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  681 |       return
  682 |     }
  683 |     const body = url.pathname === '/api/auth/session'
  684 |       ? { authenticated: true }
  685 |       : url.pathname === '/api/health'
  686 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  687 |         : []
  688 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  689 |   })
  690 |   try {
  691 |     await page.goto('/?tier=Signals&activity=event-power')
  692 |     await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('event-power')
  693 |     await expect.poll(() => requests.length).toBe(1)
  694 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  695 |     await page.waitForTimeout(100)
  696 |     expect(requests).toHaveLength(1)
  697 |     releaseRequest?.()
  698 |     await expect(page.locator('[data-opportunity-id="same-filter-pending"]')).toBeVisible()
  699 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  700 |   } finally {
  701 |     releaseRequest?.()
  702 |   }
  703 | })
  704 | 
  705 | test('clicking the active ingestion view during its request does not strand loading', async ({ page }) => {
  706 |   let requestStarted = false
  707 |   let releaseRequest: (() => void) | undefined
  708 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  709 |   await page.route(apiRoute, async (route) => {
  710 |     const url = new URL(route.request().url())
  711 |     if (url.pathname === '/api/ingestion') {
  712 |       requestStarted = true
  713 |       await gate
  714 |       await route.fulfill({ status: 200, json: { items: [], total: 0, limit: 25, offset: 0 } })
  715 |       return
  716 |     }
  717 |     const body = url.pathname === '/api/auth/session'
  718 |       ? { authenticated: true }
  719 |       : url.pathname === '/api/health'
  720 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  721 |         : []
  722 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  723 |   })
  724 |   try {
  725 |     await page.goto('/?view=ingestion')
  726 |     await expect(page.getByRole('button', { name: 'Ingestion' })).toBeVisible()
  727 |     await expect.poll(() => requestStarted).toBe(true)
  728 |     await page.getByRole('button', { name: 'Ingestion' }).click()
  729 |     releaseRequest?.()
  730 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  731 |     await expect(page.getByRole('heading', { name: 'No retained source items' })).toBeVisible()
  732 |   } finally {
  733 |     releaseRequest?.()
  734 |   }
  735 | })
  736 | 
  737 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  738 |   const record = permit('open-during-refresh-a', 'First campus facility activity')
  739 |   const nextRecord = permit('open-during-refresh-b', 'Second campus facility activity')
  740 |   let opportunityRequests = 0
  741 |   let secondRequestStarted = false
  742 |   let releaseSecondRequest: (() => void) | undefined
  743 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  744 |   await page.route(apiRoute, async (route) => {
  745 |     const url = new URL(route.request().url())
  746 |     if (url.pathname === '/api/opportunities') {
  747 |       opportunityRequests += 1
  748 |       if (opportunityRequests === 2) {
  749 |         secondRequestStarted = true
  750 |         await secondRequestGate
  751 |       }
  752 |       const payload = serverOpportunityPage([record, nextRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  753 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  754 |       return
  755 |     }
  756 |     const body = url.pathname === '/api/auth/session'
  757 |       ? { authenticated: true }
  758 |       : url.pathname === '/api/health'
  759 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  760 |         : url.pathname.startsWith('/api/power-needs/')
  761 |           ? { status: 'unavailable', result: null, citations: [] }
  762 |           : []
  763 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  764 |   })
  765 |   try {
  766 |     await page.goto('/?tier=Signals')
  767 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  768 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  769 |     await expect.poll(() => secondRequestStarted).toBe(true)
  770 |     await expect(page.locator('[data-opportunity-id="open-during-refresh-a"]')).toBeVisible()
  771 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  772 |     await expect(page.getByRole('button', { name: 'Next →' })).toBeEnabled()
  773 |     await page.getByRole('button', { name: 'Next →' }).click()
> 774 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('open-during-refresh-b')
      |                                                           ^ Error: expect(locator).toContainText(expected) failed
  775 |     releaseSecondRequest?.()
  776 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  777 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('open-during-refresh-b')
  778 |   } finally {
  779 |     releaseSecondRequest?.()
  780 |   }
  781 | })
  782 | 
  783 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  784 |   const record = permit('roles', 'Facility construction', {
  785 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  786 |   })
  787 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  788 |   record.evidence[0].assessment_current = false
  789 |   expect(projectTitle(record)).not.toContain('Owner Company')
  790 | })
  791 | 
  792 | test('city permit company title shows source role and does not infer ownership', () => {
  793 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  794 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  795 |   })
  796 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  797 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  798 | 
  799 |   const houston = permit('houston-1', 'Commercial facility construction')
  800 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  801 |   houston.title_company_role = 'permit-listed owner / occupant'
  802 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  803 | })
  804 | 
  805 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  806 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  807 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  808 |   })
  809 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  810 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  811 | 
  812 |   const houston = permit('houston-1', 'Commercial facility construction')
  813 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  814 |   houston.title_company_role = 'permit-listed owner / occupant'
  815 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  816 | })
  817 | 
  818 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  819 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  820 |     projectId: 'dallas-campus',
  821 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  822 |   })
  823 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  824 |     projectId: 'dallas-campus',
  825 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  826 |   })
  827 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  828 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  829 |   const records = [keeter, merichem]
  830 |   await page.route(apiRoute, async (route) => {
  831 |     const path = new URL(route.request().url()).pathname
  832 |     if (path === '/api/opportunities') {
  833 |       await fulfillServerOpportunityPage(route, records)
  834 |       return
  835 |     }
  836 |     const body = path === '/api/auth/session'
  837 |       ? { authenticated: true }
  838 |       : path === '/api/health'
  839 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  840 |           : []
  841 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  842 |   })
  843 |   await page.goto('/?tier=Signals')
  844 |   await page.getByRole('button', { name: /KEETER INVESTMENTS LLC · LP Business Name · role unverified/ }).click()
  845 |   const keeterMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000129"]')
  846 |   const merichemMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000130"]')
  847 |   await expect(keeterMember).toContainText('KEETER INVESTMENTS LLC · LP Business Name · role unverified')
  848 |   await expect(merichemMember).toContainText('MERICHEM TECHNOLOGIES LLC · owner')
  849 |   await keeterMember.click()
  850 |   await expect(page.getByRole('heading', { level: 1, name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified' })).toBeVisible()
  851 |   await expect(page.getByText('COM-NEW-26-000129', { exact: false }).first()).toBeVisible()
  852 | })
  853 | 
  854 | test('Signals default to All and keep SHOW, REVIEW, and HOLD selectable', async ({ page }) => {
  855 |   let records = [
  856 |     permit('hold-member', 'Routine hospital maintenance', { projectId: 'shared-project', decision: 'HOLD' }),
  857 |     permit('show-member', 'New data center electrical buildout', { projectId: 'shared-project', decision: 'SHOW' }),
  858 |     permit('review', 'Possible industrial expansion', { projectId: 'review-project', decision: 'REVIEW' }),
  859 |     permit('hold', 'Marathon temporary stage', { projectId: 'hold-project', decision: 'HOLD' }),
  860 |     permit('unknown', 'Unadjudicated project', { projectId: 'unknown-project', decision: null }),
  861 |   ]
  862 |   await page.route(apiRoute, async (route) => {
  863 |     const path = new URL(route.request().url()).pathname
  864 |     if (path === '/api/opportunities') {
  865 |       await fulfillServerOpportunityPage(route, records)
  866 |       return
  867 |     }
  868 |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  869 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  870 |   })
  871 |   await page.goto('/?tier=Signals')
  872 |   await expect(page.getByRole('button', { name: 'All 4' })).toHaveAttribute('aria-pressed', 'true')
  873 |   await expect(page.getByRole('button', { name: /Possible Industrial Expansion/ })).toBeVisible()
  874 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
```