# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> active decision and unchanged activity filter during page load preserve the request
- Location: tests\project_cards.spec.ts:597:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-opportunity-id="same-controls-pending"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('[data-opportunity-id="same-controls-pending"]') with timeout 5000ms
  - waiting for locator('[data-opportunity-id="same-controls-pending"]')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Signals" [level=1]
  - paragraph: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Signals · 0 filtered project cards · 0 filtered opportunity records" [level=2]
  - paragraph: All · 0 cards and 0 records on this page of 0 filtered cards and 0 records. SHOW means worth investigating, not qualified.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
    - text: event-power
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - group "Filter Signals by review decision":
    - button "All 0" [pressed]
    - button "SHOW 0"
    - button "REVIEW 0"
    - button "HOLD 0"
  - status: Updating this view…
  - text: 0 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  525 | })
  526 | 
  527 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  528 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  529 |   let requestStarted = false
  530 |   let releaseRequest: (() => void) | undefined
  531 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  532 |   await page.route(apiRoute, async (route) => {
  533 |     const url = new URL(route.request().url())
  534 |     if (url.pathname === '/api/opportunities') {
  535 |       requestStarted = true
  536 |       await gate
  537 |       const payload = serverOpportunityPage([record])
  538 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  539 |       return
  540 |     }
  541 |     const body = url.pathname === '/api/auth/session'
  542 |       ? { authenticated: true }
  543 |       : url.pathname === '/api/health'
  544 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  545 |         : []
  546 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  547 |   })
  548 |   try {
  549 |     await page.goto('/?tier=Signals')
  550 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  551 |     await expect.poll(() => requestStarted).toBe(true)
  552 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  553 |     await page.getByRole('button', { name: 'Signals' }).click()
  554 |     releaseRequest?.()
  555 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  556 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  557 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  558 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  559 |   } finally {
  560 |     releaseRequest?.()
  561 |   }
  562 | })
  563 | 
  564 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  565 |   const record = permit('same-decision-search', 'Campus facility activity')
  566 |   const requests: URL[] = []
  567 |   await page.route(apiRoute, async (route) => {
  568 |     const url = new URL(route.request().url())
  569 |     if (url.pathname === '/api/opportunities') {
  570 |       requests.push(url)
  571 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  572 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  573 |       return
  574 |     }
  575 |     const body = url.pathname === '/api/auth/session'
  576 |       ? { authenticated: true }
  577 |       : url.pathname === '/api/health'
  578 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  579 |         : []
  580 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  581 |   })
  582 |   await page.goto('/?tier=Signals&q=campus&activity=event-power')
  583 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
  584 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  585 |   await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  586 |   await expect(csv).toBeVisible()
  587 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  588 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  589 |   await expect(csv).toBeVisible()
  590 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  591 |   await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  592 |   await expect(csv).toBeVisible()
  593 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  594 |   expect(requests).toHaveLength(1)
  595 | })
  596 | 
  597 | test('active decision and unchanged activity filter during page load preserve the request', async ({ page }) => {
  598 |   const record = permit('same-controls-pending', 'Campus facility activity')
  599 |   let requestStarted = false
  600 |   let releaseRequest: (() => void) | undefined
  601 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  602 |   await page.route(apiRoute, async (route) => {
  603 |     const url = new URL(route.request().url())
  604 |     if (url.pathname === '/api/opportunities') {
  605 |       requestStarted = true
  606 |       await gate
  607 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  608 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  609 |       return
  610 |     }
  611 |     const body = url.pathname === '/api/auth/session'
  612 |       ? { authenticated: true }
  613 |       : url.pathname === '/api/health'
  614 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  615 |         : []
  616 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  617 |   })
  618 |   try {
  619 |     await page.goto('/?tier=Signals&activity=event-power')
  620 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  621 |     await expect.poll(() => requestStarted).toBe(true)
  622 |     await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  623 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  624 |     releaseRequest?.()
> 625 |     await expect(page.locator('[data-opportunity-id="same-controls-pending"]')).toBeVisible()
      |                                                                                 ^ Error: expect(locator).toBeVisible() failed
  626 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  627 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  628 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  629 |   } finally {
  630 |     releaseRequest?.()
  631 |   }
  632 | })
  633 | 
  634 | test('unchanged search during page load does not cancel its terminal response', async ({ page }) => {
  635 |   const record = permit('same-search-pending', 'Campus facility activity')
  636 |   let requestStarted = false
  637 |   let releaseRequest: (() => void) | undefined
  638 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  639 |   await page.route(apiRoute, async (route) => {
  640 |     const url = new URL(route.request().url())
  641 |     if (url.pathname === '/api/opportunities') {
  642 |       requestStarted = true
  643 |       await gate
  644 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  645 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  646 |       return
  647 |     }
  648 |     const body = url.pathname === '/api/auth/session'
  649 |       ? { authenticated: true }
  650 |       : url.pathname === '/api/health'
  651 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  652 |         : []
  653 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  654 |   })
  655 |   try {
  656 |     await page.goto('/?tier=Signals&q=campus')
  657 |     await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  658 |     await expect.poll(() => requestStarted).toBe(true)
  659 |     await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  660 |     releaseRequest?.()
  661 |     await expect(page.locator('[data-opportunity-id="same-search-pending"]')).toBeVisible()
  662 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  663 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  664 |   } finally {
  665 |     releaseRequest?.()
  666 |   }
  667 | })
  668 | 
  669 | test('clicking the active ingestion view during its request does not strand loading', async ({ page }) => {
  670 |   let requestStarted = false
  671 |   let releaseRequest: (() => void) | undefined
  672 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  673 |   await page.route(apiRoute, async (route) => {
  674 |     const url = new URL(route.request().url())
  675 |     if (url.pathname === '/api/ingestion') {
  676 |       requestStarted = true
  677 |       await gate
  678 |       await route.fulfill({ status: 200, json: { items: [], total: 0, limit: 25, offset: 0 } })
  679 |       return
  680 |     }
  681 |     const body = url.pathname === '/api/auth/session'
  682 |       ? { authenticated: true }
  683 |       : url.pathname === '/api/health'
  684 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  685 |         : []
  686 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  687 |   })
  688 |   try {
  689 |     await page.goto('/?view=ingestion')
  690 |     await expect(page.getByRole('button', { name: 'Ingestion' })).toBeVisible()
  691 |     await expect.poll(() => requestStarted).toBe(true)
  692 |     await page.getByRole('button', { name: 'Ingestion' }).click()
  693 |     releaseRequest?.()
  694 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  695 |     await expect(page.getByRole('heading', { name: 'No retained source items' })).toBeVisible()
  696 |   } finally {
  697 |     releaseRequest?.()
  698 |   }
  699 | })
  700 | 
  701 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  702 |   const record = permit('open-during-refresh', 'Campus facility activity')
  703 |   let opportunityRequests = 0
  704 |   let secondRequestStarted = false
  705 |   let releaseSecondRequest: (() => void) | undefined
  706 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  707 |   await page.route(apiRoute, async (route) => {
  708 |     const url = new URL(route.request().url())
  709 |     if (url.pathname === '/api/opportunities') {
  710 |       opportunityRequests += 1
  711 |       if (opportunityRequests === 2) {
  712 |         secondRequestStarted = true
  713 |         await secondRequestGate
  714 |       }
  715 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  716 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  717 |       return
  718 |     }
  719 |     const body = url.pathname === '/api/auth/session'
  720 |       ? { authenticated: true }
  721 |       : url.pathname === '/api/health'
  722 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  723 |         : url.pathname.startsWith('/api/power-needs/')
  724 |           ? { status: 'unavailable', result: null, citations: [] }
  725 |           : []
```