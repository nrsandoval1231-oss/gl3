# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> clicking the active ingestion view during its request does not strand loading
- Location: tests\project_cards.spec.ts:669:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('Updating this view…')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByText('Updating this view…') with timeout 5000ms
  - waiting for getByText('Updating this view…')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [active] [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e18]:
      - paragraph [ref=e19]: Retained evidence · Publisher and government sources
      - heading "Ingestion inbox" [level=1] [ref=e20]
      - paragraph [ref=e21]: Permits are primary project discovery; news is supplemental. Source evidence and qualification stay visible. City permit coverage is regional and limited to a rolling issue-date window.
    - generic [ref=e22]:
      - generic [ref=e23]:
        - text: Source
        - combobox "Filter by source" [ref=e24]:
          - option "All sources" [selected]
      - generic [ref=e25]:
        - text: Source sector
        - combobox "Filter by source sector" [ref=e26]:
          - option "All source sectors" [selected]
          - option "Data centers"
          - option "Energy & utilities"
          - option "Oil & gas"
          - option "Industrial & manufacturing"
          - option "Construction & facilities"
          - option "Healthcare"
          - option "Cannabis"
          - option "Mining"
          - option "Infrastructure"
      - generic [ref=e27]: 0 retained items · page 1
    - status [ref=e28]: Updating this view…
    - generic [ref=e29]:
      - button "← Previous" [disabled] [ref=e30]
      - button "Next →" [disabled] [ref=e31]
  - contentinfo [ref=e32]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  594 |   expect(requests).toHaveLength(1)
  595 | })
  596 | 
  597 | test('active decision and unchanged activity filter during page load preserve the request', async ({ page }) => {
  598 |   const record = permit('same-controls-pending', 'Campus facility activity')
  599 |   let requestStarted = false
  600 |   let releaseRequest: (() => void) | undefined
  601 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  602 |   await page.route(apiRoute, async (route) => {
  603 |     const url = new URL(route.request().url())
  604 |     if (url.pathname === '/api/opportunities') {
  605 |       requestStarted = true
  606 |       await gate
  607 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  608 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  609 |       return
  610 |     }
  611 |     const body = url.pathname === '/api/auth/session'
  612 |       ? { authenticated: true }
  613 |       : url.pathname === '/api/health'
  614 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  615 |         : []
  616 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  617 |   })
  618 |   try {
  619 |     await page.goto('/?tier=Signals&activity=event-power')
  620 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  621 |     await expect.poll(() => requestStarted).toBe(true)
  622 |     await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  623 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('event-power')
  624 |     releaseRequest?.()
  625 |     await expect(page.locator('[data-opportunity-id="same-controls-pending"]')).toBeVisible()
  626 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  627 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  628 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  629 |   } finally {
  630 |     releaseRequest?.()
  631 |   }
  632 | })
  633 | 
  634 | test('unchanged search during page load does not cancel its terminal response', async ({ page }) => {
  635 |   const record = permit('same-search-pending', 'Campus facility activity')
  636 |   let requestStarted = false
  637 |   let releaseRequest: (() => void) | undefined
  638 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  639 |   await page.route(apiRoute, async (route) => {
  640 |     const url = new URL(route.request().url())
  641 |     if (url.pathname === '/api/opportunities') {
  642 |       requestStarted = true
  643 |       await gate
  644 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  645 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  646 |       return
  647 |     }
  648 |     const body = url.pathname === '/api/auth/session'
  649 |       ? { authenticated: true }
  650 |       : url.pathname === '/api/health'
  651 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  652 |         : []
  653 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  654 |   })
  655 |   try {
  656 |     await page.goto('/?tier=Signals&q=campus')
  657 |     await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  658 |     await expect.poll(() => requestStarted).toBe(true)
  659 |     await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  660 |     releaseRequest?.()
  661 |     await expect(page.locator('[data-opportunity-id="same-search-pending"]')).toBeVisible()
  662 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  663 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  664 |   } finally {
  665 |     releaseRequest?.()
  666 |   }
  667 | })
  668 | 
  669 | test('clicking the active ingestion view during its request does not strand loading', async ({ page }) => {
  670 |   let requestStarted = false
  671 |   let releaseRequest: (() => void) | undefined
  672 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  673 |   await page.route(apiRoute, async (route) => {
  674 |     const url = new URL(route.request().url())
  675 |     if (url.pathname === '/api/ingestion') {
  676 |       requestStarted = true
  677 |       await gate
  678 |       await route.fulfill({ status: 200, json: { items: [], total: 0, limit: 25, offset: 0 } })
  679 |       return
  680 |     }
  681 |     const body = url.pathname === '/api/auth/session'
  682 |       ? { authenticated: true }
  683 |       : url.pathname === '/api/health'
  684 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  685 |         : []
  686 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  687 |   })
  688 |   try {
  689 |     await page.goto('/?view=ingestion')
  690 |     await expect(page.getByRole('button', { name: 'Ingestion' })).toBeVisible()
  691 |     await expect.poll(() => requestStarted).toBe(true)
  692 |     await page.getByRole('button', { name: 'Ingestion' }).click()
  693 |     releaseRequest?.()
> 694 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
      |                                                         ^ Error: expect(locator).toHaveCount(expected) failed
  695 |     await expect(page.getByRole('heading', { name: 'No retained source items' })).toBeVisible()
  696 |   } finally {
  697 |     releaseRequest?.()
  698 |   }
  699 | })
  700 | 
  701 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  702 |   const record = permit('open-during-refresh', 'Campus facility activity')
  703 |   let opportunityRequests = 0
  704 |   let secondRequestStarted = false
  705 |   let releaseSecondRequest: (() => void) | undefined
  706 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  707 |   await page.route(apiRoute, async (route) => {
  708 |     const url = new URL(route.request().url())
  709 |     if (url.pathname === '/api/opportunities') {
  710 |       opportunityRequests += 1
  711 |       if (opportunityRequests === 2) {
  712 |         secondRequestStarted = true
  713 |         await secondRequestGate
  714 |       }
  715 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  716 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  717 |       return
  718 |     }
  719 |     const body = url.pathname === '/api/auth/session'
  720 |       ? { authenticated: true }
  721 |       : url.pathname === '/api/health'
  722 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  723 |         : url.pathname.startsWith('/api/power-needs/')
  724 |           ? { status: 'unavailable', result: null, citations: [] }
  725 |           : []
  726 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  727 |   })
  728 |   try {
  729 |     await page.goto('/?tier=Signals')
  730 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  731 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  732 |     await expect.poll(() => secondRequestStarted).toBe(true)
  733 |     await expect(page.locator('[data-opportunity-id="open-during-refresh"]')).toBeVisible()
  734 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  735 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  736 |     releaseSecondRequest?.()
  737 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  738 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  739 |   } finally {
  740 |     releaseSecondRequest?.()
  741 |   }
  742 | })
  743 | 
  744 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  745 |   const record = permit('roles', 'Facility construction', {
  746 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  747 |   })
  748 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  749 |   record.evidence[0].assessment_current = false
  750 |   expect(projectTitle(record)).not.toContain('Owner Company')
  751 | })
  752 | 
  753 | test('city permit company title shows source role and does not infer ownership', () => {
  754 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  755 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  756 |   })
  757 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  758 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  759 | 
  760 |   const houston = permit('houston-1', 'Commercial facility construction')
  761 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  762 |   houston.title_company_role = 'permit-listed owner / occupant'
  763 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  764 | })
  765 | 
  766 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  767 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  768 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  769 |   })
  770 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  771 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  772 | 
  773 |   const houston = permit('houston-1', 'Commercial facility construction')
  774 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  775 |   houston.title_company_role = 'permit-listed owner / occupant'
  776 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  777 | })
  778 | 
  779 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  780 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  781 |     projectId: 'dallas-campus',
  782 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  783 |   })
  784 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  785 |     projectId: 'dallas-campus',
  786 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  787 |   })
  788 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  789 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  790 |   const records = [keeter, merichem]
  791 |   await page.route(apiRoute, async (route) => {
  792 |     const path = new URL(route.request().url()).pathname
  793 |     if (path === '/api/opportunities') {
  794 |       await fulfillServerOpportunityPage(route, records)
```