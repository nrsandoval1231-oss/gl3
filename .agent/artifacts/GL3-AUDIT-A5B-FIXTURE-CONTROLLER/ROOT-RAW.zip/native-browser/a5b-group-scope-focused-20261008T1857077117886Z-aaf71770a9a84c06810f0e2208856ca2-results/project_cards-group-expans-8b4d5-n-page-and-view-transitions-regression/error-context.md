# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> group expansion intent is invalidated by tier, search, Signal decision, page, and view transitions
- Location: tests\project_cards.spec.ts:1022:1

# Error details

```
Error: route.fulfill: Route is already handled!
```

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-opportunity-id="scope-prospect"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('[data-opportunity-id="scope-prospect"]') with timeout 5000ms
  - waiting for locator('[data-opportunity-id="scope-prospect"]')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Prospects" [level=1]
  - paragraph: Projects with sourced events that may warrant a power discovery conversation.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Prospects · 1 filtered project cards · 1 filtered opportunity records" [level=2]
  - paragraph: Browse the evidence and open a project for its source details.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - link "Download filtered CSV":
    - /url: /api/opportunities/export.csv?tier=Prospect&search=&decision=ALL&cohort_token=fixture-server-cohort
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - button "Group scope-signal 2100 BARTON SPRINGS RD, AUSTIN, TX Signal 1 of 2 related records":
    - strong: Group scope-signal
    - text: 2100 BARTON SPRINGS RD, AUSTIN, TX Signal 1 of 2 related records
  - text: 1 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  999  |           : []
  1000 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1001 |   })
  1002 |   try {
  1003 |     await page.goto('/?tier=Signals')
  1004 |     const group = page.locator('[data-opportunity-id="pending-group-member"]')
  1005 |     await group.click()
  1006 |     await expect.poll(() => groupRequests).toBe(1)
  1007 |     await group.click()
  1008 |     groupReleases[0]?.()
  1009 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1010 |     await group.click()
  1011 |     await expect.poll(() => groupRequests).toBe(2)
  1012 |     await page.locator('[data-opportunity-id="pending-selection"]').click()
  1013 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
  1014 |     groupReleases[1]?.()
  1015 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
  1016 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1017 |   } finally {
  1018 |     for (const release of groupReleases) release()
  1019 |   }
  1020 | })
  1021 | 
  1022 | test('group expansion intent is invalidated by tier, search, Signal decision, page, and view transitions', async ({ page }) => {
  1023 |   const scenarios = [
  1024 |     { name: 'tier', initialId: 'scope-signal', nextId: 'scope-prospect' },
  1025 |     { name: 'search', initialId: 'scope-signal', nextId: 'scope-search' },
  1026 |     { name: 'decision', initialId: 'scope-show', nextId: 'scope-review' },
  1027 |     { name: 'page', initialId: 'scope-page-first', nextId: 'scope-page-next' },
  1028 |     { name: 'view', initialId: 'scope-signal', nextId: '' },
  1029 |   ] as const
  1030 |   const records = new Map<string, Opportunity>()
  1031 |   for (const [id, action, options] of [
  1032 |     ['scope-signal', 'Signal scope activity', {}],
  1033 |     ['scope-prospect', 'Prospect scope activity', { tier: 'Prospect' }],
  1034 |     ['scope-search', 'newterm scope activity', {}],
  1035 |     ['scope-show', 'SHOW scope activity', { decision: 'SHOW' }],
  1036 |     ['scope-review', 'REVIEW scope activity', { decision: 'REVIEW' }],
  1037 |     ['scope-page-first', 'First page scope activity', {}],
  1038 |     ['scope-page-next', 'Next page scope activity', {}],
  1039 |   ] as const) {
  1040 |     const record = permit(id, action, options)
  1041 |     record.group_id = `group-${id}`
  1042 |     record.group_title = `Group ${id}`
  1043 |     record.group_total_filtered = 2
  1044 |     record.group_loaded_on_page = 1
  1045 |     record.group_complete_on_page = false
  1046 |     records.set(id, record)
  1047 |   }
  1048 |   for (const scenario of scenarios) {
  1049 |     let releaseGroup: (() => void) | undefined
  1050 |     let groupGate = Promise.resolve()
  1051 |     let groupStarted = false
  1052 |     let groupFinished = false
  1053 |     await page.route(apiRoute, async (route) => {
  1054 |       const url = new URL(route.request().url())
  1055 |       const path = url.pathname
  1056 |       if (path === '/api/opportunities') {
  1057 |         const tier = url.searchParams.get('tier')
  1058 |         const search = url.searchParams.get('search') ?? ''
  1059 |         const decision = url.searchParams.get('decision') ?? 'ALL'
  1060 |         const offset = Number(url.searchParams.get('offset') ?? 0)
  1061 |         const chosenId = tier === 'prospect' ? 'scope-prospect'
  1062 |           : search ? 'scope-search'
  1063 |             : decision === 'REVIEW' ? 'scope-review'
  1064 |               : offset > 0 ? 'scope-page-next'
  1065 |                 : scenario.name === 'decision' ? 'scope-show'
  1066 |                   : scenario.name === 'page' ? 'scope-page-first' : 'scope-signal'
  1067 |         const record = records.get(chosenId)!
  1068 |         const payload = partialServerOpportunityPage([record])
  1069 |         const headers = { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset) }
  1070 |         if (scenario.name === 'page' && offset === 0) headers['X-Next-Offset'] = '25'
  1071 |         await route.fulfill({ status: 200, contentType: 'application/json', headers, body: JSON.stringify(payload.items) })
  1072 |         return
  1073 |       }
  1074 |       if (path.startsWith('/api/opportunity-groups/')) {
  1075 |         groupStarted = true
  1076 |         await groupGate
  1077 |         groupFinished = true
  1078 |         const groupId = path.split('/').at(-1) ?? ''
  1079 |         const record = [...records.values()].find((candidate) => candidate.group_id === groupId)!
  1080 |         await route.fulfill({ status: 200, json: { items: [record], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  1081 |         return
  1082 |       }
  1083 |       const body = path === '/api/auth/session'
  1084 |         ? { authenticated: true }
  1085 |         : path === '/api/health'
  1086 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1087 |           : []
  1088 |       await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1089 |     })
  1090 |     try {
  1091 |       await page.goto('/?tier=Signals')
  1092 |       groupStarted = false
  1093 |       groupFinished = false
  1094 |       groupGate = new Promise<void>((resolve) => { releaseGroup = resolve })
  1095 |       await page.locator(`[data-opportunity-id="${scenario.initialId}"]`).click()
  1096 |       await expect.poll(() => groupStarted).toBe(true)
  1097 |       if (scenario.name === 'tier') {
  1098 |         await page.getByRole('button', { name: 'Prospects' }).click()
> 1099 |         await expect(page.locator('[data-opportunity-id="scope-prospect"]')).toBeVisible()
       |                                                                              ^ Error: expect(locator).toBeVisible() failed
  1100 |       } else if (scenario.name === 'search') {
  1101 |         await page.getByRole('textbox', { name: 'Search projects' }).fill('newterm')
  1102 |         await expect(page.locator('[data-opportunity-id="scope-search"]')).toBeVisible()
  1103 |       } else if (scenario.name === 'decision') {
  1104 |         await page.getByRole('button', { name: /^REVIEW/ }).click()
  1105 |         await expect(page.locator('[data-opportunity-id="scope-review"]')).toBeVisible()
  1106 |       } else if (scenario.name === 'page') {
  1107 |         await page.getByRole('button', { name: 'Next →' }).click()
  1108 |         await expect(page.locator('[data-opportunity-id="scope-page-next"]')).toBeVisible()
  1109 |       } else {
  1110 |         await page.getByRole('button', { name: 'Ingestion' }).click()
  1111 |         await expect(page.getByRole('heading', { name: 'Ingestion inbox' })).toBeVisible()
  1112 |       }
  1113 |       releaseGroup?.()
  1114 |       await expect.poll(() => groupFinished).toBe(true)
  1115 |       await expect(page.locator('.project-members')).toHaveCount(0)
  1116 |       if (scenario.nextId) await expect(page.locator(`[data-opportunity-id="${scenario.nextId}"]`)).toBeVisible()
  1117 |     } finally {
  1118 |       releaseGroup?.()
  1119 |       await page.unroute(apiRoute)
  1120 |     }
  1121 |   }
  1122 | })
  1123 | 
  1124 | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  1125 |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  1126 |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  1127 |   let pageZeroRequests = 0
  1128 |   let releasePrevious: (() => void) | undefined
  1129 |   let previousStarted = false
  1130 |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  1131 |   await page.route(apiRoute, async (route) => {
  1132 |     const url = new URL(route.request().url())
  1133 |     if (url.pathname === '/api/opportunities') {
  1134 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1135 |       if (offset === 0) {
  1136 |         pageZeroRequests += 1
  1137 |         if (pageZeroRequests > 1) {
  1138 |           previousStarted = true
  1139 |           await previousGate
  1140 |         }
  1141 |       }
  1142 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1143 |       await route.fulfill({
  1144 |         status: 200,
  1145 |         contentType: 'application/json',
  1146 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1147 |         body: JSON.stringify(payload.items),
  1148 |       })
  1149 |       return
  1150 |     }
  1151 |     const path = url.pathname
  1152 |     const body = path === '/api/auth/session'
  1153 |       ? { authenticated: true }
  1154 |       : path === '/api/health'
  1155 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1156 |         : []
  1157 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1158 |   })
  1159 |   try {
  1160 |     await page.goto('/?tier=Signals&offset=25')
  1161 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toBeVisible()
  1162 |     await page.getByRole('button', { name: '← Previous' }).click()
  1163 |     await expect.poll(() => previousStarted).toBe(true)
  1164 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  1165 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toHaveCount(0)
  1166 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  1167 |     await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  1168 |     await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  1169 |     expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  1170 |     expect(new URL(page.url()).hash).toBe('')
  1171 |     releasePrevious?.()
  1172 |     await expect(page.locator('[data-opportunity-id="transition-first-page"]')).toBeVisible()
  1173 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  1174 |     await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  1175 |   } finally {
  1176 |     releasePrevious?.()
  1177 |   }
  1178 | })
  1179 | 
  1180 | test('Next hides first-page rows and metadata until the later-page request settles', async ({ page }) => {
  1181 |   const firstPageRecord = permit('transition-next-first-page', 'First page Next fixture')
  1182 |   const laterPageRecord = permit('transition-next-later-page', 'Later page Next fixture')
  1183 |   let releaseNext: (() => void) | undefined
  1184 |   let nextStarted = false
  1185 |   const nextGate = new Promise<void>((resolve) => { releaseNext = resolve })
  1186 |   await page.route(apiRoute, async (route) => {
  1187 |     const url = new URL(route.request().url())
  1188 |     if (url.pathname === '/api/opportunities') {
  1189 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1190 |       if (offset > 0) {
  1191 |         nextStarted = true
  1192 |         await nextGate
  1193 |       }
  1194 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1195 |       await route.fulfill({
  1196 |         status: 200,
  1197 |         contentType: 'application/json',
  1198 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-next-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1199 |         body: JSON.stringify(payload.items),
```