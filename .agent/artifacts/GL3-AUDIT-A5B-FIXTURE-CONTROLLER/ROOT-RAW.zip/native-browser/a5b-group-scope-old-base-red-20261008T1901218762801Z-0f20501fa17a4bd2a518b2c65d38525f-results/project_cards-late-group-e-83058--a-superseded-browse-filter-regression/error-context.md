# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> late group expansion pages cannot restore members from a superseded browse filter
- Location: tests\project_cards.spec.ts:833:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.project-members')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.project-members') with timeout 5000ms
  - waiting for locator('.project-members')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - generic [ref=e19]:
        - paragraph [ref=e20]: Evidence-led project discovery
        - heading "Signals" [level=1] [ref=e21]
        - paragraph [ref=e22]: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Today
          - strong [ref=e26]: 0 material changes
        - generic [ref=e27]: No material opportunity changes today.
    - generic [ref=e28]:
      - generic [ref=e29]:
        - heading "Signals · 1 filtered project cards · 1 filtered opportunity records" [level=2] [ref=e30]
        - paragraph [ref=e31]: All · 1 cards and 1 records on this page of 1 filtered cards and 1 records. SHOW means worth investigating, not qualified.
      - generic [ref=e32]:
        - generic [ref=e33]: Search projects
        - textbox "Search projects" [ref=e34]:
          - /placeholder: Search projects, work, or permit ID
      - link "Download filtered CSV" [ref=e35] [cursor=pointer]:
        - /url: /api/opportunities/export.csv?tier=Signal&search=&decision=ALL&cohort_token=fixture-server-cohort&activity=activity-b
    - generic "Filter opportunity records" [ref=e36]:
      - generic [ref=e37]:
        - text: Geography
        - combobox "Select unknown geography" [ref=e38]:
          - option "Any exact location" [selected]
          - option "Unknown"
        - textbox "Filter by exact geography" [ref=e39]:
          - /placeholder: Exact stored location
      - generic [ref=e40]:
        - text: Industry
        - combobox "Select unknown industry" [ref=e41]:
          - option "Any exact asset type" [selected]
          - option "Unknown"
        - textbox "Filter by exact project asset type" [ref=e42]:
          - /placeholder: Exact stored asset type
      - generic [ref=e43]:
        - text: Activity
        - combobox "Select unknown activity" [ref=e44]:
          - option "Any exact activity" [selected]
          - option "Unknown"
        - textbox "Filter by exact power activity" [active] [ref=e45]:
          - /placeholder: Exact stored activity
          - text: activity-b
      - generic [ref=e46]:
        - text: Timing
        - combobox "Filter by supported timing availability" [ref=e47]:
          - option "Any timing" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e48]:
        - text: Required MW
        - combobox "Filter by required MW availability" [ref=e49]:
          - option "Any MW status" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e50]:
        - text: MW minimum
        - textbox "Minimum overlapping required MW" [ref=e51]:
          - /placeholder: MW minimum
      - generic [ref=e52]:
        - text: MW maximum
        - textbox "Maximum overlapping required MW" [ref=e53]:
          - /placeholder: MW maximum
      - generic [ref=e54]:
        - text: Priority
        - combobox "Filter by canonical priority segment" [ref=e55]:
          - option "Any priority" [selected]
          - option "Segment 0"
          - option "Segment 1"
          - option "Segment 2"
          - option "Segment 3"
          - option "Segment 4"
          - option "Segment 5"
          - option "Segment 6"
          - option "Segment 7"
          - option "Segment 8"
      - generic [ref=e56]:
        - text: Workflow status
        - combobox "Filter by workflow status" [ref=e57]:
          - option "Any status" [selected]
          - option "Unknown"
    - group "Filter Signals by review decision" [ref=e58]:
      - button "All 1" [pressed] [ref=e59] [cursor=pointer]
      - button "SHOW 1" [ref=e60] [cursor=pointer]
      - button "REVIEW 0" [ref=e61] [cursor=pointer]
      - button "HOLD 0" [ref=e62] [cursor=pointer]
    - generic [ref=e64]:
      - 'button "Stable event group 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal 2 of 2 related records" [expanded] [ref=e65] [cursor=pointer]':
        - generic [ref=e67]:
          - strong [ref=e68]: Stable event group
          - generic [ref=e69]: 2100 BARTON SPRINGS RD, AUSTIN, TX
        - generic [ref=e70]:
          - strong [ref=e72]: "Decision: SHOW"
          - generic [ref=e73]: Signal
          - generic [ref=e74]: 2 of 2 related records
        - generic [aria-hidden] [ref=e75]: −
      - generic [ref=e76]:
        - paragraph [ref=e77]: 2 of 2 related records loaded
        - 'button "Activity A First Record Decision: SHOW Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX Open this record and its evidence →" [ref=e78] [cursor=pointer]':
          - strong [ref=e79]: Activity A First Record
          - strong [ref=e81]: "Decision: SHOW"
          - generic [ref=e82]: Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX
          - generic [ref=e83]: Open this record and its evidence →
        - 'button "Activity A Later Record Decision: SHOW Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX Open this record and its evidence →" [ref=e84] [cursor=pointer]':
          - strong [ref=e85]: Activity A Later Record
          - strong [ref=e87]: "Decision: SHOW"
          - generic [ref=e88]: Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX
          - generic [ref=e89]: Open this record and its evidence →
    - generic [ref=e90]:
      - generic [ref=e91]: 1 filtered records · page 1
      - button "← Previous" [disabled] [ref=e92]
      - button "Next →" [disabled] [ref=e93]
  - contentinfo [ref=e94]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  791 |   let secondRequestStarted = false
  792 |   let releaseSecondRequest: (() => void) | undefined
  793 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  794 |   await page.route(apiRoute, async (route) => {
  795 |     const url = new URL(route.request().url())
  796 |     if (url.pathname === '/api/opportunities') {
  797 |       opportunityRequests += 1
  798 |       if (opportunityRequests === 2) {
  799 |         secondRequestStarted = true
  800 |         await secondRequestGate
  801 |       }
  802 |       const payload = serverOpportunityPage([record, nextRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  803 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  804 |       return
  805 |     }
  806 |     const body = url.pathname === '/api/auth/session'
  807 |       ? { authenticated: true }
  808 |       : url.pathname === '/api/health'
  809 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  810 |         : url.pathname.startsWith('/api/power-needs/')
  811 |           ? { status: 'unavailable', result: null, citations: [] }
  812 |           : []
  813 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  814 |   })
  815 |   try {
  816 |     await page.goto('/?tier=Signals')
  817 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  818 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  819 |     await expect.poll(() => secondRequestStarted).toBe(true)
  820 |     await expect(page.locator('[data-opportunity-id="open-during-refresh-a"]')).toBeVisible()
  821 |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  822 |     await expect(page.getByRole('button', { name: 'Next →' })).toBeEnabled()
  823 |     await page.getByRole('button', { name: 'Next →' }).click()
  824 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  825 |     releaseSecondRequest?.()
  826 |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  827 |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  828 |   } finally {
  829 |     releaseSecondRequest?.()
  830 |   }
  831 | })
  832 | 
  833 | test('late group expansion pages cannot restore members from a superseded browse filter', async ({ page }) => {
  834 |   const oldFirst = permit('scope-a-first', 'Activity A first record', { activity: 'activity-a' })
  835 |   const oldLast = permit('scope-a-last', 'Activity A later record', { activity: 'activity-a' })
  836 |   const current = permit('scope-b-current', 'Activity B current record', { activity: 'activity-b' })
  837 |   const partial = (record: Opportunity, groupId: string, total: number) => {
  838 |     record.group_id = groupId
  839 |     record.group_title = 'Stable event group'
  840 |     record.group_total_filtered = total
  841 |     record.group_loaded_on_page = 1
  842 |     record.group_complete_on_page = false
  843 |     return record
  844 |   }
  845 |   partial(oldFirst, 'stable-group', 51)
  846 |   partial(oldLast, 'stable-group', 51)
  847 |   partial(current, 'stable-group', 2)
  848 |   let releaseOldLaterPage: (() => void) | undefined
  849 |   const oldLaterPage = new Promise<void>((resolve) => { releaseOldLaterPage = resolve })
  850 |   let oldLaterPageStarted = false
  851 |   const groupRequests: URL[] = []
  852 |   await page.route(apiRoute, async (route) => {
  853 |     const url = new URL(route.request().url())
  854 |     const path = url.pathname
  855 |     if (path === '/api/opportunities') {
  856 |       const activity = url.searchParams.get('activity')
  857 |       const record = activity === 'activity-a' ? oldFirst : current
  858 |       const payload = partialServerOpportunityPage([record])
  859 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0' }, body: JSON.stringify(payload.items) })
  860 |       return
  861 |     }
  862 |     if (path === '/api/opportunity-groups/stable-group') {
  863 |       groupRequests.push(url)
  864 |       const activity = url.searchParams.get('activity')
  865 |       const groupOffset = Number(url.searchParams.get('offset'))
  866 |       if (activity === 'activity-a' && groupOffset === 50) {
  867 |         oldLaterPageStarted = true
  868 |         await oldLaterPage
  869 |         await route.fulfill({ status: 200, json: { items: [oldLast], total: 51, limit: 50, offset: 50, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  870 |         return
  871 |       }
  872 |       await route.fulfill({ status: 200, json: { items: [activity === 'activity-a' ? oldFirst : current], total: activity === 'activity-a' ? 51 : 1, limit: 50, offset: groupOffset, next_offset: activity === 'activity-a' ? 50 : null, cohort_token: 'fixture-server-cohort' } })
  873 |       return
  874 |     }
  875 |     const body = path === '/api/auth/session'
  876 |       ? { authenticated: true }
  877 |       : path === '/api/health'
  878 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  879 |         : []
  880 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  881 |   })
  882 |   try {
  883 |     await page.goto('/?tier=Signals&activity=activity-a')
  884 |     const group = page.locator('[data-opportunity-id="scope-a-first"]')
  885 |     await expect(group).toBeVisible()
  886 |     await group.click()
  887 |     await expect.poll(() => oldLaterPageStarted).toBe(true)
  888 |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('activity-b')
  889 |     await expect(page.locator('[data-opportunity-id="scope-b-current"]')).toBeVisible()
  890 |     releaseOldLaterPage?.()
> 891 |     await expect(page.locator('.project-members')).toHaveCount(0)
      |                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  892 |     await expect(page.locator('[data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  893 |     expect(groupRequests.every((request) => request.searchParams.get('cohort_token') === 'fixture-server-cohort')).toBe(true)
  894 |     expect(groupRequests.some((request) => request.searchParams.get('activity') === 'activity-a' && request.searchParams.get('offset') === '50')).toBe(true)
  895 |     await page.locator('[data-opportunity-id="scope-b-current"]').click()
  896 |     await expect(page.locator('.project-members [data-opportunity-id="scope-b-current"]')).toBeVisible()
  897 |     await expect(page.locator('.project-members [data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  898 |   } finally {
  899 |     releaseOldLaterPage?.()
  900 |   }
  901 | })
  902 | 
  903 | test('only the latest group expansion intent may open a card or surface its failure', async ({ page }) => {
  904 |   const first = permit('intent-first', 'First exact group member')
  905 |   const second = permit('intent-second', 'Second exact group member')
  906 |   for (const [record, groupId] of [[first, 'intent-group-a'], [second, 'intent-group-b']] as const) {
  907 |     record.group_id = groupId
  908 |     record.group_title = groupId
  909 |     record.group_total_filtered = 2
  910 |     record.group_loaded_on_page = 1
  911 |     record.group_complete_on_page = false
  912 |   }
  913 |   let releaseFirst: (() => void) | undefined
  914 |   const firstGate = new Promise<void>((resolve) => { releaseFirst = resolve })
  915 |   let firstStarted = false
  916 |   let failSecond = false
  917 |   await page.route(apiRoute, async (route) => {
  918 |     const url = new URL(route.request().url())
  919 |     if (url.pathname === '/api/opportunities') {
  920 |       const payload = partialServerOpportunityPage([first, second])
  921 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  922 |       return
  923 |     }
  924 |     if (url.pathname.startsWith('/api/opportunity-groups/')) {
  925 |       if (url.pathname.endsWith('intent-group-a')) {
  926 |         firstStarted = true
  927 |         await firstGate
  928 |         await route.fulfill({ status: 503, json: { detail: 'synthetic stale group failure' } })
  929 |         return
  930 |       }
  931 |       if (failSecond) {
  932 |         await route.fulfill({ status: 503, json: { detail: 'synthetic current group failure' } })
  933 |         return
  934 |       }
  935 |       await route.fulfill({ status: 200, json: { items: [second], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  936 |       return
  937 |     }
  938 |     const body = url.pathname === '/api/auth/session'
  939 |       ? { authenticated: true }
  940 |       : url.pathname === '/api/health'
  941 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  942 |         : []
  943 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  944 |   })
  945 |   try {
  946 |     await page.goto('/?tier=Signals')
  947 |     await page.locator('[data-opportunity-id="intent-first"]').click()
  948 |     await expect.poll(() => firstStarted).toBe(true)
  949 |     await page.locator('.opportunity-row[data-opportunity-id="intent-second"]').click()
  950 |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  951 |     releaseFirst?.()
  952 |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  953 |     await expect(page.locator('.project-members [data-opportunity-id="intent-first"]')).toHaveCount(0)
  954 |     await expect(page.getByRole('alert')).toHaveCount(0)
  955 | 
  956 |     await page.locator('.opportunity-row[data-opportunity-id="intent-second"]').click()
  957 |     await expect(page.locator('.project-members')).toHaveCount(0)
  958 |     failSecond = true
  959 |     await page.locator('[data-opportunity-id="intent-second"]').click()
  960 |     await expect(page.getByRole('alert')).toContainText('503')
  961 |     await expect(page.locator('.project-members')).toHaveCount(0)
  962 |   } finally {
  963 |     releaseFirst?.()
  964 |   }
  965 | })
  966 | 
  967 | test('reclicking a pending group cancels its expansion and selected-record navigation supersedes it', async ({ page }) => {
  968 |   const grouped = permit('pending-group-member', 'Pending group member')
  969 |   grouped.group_id = 'pending-group'
  970 |   grouped.group_title = 'Pending group'
  971 |   grouped.group_total_filtered = 2
  972 |   grouped.group_loaded_on_page = 1
  973 |   grouped.group_complete_on_page = false
  974 |   const selected = permit('pending-selection', 'Selected standalone record')
  975 |   selected.group_total_filtered = 1
  976 |   selected.group_loaded_on_page = 1
  977 |   selected.group_complete_on_page = true
  978 |   const groupReleases: (() => void)[] = []
  979 |   let groupRequests = 0
  980 |   await page.route(apiRoute, async (route) => {
  981 |     const url = new URL(route.request().url())
  982 |     if (url.pathname === '/api/opportunities') {
  983 |       const payload = partialServerOpportunityPage([grouped, selected])
  984 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  985 |       return
  986 |     }
  987 |     if (url.pathname === '/api/opportunity-groups/pending-group') {
  988 |       groupRequests += 1
  989 |       await new Promise<void>((resolve) => { groupReleases.push(resolve) })
  990 |       await route.fulfill({ status: 200, json: { items: [grouped], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  991 |       return
```