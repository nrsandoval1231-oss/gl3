# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> failed Previous clears the later page and reports unavailable instead of an empty cohort
- Location: tests\project_cards.spec.ts:874:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "First page unavailable for transition test"
Received string:    "GridLens could not complete this request (503)."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')
    14 × locator resolved to <p role="alert" class="error-banner">GridLens could not complete this request (503).</p>
       - unexpected value "GridLens could not complete this request (503)."

```

```yaml
- alert: GridLens could not complete this request (503).
```

# Test source

```ts
  805  |     await expect.poll(() => secondRequestStarted).toBe(true)
  806  |     await expect(page.locator('[data-opportunity-id="open-during-refresh-a"]')).toBeVisible()
  807  |     await page.locator('[data-opportunity-id="open-during-refresh-a"]').click()
  808  |     await expect(page.getByRole('button', { name: 'Next →' })).toBeEnabled()
  809  |     await page.getByRole('button', { name: 'Next →' }).click()
  810  |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  811  |     releaseSecondRequest?.()
  812  |     await expect(page.getByText('Updating this view…')).toHaveCount(0)
  813  |     await expect(page.getByRole('heading', { level: 1 })).toHaveText('Second Campus Facility Activity')
  814  |   } finally {
  815  |     releaseSecondRequest?.()
  816  |   }
  817  | })
  818  | 
  819  | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  820  |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  821  |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  822  |   let pageZeroRequests = 0
  823  |   let releasePrevious: (() => void) | undefined
  824  |   let previousStarted = false
  825  |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  826  |   await page.route(apiRoute, async (route) => {
  827  |     const url = new URL(route.request().url())
  828  |     if (url.pathname === '/api/opportunities') {
  829  |       const offset = Number(url.searchParams.get('offset') ?? '0')
  830  |       if (offset === 0) {
  831  |         pageZeroRequests += 1
  832  |         if (pageZeroRequests > 1) {
  833  |           previousStarted = true
  834  |           await previousGate
  835  |         }
  836  |       }
  837  |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  838  |       await route.fulfill({
  839  |         status: 200,
  840  |         contentType: 'application/json',
  841  |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  842  |         body: JSON.stringify(payload.items),
  843  |       })
  844  |       return
  845  |     }
  846  |     const path = url.pathname
  847  |     const body = path === '/api/auth/session'
  848  |       ? { authenticated: true }
  849  |       : path === '/api/health'
  850  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  851  |         : []
  852  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  853  |   })
  854  |   try {
  855  |     await page.goto('/?tier=Signals&offset=25')
  856  |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toBeVisible()
  857  |     await page.getByRole('button', { name: '← Previous' }).click()
  858  |     await expect.poll(() => previousStarted).toBe(true)
  859  |     await expect(page.getByText('Updating this view…')).toBeVisible()
  860  |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toHaveCount(0)
  861  |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  862  |     await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  863  |     expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  864  |     expect(new URL(page.url()).hash).toBe('')
  865  |     releasePrevious?.()
  866  |     await expect(page.locator('[data-opportunity-id="transition-first-page"]')).toBeVisible()
  867  |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  868  |     await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  869  |   } finally {
  870  |     releasePrevious?.()
  871  |   }
  872  | })
  873  | 
  874  | test('failed Previous clears the later page and reports unavailable instead of an empty cohort', async ({ page }) => {
  875  |   const laterPageRecord = permit('transition-error-later-page', 'Later page error fixture')
  876  |   let pageZeroRequests = 0
  877  |   await page.route(apiRoute, async (route) => {
  878  |     const url = new URL(route.request().url())
  879  |     if (url.pathname === '/api/opportunities') {
  880  |       const offset = Number(url.searchParams.get('offset') ?? '0')
  881  |       if (offset === 0 && ++pageZeroRequests > 1) {
  882  |         await route.fulfill({ status: 503, json: { detail: 'First page unavailable for transition test' } })
  883  |         return
  884  |       }
  885  |       const payload = serverOpportunityPage([laterPageRecord])
  886  |       await route.fulfill({
  887  |         status: 200,
  888  |         contentType: 'application/json',
  889  |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-error-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  890  |         body: JSON.stringify(payload.items),
  891  |       })
  892  |       return
  893  |     }
  894  |     const path = url.pathname
  895  |     const body = path === '/api/auth/session'
  896  |       ? { authenticated: true }
  897  |       : path === '/api/health'
  898  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  899  |         : []
  900  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  901  |   })
  902  |   await page.goto('/?tier=Signals&offset=25')
  903  |   await expect(page.locator('[data-opportunity-id="transition-error-later-page"]')).toBeVisible()
  904  |   await page.getByRole('button', { name: '← Previous' }).click()
> 905  |   await expect(page.getByRole('alert')).toContainText('First page unavailable for transition test')
       |                                         ^ Error: expect(locator).toContainText(expected) failed
  906  |   await expect(page.locator('[data-opportunity-id="transition-error-later-page"]')).toHaveCount(0)
  907  |   await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  908  |   await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  909  |   await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  910  |   expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  911  |   expect(new URL(page.url()).hash).toBe('')
  912  | })
  913  | 
  914  | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  915  |   const record = permit('roles', 'Facility construction', {
  916  |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  917  |   })
  918  |   expect(projectTitle(record)).toBe('Owner Company · owner')
  919  |   record.evidence[0].assessment_current = false
  920  |   expect(projectTitle(record)).not.toContain('Owner Company')
  921  | })
  922  | 
  923  | test('city permit company title shows source role and does not infer ownership', () => {
  924  |   const dallas = permit('dallas-1', 'Warehouse construction', {
  925  |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  926  |   })
  927  |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  928  |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  929  | 
  930  |   const houston = permit('houston-1', 'Commercial facility construction')
  931  |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  932  |   houston.title_company_role = 'permit-listed owner / occupant'
  933  |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  934  | })
  935  | 
  936  | test('city permit organization labels preserve the source role and role uncertainty', () => {
  937  |   const dallas = permit('dallas-1', 'Warehouse construction', {
  938  |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  939  |   })
  940  |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  941  |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  942  | 
  943  |   const houston = permit('houston-1', 'Commercial facility construction')
  944  |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  945  |   houston.title_company_role = 'permit-listed owner / occupant'
  946  |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  947  | })
  948  | 
  949  | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  950  |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  951  |     projectId: 'dallas-campus',
  952  |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  953  |   })
  954  |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  955  |     projectId: 'dallas-campus',
  956  |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  957  |   })
  958  |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  959  |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  960  |   const records = [keeter, merichem]
  961  |   await page.route(apiRoute, async (route) => {
  962  |     const path = new URL(route.request().url()).pathname
  963  |     if (path === '/api/opportunities') {
  964  |       await fulfillServerOpportunityPage(route, records)
  965  |       return
  966  |     }
  967  |     const body = path === '/api/auth/session'
  968  |       ? { authenticated: true }
  969  |       : path === '/api/health'
  970  |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  971  |           : []
  972  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  973  |   })
  974  |   await page.goto('/?tier=Signals')
  975  |   await page.getByRole('button', { name: /KEETER INVESTMENTS LLC · LP Business Name · role unverified/ }).click()
  976  |   const keeterMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000129"]')
  977  |   const merichemMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000130"]')
  978  |   await expect(keeterMember).toContainText('KEETER INVESTMENTS LLC · LP Business Name · role unverified')
  979  |   await expect(merichemMember).toContainText('MERICHEM TECHNOLOGIES LLC · owner')
  980  |   await keeterMember.click()
  981  |   await expect(page.getByRole('heading', { level: 1, name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified' })).toBeVisible()
  982  |   await expect(page.getByText('COM-NEW-26-000129', { exact: false }).first()).toBeVisible()
  983  | })
  984  | 
  985  | test('Signals default to All and keep SHOW, REVIEW, and HOLD selectable', async ({ page }) => {
  986  |   let records = [
  987  |     permit('hold-member', 'Routine hospital maintenance', { projectId: 'shared-project', decision: 'HOLD' }),
  988  |     permit('show-member', 'New data center electrical buildout', { projectId: 'shared-project', decision: 'SHOW' }),
  989  |     permit('review', 'Possible industrial expansion', { projectId: 'review-project', decision: 'REVIEW' }),
  990  |     permit('hold', 'Marathon temporary stage', { projectId: 'hold-project', decision: 'HOLD' }),
  991  |     permit('unknown', 'Unadjudicated project', { projectId: 'unknown-project', decision: null }),
  992  |   ]
  993  |   await page.route(apiRoute, async (route) => {
  994  |     const path = new URL(route.request().url()).pathname
  995  |     if (path === '/api/opportunities') {
  996  |       await fulfillServerOpportunityPage(route, records)
  997  |       return
  998  |     }
  999  |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  1000 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1001 |   })
  1002 |   await page.goto('/?tier=Signals')
  1003 |   await expect(page.getByRole('button', { name: 'All 4' })).toHaveAttribute('aria-pressed', 'true')
  1004 |   await expect(page.getByRole('button', { name: /Possible Industrial Expansion/ })).toBeVisible()
  1005 |   await expect(page.getByRole('button', { name: /Marathon Temporary Stage/ })).toBeVisible()
```