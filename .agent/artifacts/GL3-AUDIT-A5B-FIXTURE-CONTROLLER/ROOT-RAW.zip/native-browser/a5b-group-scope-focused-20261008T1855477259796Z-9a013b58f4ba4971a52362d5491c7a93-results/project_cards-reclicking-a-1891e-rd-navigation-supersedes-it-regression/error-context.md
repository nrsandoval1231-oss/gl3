# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> reclicking a pending group cancels its expansion and selected-record navigation supersedes it
- Location: tests\project_cards.spec.ts:966:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('heading', { level: 1 })
Expected substring: "Pending Selection"
Received string:    "Selected Standalone Record"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('heading', { level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { level: 1 })
    14 × locator resolved to <h1>Selected Standalone Record</h1>
       - unexpected value "Selected Standalone Record"

```

```yaml
- heading "Selected Standalone Record" [level=1]
```

# Test source

```ts
  912  |   }
  913  |   let releaseFirst: (() => void) | undefined
  914  |   const firstGate = new Promise<void>((resolve) => { releaseFirst = resolve })
  915  |   let firstStarted = false
  916  |   let failSecond = false
  917  |   await page.route(apiRoute, async (route) => {
  918  |     const url = new URL(route.request().url())
  919  |     if (url.pathname === '/api/opportunities') {
  920  |       const payload = partialServerOpportunityPage([first, second])
  921  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  922  |       return
  923  |     }
  924  |     if (url.pathname.startsWith('/api/opportunity-groups/')) {
  925  |       if (url.pathname.endsWith('intent-group-a')) {
  926  |         firstStarted = true
  927  |         await firstGate
  928  |         await route.fulfill({ status: 503, json: { detail: 'synthetic stale group failure' } })
  929  |         return
  930  |       }
  931  |       if (failSecond) {
  932  |         await route.fulfill({ status: 503, json: { detail: 'synthetic current group failure' } })
  933  |         return
  934  |       }
  935  |       await route.fulfill({ status: 200, json: { items: [second], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  936  |       return
  937  |     }
  938  |     const body = url.pathname === '/api/auth/session'
  939  |       ? { authenticated: true }
  940  |       : url.pathname === '/api/health'
  941  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  942  |         : []
  943  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  944  |   })
  945  |   try {
  946  |     await page.goto('/?tier=Signals')
  947  |     await page.locator('[data-opportunity-id="intent-first"]').click()
  948  |     await expect.poll(() => firstStarted).toBe(true)
  949  |     await page.locator('[data-opportunity-id="intent-second"]').click()
  950  |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  951  |     releaseFirst?.()
  952  |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  953  |     await expect(page.locator('.project-members [data-opportunity-id="intent-first"]')).toHaveCount(0)
  954  | 
  955  |     await page.locator('[data-opportunity-id="intent-second"]').click()
  956  |     await expect(page.locator('.project-members')).toHaveCount(0)
  957  |     failSecond = true
  958  |     await page.locator('[data-opportunity-id="intent-second"]').click()
  959  |     await expect(page.getByRole('alert')).toContainText('503')
  960  |     await expect(page.locator('.project-members')).toHaveCount(0)
  961  |   } finally {
  962  |     releaseFirst?.()
  963  |   }
  964  | })
  965  | 
  966  | test('reclicking a pending group cancels its expansion and selected-record navigation supersedes it', async ({ page }) => {
  967  |   const grouped = permit('pending-group-member', 'Pending group member')
  968  |   grouped.group_id = 'pending-group'
  969  |   grouped.group_title = 'Pending group'
  970  |   grouped.group_total_filtered = 2
  971  |   grouped.group_loaded_on_page = 1
  972  |   grouped.group_complete_on_page = false
  973  |   const selected = permit('pending-selection', 'Selected standalone record')
  974  |   selected.group_total_filtered = 1
  975  |   selected.group_loaded_on_page = 1
  976  |   selected.group_complete_on_page = true
  977  |   const groupReleases: (() => void)[] = []
  978  |   let groupRequests = 0
  979  |   await page.route(apiRoute, async (route) => {
  980  |     const url = new URL(route.request().url())
  981  |     if (url.pathname === '/api/opportunities') {
  982  |       const payload = partialServerOpportunityPage([grouped, selected])
  983  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  984  |       return
  985  |     }
  986  |     if (url.pathname === '/api/opportunity-groups/pending-group') {
  987  |       groupRequests += 1
  988  |       await new Promise<void>((resolve) => { groupReleases.push(resolve) })
  989  |       await route.fulfill({ status: 200, json: { items: [grouped], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  990  |       return
  991  |     }
  992  |     const body = url.pathname === '/api/auth/session'
  993  |       ? { authenticated: true }
  994  |       : url.pathname === '/api/health'
  995  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  996  |         : url.pathname.startsWith('/api/opportunities/needs/')
  997  |           ? selected
  998  |           : []
  999  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1000 |   })
  1001 |   try {
  1002 |     await page.goto('/?tier=Signals')
  1003 |     const group = page.locator('[data-opportunity-id="pending-group-member"]')
  1004 |     await group.click()
  1005 |     await expect.poll(() => groupRequests).toBe(1)
  1006 |     await group.click()
  1007 |     groupReleases[0]?.()
  1008 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1009 |     await group.click()
  1010 |     await expect.poll(() => groupRequests).toBe(2)
  1011 |     await page.locator('[data-opportunity-id="pending-selection"]').click()
> 1012 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Pending Selection')
       |                                                           ^ Error: expect(locator).toContainText(expected) failed
  1013 |     groupReleases[1]?.()
  1014 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Pending Selection')
  1015 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1016 |   } finally {
  1017 |     for (const release of groupReleases) release()
  1018 |   }
  1019 | })
  1020 | 
  1021 | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  1022 |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  1023 |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  1024 |   let pageZeroRequests = 0
  1025 |   let releasePrevious: (() => void) | undefined
  1026 |   let previousStarted = false
  1027 |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  1028 |   await page.route(apiRoute, async (route) => {
  1029 |     const url = new URL(route.request().url())
  1030 |     if (url.pathname === '/api/opportunities') {
  1031 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1032 |       if (offset === 0) {
  1033 |         pageZeroRequests += 1
  1034 |         if (pageZeroRequests > 1) {
  1035 |           previousStarted = true
  1036 |           await previousGate
  1037 |         }
  1038 |       }
  1039 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1040 |       await route.fulfill({
  1041 |         status: 200,
  1042 |         contentType: 'application/json',
  1043 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1044 |         body: JSON.stringify(payload.items),
  1045 |       })
  1046 |       return
  1047 |     }
  1048 |     const path = url.pathname
  1049 |     const body = path === '/api/auth/session'
  1050 |       ? { authenticated: true }
  1051 |       : path === '/api/health'
  1052 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1053 |         : []
  1054 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1055 |   })
  1056 |   try {
  1057 |     await page.goto('/?tier=Signals&offset=25')
  1058 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toBeVisible()
  1059 |     await page.getByRole('button', { name: '← Previous' }).click()
  1060 |     await expect.poll(() => previousStarted).toBe(true)
  1061 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  1062 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toHaveCount(0)
  1063 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  1064 |     await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  1065 |     await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  1066 |     expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  1067 |     expect(new URL(page.url()).hash).toBe('')
  1068 |     releasePrevious?.()
  1069 |     await expect(page.locator('[data-opportunity-id="transition-first-page"]')).toBeVisible()
  1070 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  1071 |     await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  1072 |   } finally {
  1073 |     releasePrevious?.()
  1074 |   }
  1075 | })
  1076 | 
  1077 | test('Next hides first-page rows and metadata until the later-page request settles', async ({ page }) => {
  1078 |   const firstPageRecord = permit('transition-next-first-page', 'First page Next fixture')
  1079 |   const laterPageRecord = permit('transition-next-later-page', 'Later page Next fixture')
  1080 |   let releaseNext: (() => void) | undefined
  1081 |   let nextStarted = false
  1082 |   const nextGate = new Promise<void>((resolve) => { releaseNext = resolve })
  1083 |   await page.route(apiRoute, async (route) => {
  1084 |     const url = new URL(route.request().url())
  1085 |     if (url.pathname === '/api/opportunities') {
  1086 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1087 |       if (offset > 0) {
  1088 |         nextStarted = true
  1089 |         await nextGate
  1090 |       }
  1091 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1092 |       await route.fulfill({
  1093 |         status: 200,
  1094 |         contentType: 'application/json',
  1095 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-next-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1096 |         body: JSON.stringify(payload.items),
  1097 |       })
  1098 |       return
  1099 |     }
  1100 |     const path = url.pathname
  1101 |     const body = path === '/api/auth/session'
  1102 |       ? { authenticated: true }
  1103 |       : path === '/api/health'
  1104 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1105 |         : []
  1106 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1107 |   })
  1108 |   try {
  1109 |     await page.goto('/?tier=Signals')
  1110 |     await expect(page.locator('[data-opportunity-id="transition-next-first-page"]')).toBeVisible()
  1111 |     await page.getByRole('button', { name: 'Next →' }).click()
  1112 |     await expect.poll(() => nextStarted).toBe(true)
```