# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> only the latest group expansion intent may open a card or surface its failure
- Location: tests\project_cards.spec.ts:903:1

# Error details

```
Error: locator.click: Error: strict mode violation: locator('[data-opportunity-id="intent-second"]') resolved to 2 elements:
    1) <button aria-expanded="true" class="opportunity-row" data-opportunity-id="intent-second">…</button> aka getByRole('button', { name: 'intent-group-b 2100 BARTON' })
    2) <button class="project-member" data-opportunity-id="intent-second">…</button> aka getByRole('button', { name: 'Second Exact Group Member' })

Call log:
  - waiting for locator('[data-opportunity-id="intent-second"]')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "GridLens home" [ref=e5] [cursor=pointer]:
      - /url: /?tier=Signals&q=
      - img "GridLens" [ref=e6]
    - navigation "Workspace views" [ref=e7]:
      - button "Signals" [ref=e8] [cursor=pointer]
      - button "Prospects" [ref=e9] [cursor=pointer]
      - button "Leads" [ref=e10] [cursor=pointer]
      - button "Today’s pursuits" [ref=e11] [cursor=pointer]
      - button "Ingestion" [ref=e12] [cursor=pointer]
    - generic [ref=e13]:
      - button "Source health" [ref=e14] [cursor=pointer]
      - button "Sign out" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - generic [ref=e19]:
        - paragraph [ref=e20]: Evidence-led project discovery
        - heading "Signals" [level=1] [ref=e21]
        - paragraph [ref=e22]: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]: Today
          - strong [ref=e26]: 0 material changes
        - generic [ref=e27]: No material opportunity changes today.
    - generic [ref=e28]:
      - generic [ref=e29]:
        - heading "Signals · 2 filtered project cards · 2 filtered opportunity records" [level=2] [ref=e30]
        - paragraph [ref=e31]: All · 2 cards and 2 records on this page of 2 filtered cards and 2 records. SHOW means worth investigating, not qualified.
      - generic [ref=e32]:
        - generic [ref=e33]: Search projects
        - textbox "Search projects" [ref=e34]:
          - /placeholder: Search projects, work, or permit ID
      - link "Download filtered CSV" [ref=e35] [cursor=pointer]:
        - /url: /api/opportunities/export.csv?tier=Signal&search=&decision=ALL&cohort_token=fixture-server-cohort
    - generic "Filter opportunity records" [ref=e36]:
      - generic [ref=e37]:
        - text: Geography
        - combobox "Select unknown geography" [ref=e38]:
          - option "Any exact location" [selected]
          - option "Unknown"
        - textbox "Filter by exact geography" [ref=e39]:
          - /placeholder: Exact stored location
      - generic [ref=e40]:
        - text: Industry
        - combobox "Select unknown industry" [ref=e41]:
          - option "Any exact asset type" [selected]
          - option "Unknown"
        - textbox "Filter by exact project asset type" [ref=e42]:
          - /placeholder: Exact stored asset type
      - generic [ref=e43]:
        - text: Activity
        - combobox "Select unknown activity" [ref=e44]:
          - option "Any exact activity" [selected]
          - option "Unknown"
        - textbox "Filter by exact power activity" [ref=e45]:
          - /placeholder: Exact stored activity
      - generic [ref=e46]:
        - text: Timing
        - combobox "Filter by supported timing availability" [ref=e47]:
          - option "Any timing" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e48]:
        - text: Required MW
        - combobox "Filter by required MW availability" [ref=e49]:
          - option "Any MW status" [selected]
          - option "Known"
          - option "Unknown"
      - generic [ref=e50]:
        - text: MW minimum
        - textbox "Minimum overlapping required MW" [ref=e51]:
          - /placeholder: MW minimum
      - generic [ref=e52]:
        - text: MW maximum
        - textbox "Maximum overlapping required MW" [ref=e53]:
          - /placeholder: MW maximum
      - generic [ref=e54]:
        - text: Priority
        - combobox "Filter by canonical priority segment" [ref=e55]:
          - option "Any priority" [selected]
          - option "Segment 0"
          - option "Segment 1"
          - option "Segment 2"
          - option "Segment 3"
          - option "Segment 4"
          - option "Segment 5"
          - option "Segment 6"
          - option "Segment 7"
          - option "Segment 8"
      - generic [ref=e56]:
        - text: Workflow status
        - combobox "Filter by workflow status" [ref=e57]:
          - option "Any status" [selected]
          - option "Unknown"
    - group "Filter Signals by review decision" [ref=e58]:
      - button "All 2" [pressed] [ref=e59] [cursor=pointer]
      - button "SHOW 2" [ref=e60] [cursor=pointer]
      - button "REVIEW 0" [ref=e61] [cursor=pointer]
      - button "HOLD 0" [ref=e62] [cursor=pointer]
    - generic [ref=e63]:
      - 'button "intent-group-a 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal 1 of 2 related records" [ref=e65] [cursor=pointer]':
        - generic [ref=e67]:
          - strong [ref=e68]: intent-group-a
          - generic [ref=e69]: 2100 BARTON SPRINGS RD, AUSTIN, TX
        - generic [ref=e70]:
          - strong [ref=e72]: "Decision: SHOW"
          - generic [ref=e73]: Signal
          - generic [ref=e74]: 1 of 2 related records
        - generic [aria-hidden] [ref=e75]: +
      - generic [ref=e76]:
        - 'button "intent-group-b 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal 1 of 2 related records" [expanded] [active] [ref=e77] [cursor=pointer]':
          - generic [ref=e79]:
            - strong [ref=e80]: intent-group-b
            - generic [ref=e81]: 2100 BARTON SPRINGS RD, AUSTIN, TX
          - generic [ref=e82]:
            - strong [ref=e84]: "Decision: SHOW"
            - generic [ref=e85]: Signal
            - generic [ref=e86]: 1 of 2 related records
          - generic [aria-hidden] [ref=e87]: −
        - generic [ref=e88]:
          - paragraph [ref=e89]: 1 of 2 related records loaded
          - 'button "Second Exact Group Member Decision: SHOW Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX Open this record and its evidence →" [ref=e90] [cursor=pointer]':
            - strong [ref=e91]: Second Exact Group Member
            - strong [ref=e93]: "Decision: SHOW"
            - generic [ref=e94]: Permit issue date unknown · 2100 BARTON SPRINGS RD, AUSTIN, TX
            - generic [ref=e95]: Open this record and its evidence →
    - generic [ref=e96]:
      - generic [ref=e97]: 2 filtered records · page 1
      - button "← Previous" [disabled] [ref=e98]
      - button "Next →" [disabled] [ref=e99]
  - contentinfo [ref=e100]: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  855  |     if (path === '/api/opportunities') {
  856  |       const activity = url.searchParams.get('activity')
  857  |       const record = activity === 'activity-a' ? oldFirst : current
  858  |       const payload = partialServerOpportunityPage([record])
  859  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0' }, body: JSON.stringify(payload.items) })
  860  |       return
  861  |     }
  862  |     if (path === '/api/opportunity-groups/stable-group') {
  863  |       groupRequests.push(url)
  864  |       const activity = url.searchParams.get('activity')
  865  |       const groupOffset = Number(url.searchParams.get('offset'))
  866  |       if (activity === 'activity-a' && groupOffset === 50) {
  867  |         oldLaterPageStarted = true
  868  |         await oldLaterPage
  869  |         await route.fulfill({ status: 200, json: { items: [oldLast], total: 51, limit: 50, offset: 50, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  870  |         return
  871  |       }
  872  |       await route.fulfill({ status: 200, json: { items: [activity === 'activity-a' ? oldFirst : current], total: activity === 'activity-a' ? 51 : 1, limit: 50, offset: groupOffset, next_offset: activity === 'activity-a' ? 50 : null, cohort_token: 'fixture-server-cohort' } })
  873  |       return
  874  |     }
  875  |     const body = path === '/api/auth/session'
  876  |       ? { authenticated: true }
  877  |       : path === '/api/health'
  878  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  879  |         : []
  880  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  881  |   })
  882  |   try {
  883  |     await page.goto('/?tier=Signals&activity=activity-a')
  884  |     const group = page.locator('[data-opportunity-id="scope-a-first"]')
  885  |     await expect(group).toBeVisible()
  886  |     await group.click()
  887  |     await expect.poll(() => oldLaterPageStarted).toBe(true)
  888  |     await page.getByRole('textbox', { name: 'Filter by exact power activity' }).fill('activity-b')
  889  |     await expect(page.locator('[data-opportunity-id="scope-b-current"]')).toBeVisible()
  890  |     releaseOldLaterPage?.()
  891  |     await expect(page.locator('.project-members')).toHaveCount(0)
  892  |     await expect(page.locator('[data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  893  |     expect(groupRequests.every((request) => request.searchParams.get('cohort_token') === 'fixture-server-cohort')).toBe(true)
  894  |     expect(groupRequests.some((request) => request.searchParams.get('activity') === 'activity-a' && request.searchParams.get('offset') === '50')).toBe(true)
  895  |     await page.locator('[data-opportunity-id="scope-b-current"]').click()
  896  |     await expect(page.locator('.project-members [data-opportunity-id="scope-b-current"]')).toBeVisible()
  897  |     await expect(page.locator('.project-members [data-opportunity-id="scope-a-last"]')).toHaveCount(0)
  898  |   } finally {
  899  |     releaseOldLaterPage?.()
  900  |   }
  901  | })
  902  | 
  903  | test('only the latest group expansion intent may open a card or surface its failure', async ({ page }) => {
  904  |   const first = permit('intent-first', 'First exact group member')
  905  |   const second = permit('intent-second', 'Second exact group member')
  906  |   for (const [record, groupId] of [[first, 'intent-group-a'], [second, 'intent-group-b']] as const) {
  907  |     record.group_id = groupId
  908  |     record.group_title = groupId
  909  |     record.group_total_filtered = 2
  910  |     record.group_loaded_on_page = 1
  911  |     record.group_complete_on_page = false
  912  |   }
  913  |   let releaseFirst: (() => void) | undefined
  914  |   const firstGate = new Promise<void>((resolve) => { releaseFirst = resolve })
  915  |   let firstStarted = false
  916  |   let failSecond = false
  917  |   await page.route(apiRoute, async (route) => {
  918  |     const url = new URL(route.request().url())
  919  |     if (url.pathname === '/api/opportunities') {
  920  |       const payload = partialServerOpportunityPage([first, second])
  921  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  922  |       return
  923  |     }
  924  |     if (url.pathname.startsWith('/api/opportunity-groups/')) {
  925  |       if (url.pathname.endsWith('intent-group-a')) {
  926  |         firstStarted = true
  927  |         await firstGate
  928  |         await route.fulfill({ status: 503, json: { detail: 'synthetic stale group failure' } })
  929  |         return
  930  |       }
  931  |       if (failSecond) {
  932  |         await route.fulfill({ status: 503, json: { detail: 'synthetic current group failure' } })
  933  |         return
  934  |       }
  935  |       await route.fulfill({ status: 200, json: { items: [second], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  936  |       return
  937  |     }
  938  |     const body = url.pathname === '/api/auth/session'
  939  |       ? { authenticated: true }
  940  |       : url.pathname === '/api/health'
  941  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  942  |         : []
  943  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  944  |   })
  945  |   try {
  946  |     await page.goto('/?tier=Signals')
  947  |     await page.locator('[data-opportunity-id="intent-first"]').click()
  948  |     await expect.poll(() => firstStarted).toBe(true)
  949  |     await page.locator('[data-opportunity-id="intent-second"]').click()
  950  |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  951  |     releaseFirst?.()
  952  |     await expect(page.locator('.project-members [data-opportunity-id="intent-second"]')).toBeVisible()
  953  |     await expect(page.locator('.project-members [data-opportunity-id="intent-first"]')).toHaveCount(0)
  954  | 
> 955  |     await page.locator('[data-opportunity-id="intent-second"]').click()
       |                                                                 ^ Error: locator.click: Error: strict mode violation: locator('[data-opportunity-id="intent-second"]') resolved to 2 elements:
  956  |     await expect(page.locator('.project-members')).toHaveCount(0)
  957  |     failSecond = true
  958  |     await page.locator('[data-opportunity-id="intent-second"]').click()
  959  |     await expect(page.getByRole('alert')).toContainText('503')
  960  |     await expect(page.locator('.project-members')).toHaveCount(0)
  961  |   } finally {
  962  |     releaseFirst?.()
  963  |   }
  964  | })
  965  | 
  966  | test('reclicking a pending group cancels its expansion and selected-record navigation supersedes it', async ({ page }) => {
  967  |   const grouped = permit('pending-group-member', 'Pending group member')
  968  |   grouped.group_id = 'pending-group'
  969  |   grouped.group_title = 'Pending group'
  970  |   grouped.group_total_filtered = 2
  971  |   grouped.group_loaded_on_page = 1
  972  |   grouped.group_complete_on_page = false
  973  |   const selected = permit('pending-selection', 'Selected standalone record')
  974  |   selected.group_total_filtered = 1
  975  |   selected.group_loaded_on_page = 1
  976  |   selected.group_complete_on_page = true
  977  |   const groupReleases: (() => void)[] = []
  978  |   let groupRequests = 0
  979  |   await page.route(apiRoute, async (route) => {
  980  |     const url = new URL(route.request().url())
  981  |     if (url.pathname === '/api/opportunities') {
  982  |       const payload = partialServerOpportunityPage([grouped, selected])
  983  |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  984  |       return
  985  |     }
  986  |     if (url.pathname === '/api/opportunity-groups/pending-group') {
  987  |       groupRequests += 1
  988  |       await new Promise<void>((resolve) => { groupReleases.push(resolve) })
  989  |       await route.fulfill({ status: 200, json: { items: [grouped], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  990  |       return
  991  |     }
  992  |     const body = url.pathname === '/api/auth/session'
  993  |       ? { authenticated: true }
  994  |       : url.pathname === '/api/health'
  995  |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  996  |         : url.pathname.startsWith('/api/opportunities/needs/')
  997  |           ? selected
  998  |           : []
  999  |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1000 |   })
  1001 |   try {
  1002 |     await page.goto('/?tier=Signals')
  1003 |     const group = page.locator('[data-opportunity-id="pending-group-member"]')
  1004 |     await group.click()
  1005 |     await expect.poll(() => groupRequests).toBe(1)
  1006 |     await group.click()
  1007 |     groupReleases[0]?.()
  1008 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1009 |     await group.click()
  1010 |     await expect.poll(() => groupRequests).toBe(2)
  1011 |     await page.locator('[data-opportunity-id="pending-selection"]').click()
  1012 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Pending Selection')
  1013 |     groupReleases[1]?.()
  1014 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Pending Selection')
  1015 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1016 |   } finally {
  1017 |     for (const release of groupReleases) release()
  1018 |   }
  1019 | })
  1020 | 
  1021 | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  1022 |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  1023 |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  1024 |   let pageZeroRequests = 0
  1025 |   let releasePrevious: (() => void) | undefined
  1026 |   let previousStarted = false
  1027 |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  1028 |   await page.route(apiRoute, async (route) => {
  1029 |     const url = new URL(route.request().url())
  1030 |     if (url.pathname === '/api/opportunities') {
  1031 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1032 |       if (offset === 0) {
  1033 |         pageZeroRequests += 1
  1034 |         if (pageZeroRequests > 1) {
  1035 |           previousStarted = true
  1036 |           await previousGate
  1037 |         }
  1038 |       }
  1039 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1040 |       await route.fulfill({
  1041 |         status: 200,
  1042 |         contentType: 'application/json',
  1043 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1044 |         body: JSON.stringify(payload.items),
  1045 |       })
  1046 |       return
  1047 |     }
  1048 |     const path = url.pathname
  1049 |     const body = path === '/api/auth/session'
  1050 |       ? { authenticated: true }
  1051 |       : path === '/api/health'
  1052 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1053 |         : []
  1054 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1055 |   })
```