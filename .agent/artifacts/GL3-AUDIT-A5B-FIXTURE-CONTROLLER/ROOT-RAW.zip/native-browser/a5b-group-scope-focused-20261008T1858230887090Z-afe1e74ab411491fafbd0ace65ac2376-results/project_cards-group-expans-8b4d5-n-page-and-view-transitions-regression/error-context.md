# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> group expansion intent is invalidated by tier, search, Signal decision, page, and view transitions
- Location: tests\project_cards.spec.ts:1022:1

# Error details

```
Error: route.fulfill: Route is already handled!
```

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-opportunity-id="scope-prospect"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('[data-opportunity-id="scope-prospect"]') with timeout 5000ms
  - waiting for locator('[data-opportunity-id="scope-prospect"]')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Prospects" [level=1]
  - paragraph: Projects with sourced events that may warrant a power discovery conversation.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Prospects · 1 filtered project cards · 1 filtered opportunity records" [level=2]
  - paragraph: Browse the evidence and open a project for its source details.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - link "Download filtered CSV":
    - /url: /api/opportunities/export.csv?tier=Prospect&search=&decision=ALL&cohort_token=fixture-server-cohort
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - button "Group scope-signal 2100 BARTON SPRINGS RD, AUSTIN, TX Signal 1 of 2 related records":
    - strong: Group scope-signal
    - text: 2100 BARTON SPRINGS RD, AUSTIN, TX Signal 1 of 2 related records
  - text: 1 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  1001 |   })
  1002 |   try {
  1003 |     await page.goto('/?tier=Signals')
  1004 |     const group = page.locator('[data-opportunity-id="pending-group-member"]')
  1005 |     await group.click()
  1006 |     await expect.poll(() => groupRequests).toBe(1)
  1007 |     await group.click()
  1008 |     groupReleases[0]?.()
  1009 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1010 |     await group.click()
  1011 |     await expect.poll(() => groupRequests).toBe(2)
  1012 |     await page.locator('[data-opportunity-id="pending-selection"]').click()
  1013 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
  1014 |     groupReleases[1]?.()
  1015 |     await expect(page.getByRole('heading', { level: 1 })).toContainText('Selected Standalone Record')
  1016 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1017 |   } finally {
  1018 |     for (const release of groupReleases) release()
  1019 |   }
  1020 | })
  1021 | 
  1022 | test('group expansion intent is invalidated by tier, search, Signal decision, page, and view transitions', async ({ page }) => {
  1023 |   const scenarios = [
  1024 |     { name: 'tier', initialId: 'scope-signal', nextId: 'scope-prospect' },
  1025 |     { name: 'search', initialId: 'scope-signal', nextId: 'scope-search' },
  1026 |     { name: 'decision', initialId: 'scope-show', nextId: 'scope-review' },
  1027 |     { name: 'page', initialId: 'scope-page-first', nextId: 'scope-page-next' },
  1028 |     { name: 'view', initialId: 'scope-signal', nextId: '' },
  1029 |   ] as const
  1030 |   const records = new Map<string, Opportunity>()
  1031 |   for (const [id, action, options] of [
  1032 |     ['scope-signal', 'Signal scope activity', {}],
  1033 |     ['scope-prospect', 'Prospect scope activity', { tier: 'Prospect' }],
  1034 |     ['scope-search', 'newterm scope activity', {}],
  1035 |     ['scope-show', 'SHOW scope activity', { decision: 'SHOW' }],
  1036 |     ['scope-review', 'REVIEW scope activity', { decision: 'REVIEW' }],
  1037 |     ['scope-page-first', 'First page scope activity', {}],
  1038 |     ['scope-page-next', 'Next page scope activity', {}],
  1039 |   ] as const) {
  1040 |     const record = permit(id, action, options)
  1041 |     record.group_id = `group-${id}`
  1042 |     record.group_title = `Group ${id}`
  1043 |     record.group_total_filtered = 2
  1044 |     record.group_loaded_on_page = 1
  1045 |     record.group_complete_on_page = false
  1046 |     records.set(id, record)
  1047 |   }
  1048 |   let activeScenario: typeof scenarios[number] = scenarios[0]
  1049 |   let releaseGroup: (() => void) | undefined
  1050 |   let groupGate = Promise.resolve()
  1051 |   let groupStarted = false
  1052 |   let groupFinished = false
  1053 |   await page.route(apiRoute, async (route) => {
  1054 |     const url = new URL(route.request().url())
  1055 |     const path = url.pathname
  1056 |     if (path === '/api/opportunities') {
  1057 |       const tier = url.searchParams.get('tier')
  1058 |       const search = url.searchParams.get('search') ?? ''
  1059 |       const decision = url.searchParams.get('decision') ?? 'ALL'
  1060 |       const offset = Number(url.searchParams.get('offset') ?? 0)
  1061 |       const chosenId = tier === 'prospect' ? 'scope-prospect'
  1062 |         : search ? 'scope-search'
  1063 |           : decision === 'REVIEW' ? 'scope-review'
  1064 |             : offset > 0 ? 'scope-page-next'
  1065 |               : activeScenario.name === 'decision' ? 'scope-show'
  1066 |                 : activeScenario.name === 'page' ? 'scope-page-first' : 'scope-signal'
  1067 |       const record = records.get(chosenId)!
  1068 |       const payload = partialServerOpportunityPage([record])
  1069 |       const headers: Record<string, string> = { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset) }
  1070 |       if (activeScenario.name === 'page' && offset === 0) headers['X-Next-Offset'] = '25'
  1071 |       await route.fulfill({ status: 200, contentType: 'application/json', headers, body: JSON.stringify(payload.items) })
  1072 |       return
  1073 |     }
  1074 |     if (path.startsWith('/api/opportunity-groups/')) {
  1075 |       groupStarted = true
  1076 |       await groupGate
  1077 |       groupFinished = true
  1078 |       const groupId = path.split('/').at(-1) ?? ''
  1079 |       const record = [...records.values()].find((candidate) => candidate.group_id === groupId)!
  1080 |       await route.fulfill({ status: 200, json: { items: [record], total: 2, limit: 50, offset: 0, next_offset: null, cohort_token: 'fixture-server-cohort' } })
  1081 |       return
  1082 |     }
  1083 |     const body = path === '/api/auth/session'
  1084 |       ? { authenticated: true }
  1085 |       : path === '/api/health'
  1086 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1087 |         : []
  1088 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1089 |   })
  1090 |   try {
  1091 |   for (const scenario of scenarios) {
  1092 |     activeScenario = scenario
  1093 |     groupStarted = false
  1094 |     groupFinished = false
  1095 |     groupGate = new Promise<void>((resolve) => { releaseGroup = resolve })
  1096 |     await page.goto('/?tier=Signals')
  1097 |     await page.locator(`[data-opportunity-id="${scenario.initialId}"]`).click()
  1098 |     await expect.poll(() => groupStarted).toBe(true)
  1099 |     if (scenario.name === 'tier') {
  1100 |       await page.getByRole('button', { name: 'Prospects' }).click()
> 1101 |       await expect(page.locator('[data-opportunity-id="scope-prospect"]')).toBeVisible()
       |                                                                            ^ Error: expect(locator).toBeVisible() failed
  1102 |     } else if (scenario.name === 'search') {
  1103 |       await page.getByRole('textbox', { name: 'Search projects' }).fill('newterm')
  1104 |       await expect(page.locator('[data-opportunity-id="scope-search"]')).toBeVisible()
  1105 |     } else if (scenario.name === 'decision') {
  1106 |       await page.getByRole('button', { name: /^REVIEW/ }).click()
  1107 |       await expect(page.locator('[data-opportunity-id="scope-review"]')).toBeVisible()
  1108 |     } else if (scenario.name === 'page') {
  1109 |       await page.getByRole('button', { name: 'Next →' }).click()
  1110 |       await expect(page.locator('[data-opportunity-id="scope-page-next"]')).toBeVisible()
  1111 |     } else {
  1112 |       await page.getByRole('button', { name: 'Ingestion' }).click()
  1113 |       await expect(page.getByRole('heading', { name: 'Ingestion inbox' })).toBeVisible()
  1114 |     }
  1115 |     releaseGroup?.()
  1116 |     await expect.poll(() => groupFinished).toBe(true)
  1117 |     await expect(page.locator('.project-members')).toHaveCount(0)
  1118 |     if (scenario.nextId) await expect(page.locator(`[data-opportunity-id="${scenario.nextId}"]`)).toBeVisible()
  1119 |   }
  1120 |   } finally {
  1121 |     releaseGroup?.()
  1122 |     await page.unroute(apiRoute)
  1123 |   }
  1124 | })
  1125 | 
  1126 | test('Previous hides later-page rows and metadata until the first-page request settles', async ({ page }) => {
  1127 |   const firstPageRecord = permit('transition-first-page', 'First page transition fixture')
  1128 |   const laterPageRecord = permit('transition-later-page', 'Later page transition fixture')
  1129 |   let pageZeroRequests = 0
  1130 |   let releasePrevious: (() => void) | undefined
  1131 |   let previousStarted = false
  1132 |   const previousGate = new Promise<void>((resolve) => { releasePrevious = resolve })
  1133 |   await page.route(apiRoute, async (route) => {
  1134 |     const url = new URL(route.request().url())
  1135 |     if (url.pathname === '/api/opportunities') {
  1136 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1137 |       if (offset === 0) {
  1138 |         pageZeroRequests += 1
  1139 |         if (pageZeroRequests > 1) {
  1140 |           previousStarted = true
  1141 |           await previousGate
  1142 |         }
  1143 |       }
  1144 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1145 |       await route.fulfill({
  1146 |         status: 200,
  1147 |         contentType: 'application/json',
  1148 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1149 |         body: JSON.stringify(payload.items),
  1150 |       })
  1151 |       return
  1152 |     }
  1153 |     const path = url.pathname
  1154 |     const body = path === '/api/auth/session'
  1155 |       ? { authenticated: true }
  1156 |       : path === '/api/health'
  1157 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  1158 |         : []
  1159 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  1160 |   })
  1161 |   try {
  1162 |     await page.goto('/?tier=Signals&offset=25')
  1163 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toBeVisible()
  1164 |     await page.getByRole('button', { name: '← Previous' }).click()
  1165 |     await expect.poll(() => previousStarted).toBe(true)
  1166 |     await expect(page.getByText('Updating this view…')).toBeVisible()
  1167 |     await expect(page.locator('[data-opportunity-id="transition-later-page"]')).toHaveCount(0)
  1168 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toHaveCount(0)
  1169 |     await expect(page.getByRole('heading', { name: 'No Signals yet' })).toHaveCount(0)
  1170 |     await expect(page.getByText('1 filtered records · page 1')).toHaveCount(0)
  1171 |     expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  1172 |     expect(new URL(page.url()).hash).toBe('')
  1173 |     releasePrevious?.()
  1174 |     await expect(page.locator('[data-opportunity-id="transition-first-page"]')).toBeVisible()
  1175 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  1176 |     await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  1177 |   } finally {
  1178 |     releasePrevious?.()
  1179 |   }
  1180 | })
  1181 | 
  1182 | test('Next hides first-page rows and metadata until the later-page request settles', async ({ page }) => {
  1183 |   const firstPageRecord = permit('transition-next-first-page', 'First page Next fixture')
  1184 |   const laterPageRecord = permit('transition-next-later-page', 'Later page Next fixture')
  1185 |   let releaseNext: (() => void) | undefined
  1186 |   let nextStarted = false
  1187 |   const nextGate = new Promise<void>((resolve) => { releaseNext = resolve })
  1188 |   await page.route(apiRoute, async (route) => {
  1189 |     const url = new URL(route.request().url())
  1190 |     if (url.pathname === '/api/opportunities') {
  1191 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  1192 |       if (offset > 0) {
  1193 |         nextStarted = true
  1194 |         await nextGate
  1195 |       }
  1196 |       const payload = serverOpportunityPage([offset === 0 ? firstPageRecord : laterPageRecord])
  1197 |       await route.fulfill({
  1198 |         status: 200,
  1199 |         contentType: 'application/json',
  1200 |         headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': String(offset), 'X-Cohort-Token': 'transition-next-token', ...(offset === 0 ? { 'X-Next-Offset': '25' } : {}) },
  1201 |         body: JSON.stringify(payload.items),
```