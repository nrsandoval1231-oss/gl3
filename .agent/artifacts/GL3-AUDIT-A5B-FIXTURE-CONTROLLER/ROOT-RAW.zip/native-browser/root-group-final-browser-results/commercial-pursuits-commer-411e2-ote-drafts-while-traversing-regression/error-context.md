# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: commercial-pursuits.spec.ts >> commercial pages report all-group totals and preserve note drafts while traversing
- Location: tests\commercial-pursuits.spec.ts:175:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('.pursuit-position')
Expected: "51"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" locator('.pursuit-position') with timeout 5000ms
  - waiting for locator('.pursuit-position')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - region "Commercial pursuits":
    - paragraph: Retained Signals · Commercial work queue
    - heading "What should we work today?" [level=1]
    - paragraph: Evidence-backed pursuits with clear next steps. Power, supply, timing and buying roles stay unknown until sources support them.
    - button "Evaluate Signals"
    - region "Current cohort summary":
      - text: All eligible groups
      - strong: "51"
      - text: ACTION NOW · this page
      - strong: "0"
      - text: RESEARCH · this page
      - strong: "1"
      - text: WATCH · this page
      - strong: "0"
      - text: REJECT · this page
      - strong: "0"
      - text: Today · 2 evaluated · 1 surfaced · 0 contacted · — buyer reached · — qualified · 0 Prospects · 0 Leads · Unknown supported MW
      - group: 1 metric limits
    - region "Research-related changes":
      - heading "Research-related changes" [level=2]
      - paragraph: Research change history is unavailable in this response.
    - heading "ACTION NOW · 0 pursuits on this page" [level=2]
    - paragraph: Page 2 · 1 saved cards · 51 eligible groups overall · disposition counts below are page-scoped · queue refreshed 10/3/2026, 9:00:00 AM
    - text: Search commercial pursuits on this page
    - textbox "Search commercial pursuits on this page":
      - /placeholder: "Search this page: project, company, site"
    - group "Filter pursuit state":
      - button "ACTION NOW 0" [pressed]
      - button "RESEARCH 1"
      - button "WATCH 0"
      - button "REJECT 0"
    - heading "No action now pursuits" [level=3]
    - paragraph: The current retained cohort has no candidates in this state.
    - navigation "Commercial pursuit pages":
      - button "Previous page"
      - text: 1 cards on this page · 51 eligible groups overall
      - button "Next page" [disabled]
    - group: Saved evaluation history · snapshots and earlier versions
    - group: Saved research workspace and call history
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  109 |   await expect(page.locator('.commercial-detail')).toContainText('Group review question: What is the electrical load and energization window for this construction phase?')
  110 |   expect(await contrastRatio(page.locator('.commercial-toolbar h2'))).toBeGreaterThanOrEqual(4.5)
  111 |   expect(await contrastRatio(page.locator('.buying-chain h3').first())).toBeGreaterThanOrEqual(4.5)
  112 |   expect(await contrastRatio(page.locator('.buying-chain-note').first())).toBeGreaterThanOrEqual(4.5)
  113 |   expect(await contrastRatio(page.locator('.buying-chain a').last())).toBeGreaterThanOrEqual(4.5)
  114 |   await expect(page.getByRole('heading', { name: 'Buying chain' }).first()).toBeVisible()
  115 |   await expect(page.locator('.buying-chain')).toContainText('Avery Chen')
  116 |   await expect(page.locator('.buying-chain')).toContainText('Person → project')
  117 |   await expect(page.locator('.buying-chain')).toContainText('Project relationship unknown')
  118 |   await expect(page.locator('.commercial-project-chain')).toHaveCount(1)
  119 |   await page.getByRole('button', { name: 'Project 2 · related record' }).click()
  120 |   await expect(page.locator('.commercial-project-chain-label')).toContainText('related project record')
  121 |   await page.getByRole('button', { name: 'Project 1 · primary record' }).click()
  122 |   await expect(page.locator('.commercial-timeline')).toContainText('Under construction')
  123 |   await expect(page.locator('.commercial-timeline')).toContainText('2026-09-28')
  124 |   await expect(page.locator('.commercial-timeline')).toContainText('superseded source state')
  125 |   await expect(page.locator('.commercial-history-note')).toContainText('do not establish a verified power start window')
  126 |   await expect(page.locator('.commercial-timeline a').first()).toHaveAttribute('href', 'https://example.test/timeline')
  127 |   const question = 'What is the electrical load and energization window for this construction phase?'
  128 |   await page.getByLabel('Exact missing-fact question').fill(question)
  129 |   await page.locator('.commercial-card-heading').click()
  130 |   await page.locator('.commercial-card-heading').click()
  131 |   await expect(page.getByLabel('Exact missing-fact question')).toHaveValue(question)
  132 |   await page.locator('.commercial-filters button').nth(1).click()
  133 |   await expect(page.locator('.commercial-card-heading')).toContainText('South Ridge Works')
  134 |   await page.locator('.commercial-filters button').first().click()
  135 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  136 |   await page.goBack()
  137 |   await expect(page.getByLabel('Exact missing-fact question')).toHaveValue(question)
  138 |   await page.getByRole('button', { name: 'Research this question' }).click()
  139 |   await expect(page.getByRole('status').filter({ hasText: 'Research result' })).toBeVisible()
  140 |   await expect(page.locator('.commercial-research-result')).toContainText('Source review confirms the filing stage.')
  141 |   await expect(page.locator('.commercial-research-result a').first()).toHaveAttribute('href', 'https://example.test/fact')
  142 |   expect(captured.receivedQuestion).toBe(question)
  143 |   expect(captured.statusQuestion).toBe(question)
  144 |   expect(captured.statusCalls).toBeGreaterThanOrEqual(2)
  145 |   expect(captured.researchCalls).toBe(1)
  146 |   const noteText = 'Operator reported a follow-up is needed.'
  147 |   await page.locator('.commercial-action textarea').nth(1).fill(noteText)
  148 |   await page.getByLabel('Reported outcome').selectOption('Reached buying organization')
  149 |   await page.locator('.commercial-card-heading').click()
  150 |   await page.locator('.commercial-card-heading').click()
  151 |   await expect(page.locator('.commercial-action textarea').nth(1)).toHaveValue(noteText)
  152 |   await page.getByLabel('Reported outcome').selectOption('Reached buying organization')
  153 |   await page.getByRole('button', { name: 'Save note' }).click()
  154 |   await expect(page.getByRole('status').filter({ hasText: '503' })).toBeVisible()
  155 |   await page.getByRole('button', { name: 'Save note' }).click()
  156 |   await expect(page.getByText('Note saved to this pursuit. Evidence tier unchanged.')).toBeVisible()
  157 |   expect(captured.savedNote?.note).toBe(noteText)
  158 |   expect(captured.noteIds).toHaveLength(2)
  159 |   expect(captured.noteIds[0]).toBe(captured.noteIds[1])
  160 |   await expect(page.locator('.commercial-note')).toContainText(noteText)
  161 |   await page.reload()
  162 |   await page.locator('.commercial-card-heading').click()
  163 |   await expect(page.locator('.commercial-note')).toContainText(noteText)
  164 |   await page.locator('.commercial-filters button').nth(1).click()
  165 |   await expect(page.locator('.commercial-card')).toHaveCount(1)
  166 |   await expect(page.locator('.commercial-card-heading')).toContainText('South Ridge Works')
  167 |   await page.getByRole('button', { name: 'Signals', exact: true }).click()
  168 |   await page.goBack()
  169 |   await expect(page.locator('.commercial-filters button').nth(1)).toHaveAttribute('aria-pressed', 'true')
  170 |   await expect(page.locator('.commercial-card-heading')).toContainText('South Ridge Works')
  171 |   await page.locator('.commercial-filters button').first().click()
  172 |   await expect(page.locator('.commercial-card-heading')).toContainText('Northstar Campus')
  173 | })
  174 | 
  175 | test('commercial pages report all-group totals and preserve note drafts while traversing', async ({ page }) => {
  176 |   await useCommercialFixture(page)
  177 |   const firstPage: CommercialTriage = {
  178 |     ...base,
  179 |     total: 1,
  180 |     limit: 50,
  181 |     offset: 0,
  182 |     grouped_total: 51,
  183 |     next_offset: 50,
  184 |     cohort_counts: { action_now: 1, research: 0, watch: 0, reject: 0 },
  185 |     items: [base.items[0]],
  186 |   }
  187 |   const secondPage: CommercialTriage = {
  188 |     ...base,
  189 |     total: 1,
  190 |     limit: 50,
  191 |     offset: 50,
  192 |     grouped_total: 51,
  193 |     next_offset: null,
  194 |     cohort_counts: { action_now: 0, research: 1, watch: 0, reject: 0 },
  195 |     items: [base.items[1]],
  196 |   }
  197 |   await page.route(/\/api\/commercial\/triage\?/, (route) => {
  198 |     const offset = Number(new URL(route.request().url()).searchParams.get('offset') ?? 0)
  199 |     return route.fulfill({ json: offset ? secondPage : firstPage })
  200 |   })
  201 |   await page.goto('/?view=pursuits')
  202 |   await expect(page.getByText('All eligible groups').locator('..')).toContainText('51')
  203 |   await expect(page.getByText(/eligible groups overall/).first()).toContainText('51')
  204 |   await page.locator('.commercial-card-heading').first().click()
  205 |   const noteDraft = 'Keep this unsaved operator note across pages.'
  206 |   await page.locator('.commercial-action textarea').nth(1).fill(noteDraft)
  207 |   const pager = page.getByRole('navigation', { name: 'Commercial pursuit pages' })
  208 |   await pager.getByRole('button', { name: 'Next page' }).click()
> 209 |   await expect(page.locator('.pursuit-position')).toHaveText('51')
      |                                                   ^ Error: expect(locator).toHaveText(expected) failed
  210 |   await pager.getByRole('button', { name: 'Previous page' }).click()
  211 |   await page.locator('.commercial-card-heading').first().click()
  212 |   await expect(page.locator('.commercial-action textarea').nth(1)).toHaveValue(noteDraft)
  213 | })
  214 | 
  215 | test('commercial targeted research reports unavailable response', async ({ page }) => {
  216 |   const captured = await useCommercialFixture(page, 503)
  217 |   await page.locator('.commercial-card-heading').click()
  218 |   await page.getByRole('button', { name: 'Research this question' }).click()
  219 |   await expect(page.getByRole('alert').filter({ hasText: '503' })).toBeVisible()
  220 |   expect(captured.receivedQuestion).toContain('energization window')
  221 | })
  222 | 
  223 | test('targeted research polling resumes after detail collapse without posting the question again', async ({ page }) => {
  224 |   const captured = await useCommercialFixture(page)
  225 |   await page.locator('.commercial-card-heading').click()
  226 |   await page.getByRole('button', { name: 'Research this question' }).click()
  227 |   await expect.poll(() => captured.statusCalls).toBeGreaterThan(0)
  228 |   await page.locator('.commercial-card-heading').click()
  229 |   const callsAtCollapse = captured.statusCalls
  230 |   await page.waitForTimeout(1750)
  231 |   expect(captured.statusCalls).toBe(callsAtCollapse)
  232 |   await page.locator('.commercial-card-heading').click()
  233 |   await expect(page.locator('.commercial-research-result')).toContainText('Source review confirms the filing stage.')
  234 |   expect(captured.researchCalls).toBe(1)
  235 |   expect(captured.statusQuestion).toContain('energization window')
  236 | })
  237 | 
  238 | test('explicit Signals entry does not request or mount hidden commercial triage', async ({ page }) => {
  239 |   let triageRequests = 0
  240 |   await page.route('**/api/auth/session', (route) => route.fulfill({ json: { authenticated: true } }))
  241 |   await page.route('**/api/health', (route) => route.fulfill({ json: { sources: [], backlog: 0, pending_interpretations: 0 } }))
  242 |   await page.route('**/api/changes', (route) => route.fulfill({ json: [] }))
  243 |   await page.route('**/api/opportunities*', (route) => route.fulfill({ json: [] }))
  244 |   await page.route('**/api/commercial/triage*', async (route) => {
  245 |     triageRequests += 1
  246 |     await route.fulfill({ json: [] })
  247 |   })
  248 |   await page.goto('/?tier=Signals')
  249 |   await expect(page.getByRole('heading', { name: 'Signals', exact: true })).toBeVisible()
  250 |   await expect(page.getByRole('button', { name: 'All 0' })).toBeVisible()
  251 |   await page.waitForLoadState('networkidle')
  252 |   expect(triageRequests).toBe(0)
  253 | })
  254 | 
  255 | test('default root previews commercial work with an explicit full queue path', async ({ page }) => {
  256 |   await page.route('**/api/auth/session', (route) => route.fulfill({ json: { authenticated: true } }))
  257 |   await page.route('**/api/health', (route) => route.fulfill({ json: { sources: [], backlog: 0, pending_interpretations: 0 } }))
  258 |   await page.route('**/api/changes', (route) => route.fulfill({ json: [] }))
  259 |   await page.route('**/api/opportunities*', (route) => route.fulfill({ json: [] }))
  260 |   await page.route('**/api/commercial/triage?limit=50', (route) => route.fulfill({ json: base }))
  261 |   await page.goto('/')
  262 |   await expect(page.getByRole('heading', { name: 'What should we work today?' })).toBeVisible()
  263 |   await expect(page.locator('.commercial-today-entry')).toContainText('Northstar Campus')
  264 |   await expect(page.locator('.commercial-today-entry')).toContainText('Required power Unknown')
  265 |   await expect(page.getByRole('heading', { name: 'Signals', exact: true })).toBeVisible()
  266 |   await page.getByRole('button', { name: 'Open full pursuit queue' }).click()
  267 |   await expect(page).toHaveURL(/view=pursuits/)
  268 |   await expect(page.getByRole('heading', { name: 'What should we work today?' })).toBeVisible()
  269 | })
  270 | 
  271 | test('watch-only commercial cohort is not described as empty or actionable', async ({ page }) => {
  272 |   const watchOnly = structuredClone(base)
  273 |   watchOnly.items = [{ ...watchOnly.items[0], disposition: 'WATCH', watch: { event: 'Utility service plan filing', date: '2026-11-01', source_url: 'https://example.test/watch' } }]
  274 |   watchOnly.total = 1
  275 |   watchOnly.cohort_counts = { action_now: 0, research: 0, watch: 1, reject: 0 }
  276 |   await page.route('**/api/auth/session', (route) => route.fulfill({ json: { authenticated: true } }))
  277 |   await page.route('**/api/health', (route) => route.fulfill({ json: { sources: [], backlog: 0, pending_interpretations: 0 } }))
  278 |   await page.route('**/api/changes', (route) => route.fulfill({ json: [] }))
  279 |   await page.route('**/api/opportunities*', (route) => route.fulfill({ json: [] }))
  280 |   await page.route('**/api/commercial/triage?limit=50', (route) => route.fulfill({ json: watchOnly }))
  281 |   await page.goto('/')
  282 |   const preview = page.locator('.commercial-today-entry')
  283 |   await expect(preview).toContainText('No ACTION NOW or RESEARCH action is currently available.')
  284 |   await expect(preview).toContainText('WATCH trigger: Utility service plan filing')
  285 |   await expect(preview).not.toContainText('No candidates are currently retained')
  286 | })
  287 | 
  288 | test('malformed default commercial preview fails visibly without a false empty cohort', async ({ page }) => {
  289 |   const pageErrors: string[] = []
  290 |   page.on('pageerror', (error) => pageErrors.push(error.message))
  291 |   await page.route('**/api/auth/session', (route) => route.fulfill({ json: { authenticated: true } }))
  292 |   await page.route('**/api/health', (route) => route.fulfill({ json: { sources: [], backlog: 0, pending_interpretations: 0 } }))
  293 |   await page.route('**/api/changes', (route) => route.fulfill({ json: [] }))
  294 |   await page.route('**/api/opportunities*', (route) => route.fulfill({ json: [] }))
  295 |   await page.route('**/api/commercial/triage?limit=50', (route) => route.fulfill({ json: {} }))
  296 |   await page.goto('/')
  297 |   await expect(page.locator('.commercial-today-entry').getByRole('heading', { name: 'What should we work today?' })).toBeVisible()
  298 |   await expect(page.locator('.commercial-today-entry').getByRole('alert')).toContainText('incomplete data')
  299 |   await expect(page.locator('.commercial-today-entry')).not.toContainText('No candidates are currently retained')
  300 |   await expect(page.locator('.commercial-summary')).toHaveCount(0)
  301 |   await expect(page.locator('.commercial-filters')).toHaveCount(0)
  302 |   await expect(page.locator('.commercial-list .empty')).toHaveCount(0)
  303 |   await expect(page.getByRole('heading', { name: 'Signals', exact: true })).toBeVisible()
  304 |   await expect(page.getByRole('button', { name: 'All 0' })).toBeVisible()
  305 |   expect(pageErrors).toEqual([])
  306 | })
  307 | 
  308 | test('commercial queue stays behind sign-in until the authenticated session is established', async ({ page }) => {
  309 |   await page.route('**/api/auth/session', (route) => route.fulfill({ status: 401, json: { detail: 'Not authenticated' } }))
```