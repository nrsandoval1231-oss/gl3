import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
target = repo / '.agent' / 'artifacts' / 'GL3-AUDIT-A5A-CONTROLLER'
if target.exists():
    raise RuntimeError('Refusing artifact overwrite')
target.mkdir(parents=True)
inputs = sorted([path for path in (repo / '.artifacts').glob('root-a5*') if path.is_file()] + [path for path in (repo / '.artifacts' / 'A5A' / 'logs').rglob('*') if path.is_file()])
records = []
archive_path = target / 'ROOT-RAW.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in inputs:
        data = path.read_bytes()
        name = str(path.relative_to(repo / '.artifacts')).replace('\\', '/')
        archive.writestr(name, data)
        records.append({'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive_path) as archive:
    if len(archive.infolist()) != len(records):
        raise RuntimeError('Archive entry mismatch')
    for record in records:
        data = archive.read(record['name'])
        if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
            raise RuntimeError('Archive byte verification failed')
manifest = {'source_candidate': '067d5d6e9f76c03954b0d6242b9efd87c4453f5c', 'source_tree': '92eef5b352c363f8fb56a07de250c4decdbc3527', 'created_utc': datetime.now(timezone.utc).isoformat(), 'archive': archive_path.name, 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'entries': records, 'verification': 'Every archived entry byte/hash verified', 'exclusions': ['Private credentials/configuration files', 'Retained corpus payload snapshots', 'Secret-bearing diagnostic originals removed with explicit hash/redaction receipts', 'Original overwritten diagnostic bytes unavailable UNKNOWN']}
(target / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
state = repo / '.agent' / 'CURRENT_STATE.md'
data = state.read_bytes()
(target / 'CURRENT_STATE.pre-root-gates.md').write_bytes(data)
(target / 'CURRENT_STATE.PROVENANCE.json').write_text(json.dumps({'archived_sha256': hashlib.sha256(data).hexdigest(), 'source': '.agent/CURRENT_STATE.md', 'purpose': 'Archive frozen implementation state before root gate reconciliation'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'entries': len(records), 'archive_sha256': manifest['archive_sha256'], 'verification': manifest['verification']}))
