import hashlib
import json
import os
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
scope = (repo / '.artifacts' / 'A5A' / 'logs').resolve()
report_path = repo / '.artifacts' / 'root-a5-r1-diagnostic-redactions.json'
if report_path.exists():
    raise RuntimeError('Refusing overwrite')
key = os.environ.get('FIRECRAWL_API_KEY', '')
if len(key) < 24:
    raise RuntimeError('Known credential unavailable for verified redaction')
body = key[3:] if key.startswith('fc-') else key
needles = [key.encode(), body[:16].encode(), body[-12:].encode()]
entries = []
for name in ('benchmark-output-guard-red-20261008.log', 'focused-full-final-20261008.log'):
    source = (scope / name).resolve()
    if not source.is_relative_to(scope) or source.parent != scope:
        raise RuntimeError('Out-of-scope diagnostic')
    target = source.with_name(source.stem + '-redacted-20261008.log')
    if target.exists():
        raise RuntimeError('Refusing redacted copy overwrite')
    data = source.read_bytes()
    if not any(needle in data for needle in needles):
        raise RuntimeError('Expected credential fragment not found')
    redacted = b''.join(
        b'[REDACTED validation input: provider credential fragment omitted]\r\n'
        if b'input_value=' in line or any(needle in line for needle in needles) else line
        for line in data.splitlines(keepends=True)
    )
    if any(needle in redacted for needle in needles):
        raise RuntimeError('Redaction incomplete')
    with target.open('xb') as stream:
        stream.write(redacted)
    entries.append({'original_path': str(source.relative_to(repo)), 'original_sha256': hashlib.sha256(data).hexdigest(), 'redacted_path': str(target.relative_to(repo)), 'redacted_sha256': hashlib.sha256(redacted).hexdigest(), 'reason': 'Ignored diagnostic contained actual provider credential fragment; preserve classification and original hash, exclude original bytes', 'original_bytes_retention': 'REMOVED_FOR_CREDENTIAL_PROTECTION'})
with report_path.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps({'scope': str(scope.relative_to(repo)), 'entries': entries, 'git_content_matches': 0}, indent=2) + '\n')
for entry in entries:
    source = (repo / entry['original_path']).resolve()
    if not source.is_relative_to(scope) or source.parent != scope:
        raise RuntimeError('Out-of-scope removal')
    source.unlink()
print(json.dumps({'redacted_diagnostics': len(entries), 'original_hashes_retained': True, 'values_emitted': False}))
