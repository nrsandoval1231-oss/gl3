import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
output = Path(sys.argv[1])
if output.exists():
    raise RuntimeError('Refusing overwrite')
secrets = []
for name in ('FIRECRAWL_API_KEY', 'OPENAI_API_KEY', 'TYPESAFE_API_KEY', 'SESSION_SECRET', 'APP_PASSWORD_HASH', 'GRIDLENS_TEST_PASSWORD'):
    value = os.environ.get(name)
    if value and len(value) >= 16:
        secrets.append((name, value))
private_env = repo.parent / 'gl3-audit-repair-20261007' / '.env'
private_password = repo.parent / 'gl3-audit-repair-20261007' / '.artifacts' / 'local-auth.txt'
password_lines = private_password.read_text(encoding='utf-8-sig').splitlines()
if len(password_lines) > 1 and len(password_lines[1]) >= 8:
    secrets.append(('GRIDLENS_TEST_PASSWORD', password_lines[1]))
for line in private_env.read_text(encoding='utf-8-sig').splitlines():
    name, _, value = line.partition('=')
    if name in ('APP_PASSWORD_HASH', 'SESSION_SECRET') and len(value) >= 16:
        secrets.append((name, value.strip().strip('\"\'')))
needles = []
for name, value in secrets:
    needles.append((name, 'full', value.encode()))
    body = value[7:] if value.startswith('$2') else value[3:] if value.startswith('fc-') else value
    if len(body) >= 24:
        needles.extend(((name, 'partial_prefix', body[:16].encode()), (name, 'partial_suffix', body[-12:].encode())))
hits = []
checked = 0
def scan(label, data):
    global checked
    checked += 1
    for name, kind, needle in needles:
        if needle in data:
            hits.append({'file': label, 'secret': name, 'match_kind': kind})
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for entry in archive.infolist():
                if not entry.is_dir():
                    scan(label + '::' + entry.filename, archive.read(entry))
commits = subprocess.check_output(['git', 'rev-list', '5c03880584f6aacae95a81ab2231a80e63503cc8..HEAD'], cwd=repo, text=True).splitlines()
for commit in commits:
    paths = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=repo, text=True).splitlines()
    for path in paths:
        raw = subprocess.run(['git', 'show', commit + ':' + path], cwd=repo, capture_output=True)
        if raw.returncode == 0:
            scan(commit + ':' + path, raw.stdout)
for path in (repo / '.artifacts' / 'A5A' / 'logs').rglob('*'):
    if path.is_file():
        scan(str(path.relative_to(repo)), path.read_bytes())
for path in (repo / '.artifacts').glob('root-a5*'):
    if path.is_file() and path != output:
        scan(str(path.relative_to(repo)), path.read_bytes())
report = {'candidate': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(), 'commits_checked': len(commits), 'content_entries_checked': checked, 'secret_names_checked': sorted({name for name, _ in secrets}), 'hits': hits, 'scope': 'Known task secrets and unique prefix/suffix fragments; new commit blobs and task logs; values never emitted'}
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))
raise SystemExit(bool(hits))
