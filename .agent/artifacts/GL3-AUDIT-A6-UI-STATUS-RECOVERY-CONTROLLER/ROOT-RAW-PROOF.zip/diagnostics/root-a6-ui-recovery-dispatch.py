import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
output = root / '.agent/artifacts/GL3-AUDIT-A6-UI-STATUS-RECOVERY-DISPATCH'
paths = ('.agent/CURRENT_STATE.md', '.agent/WORK_GRAPH.md')
entries = []
with zipfile.ZipFile(output / 'PRIOR-STATE.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for name in paths:
        data = (root / name).read_bytes()
        archive.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with (output / 'PRESERVATION.json').open('x') as saved:
    json.dump({'rejected_head': 'ce3a03bf8e7bef6f4a4edc212c8c77fd31e175ec', 'raw_review_sha256': '9c2d1290807cc01b702140ce998a27718b5b5d6c549580f407dd1d07697b5415', 'prior_state': entries}, saved, indent=2)
(root / paths[0]).write_text('''# Current state — GL3 audit repair

Parent OPEN. Bounded A3/A9/A1/A2/A4/A5A/A5B and A6 backend remain separately independently accepted. PR43 exact accepted backend daedade06adc0dbe18fb09c46a5dcfc2444681f5 is published with successful CI. Main94c3acb and remote join5c038805 remain unchanged. No merge/deployment, paid activation or external sends authorized.

A6 UI/status candidate ce3a03bf8e7bef6f4a4edc212c8c77fd31e175ec/treecb8eaee9 was independently FIX/CORRECT despite full1471 backend and72 browser plus separate persisted1 PASS. Raw review SHA9c2d1290807cc01b702140ce998a27718b5b5d6c549580f407dd1d07697b5415 preserved in recovery dispatch. All278 source/Git hashes and223 final archive entries matched; original24 table fingerprints and dump checksum unchanged.

Findings: a status POST persisted with lost reply is idempotently replayed as its original event, but UI wrongly predicts a new version and never confirms; recent history shows oldest ten of latest100. Controller reconstructed exact server contract: GET omits client_id, so matching visible version/text alone cannot identify the pending key. Confirmation requires same-key POST event identity plus exact read-back; unresolved events remain UNKNOWN. No backend/admission redesign.

Sole READY node A6-UI-STATUS-RECOVERY, one Luna after dispatch commit. Ownership FactWorkflowPanel.tsx/call-facts.spec.ts plus new evidence only. Packet GL3-AUDIT-A6-UI-STATUS-RECOVERY.md SHA13c0f3a98347a00dd046a3444fe6e63ed471a1bd705e0bfe795f8324883678e9. Preserve earlier frozen source, failures and immutable original/saved evidence. Root reruns frozen gates and fresh Sol review after clean handoff.

A8A prepared packet remains DEPENDENT on exact UI PASS; A8B/authentic feeds/quality/seven-day/customer gates OPEN. A7 checksum-matching original PNG/HTML absent, video supplemental. Model/config/unmeasured tokens UNKNOWN. Direction CORRECT; no parent completion or UI publication.
''', encoding='utf-8')
(root / paths[1]).write_text('''# Work graph — GL3 audit frontier

Parent OPEN; canonical PRD, Finish Contract and protected reference manifest govern. Prior state/graph and exact rejected review preserved under recovery dispatch.

- ACCEPTED bounded A3/A9/A1/A2/A4/A5A/A5B and A6 backend, draftPR43, CI success. No merge/deploy.
- FIX A6 UI/status ce3a03bf/treecb8eaee9, ordinary review9c2d1290. Green gates do not override lost-response recovery and recent-history findings. Original backend acceptance remains separate.
- READY A6-UI-STATUS-RECOVERY, sole Luna, packet GL3-AUDIT-A6-UI-STATUS-RECOVERY.md. Exact event/idempotent read-back and newest-ten history; two UI files only, no backend/API/policy/schema/style changes.
- DEPENDENT root exact-frozen full gates and fresh ordinary Sol review; A8A prepared operational packet waits for PASS and actual resources, A8B follows. Authentic feed/quality/cycle/customer proof OPEN.
- EXTERNAL A7 original PNG/HTML absent; video supplemental, visual identity protected.

Direction CORRECT. Preserve ambiguous UNKNOWN, immutable source/saved history, originals and all attempts. No new parallel builder, paid/provider activation, external sends, merge/deploy or parent completion.
''', encoding='utf-8')
print(json.dumps({'dispatch': str(output), 'prior_state_files_preserved': len(entries), 'direction': 'CORRECT'}))
