import hashlib

import json

import subprocess

import sys

from pathlib import Path



root = Path(__file__).resolve().parents[1]

def git(*args):

    return subprocess.check_output(['git', '-C', str(root), *args])

head = git('rev-parse', 'HEAD').decode().strip()

assert head == sys.argv[1]

assert not git('status', '--porcelain').strip()

old = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-SELECTED-INTERVAL-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())

old_by_path = {x['path']: x for x in old['entries']}

paths = set(old_by_path) | set(git('ls-files', 'backend/src', 'backend/tests', 'web/src', 'web/tests').decode().splitlines())

packet_paths = ['.agent/packets/GL3-AUDIT-A6-TIMING-PROJECTION-INTEGRATION-REPAIR.md', '.agent/packets/GL3-AUDIT-A6-LOWER-TIER-TIMING-PROJECTION-AMENDMENT.md', '.agent/packets/GL3-AUDIT-A6-COMMERCIAL-EXACT-TARGET-PROOF-AMENDMENT.md']
packet_paths.append('.agent/packets/GL3-AUDIT-A6-SELECTED-INTERVAL-DIRECTION.md')
packet_paths.append('.agent/packets/GL3-AUDIT-A6-UI-STATUS-READY-20261008.md')
packet_paths.append('.agent/packets/GL3-AUDIT-A6-UI-BUYING-CHAIN-FIXTURE-REPAIR.md')
packet_paths.append('.agent/packets/GL3-AUDIT-A6-UI-STATUS-RECOVERY.md')
paths.update(packet_paths)
entries = []

for path in sorted(paths):

    entries.append({'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()})

accepted_head = 'daedade06adc0dbe18fb09c46a5dcfc2444681f5'
changed = git('diff', '--name-only', accepted_head, head, '--', 'backend', 'web', '.gitattributes', '.agent/packets').decode().splitlines()

allowed = {'backend/src/gridlens/api/app.py', 'backend/tests/integration/test_call_fact_workflow_integration.py', 'backend/tests/unit/test_browse_filters.py', 'backend/tests/unit/test_opportunity_browse.py', 'web/src/features/pursuits/CommercialPursuits.tsx', 'web/src/app/App.tsx', 'web/src/api/client.ts', 'web/src/api/openapi.json', 'web/src/api/generated.ts', 'web/tests/project_cards.spec.ts', 'web/tests/commercial-pursuits.spec.ts', 'web/tests/call-facts.spec.ts'}
new_components = {p for p in paths if p not in old_by_path and p.startswith('web/src/features/pursuits/') and p.endswith('.tsx')}
assert len(new_components) <= 1, new_components
allowed.update(new_components)
allowed.add('web/tests/buying_chain.spec.ts')
allowed.update(packet_paths)
assert set(changed) <= allowed, changed
source_changes = [path for path in changed if path.startswith(('backend/', 'web/'))]

output = root / '.agent/artifacts/GL3-AUDIT-A6-UI-STATUS-RECOVERY-CONTROLLER'

output.mkdir(exist_ok=False)

with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as stream:

    json.dump({'tested_head': head, 'accepted_backend_head': 'daedade06adc0dbe18fb09c46a5dcfc2444681f5', 'source_changes': source_changes, 'governing_packet_inputs': packet_paths, 'entries': entries}, stream, indent=2)

print(json.dumps({'tested_head': head, 'entries': len(entries), 'source_changes': source_changes, 'governing_packet_inputs': packet_paths}))

