import hashlib
import json`nimport os
from datetime import UTC, date, datetime
from pathlib import Path
from uuid import uuid4
from gridlens.persistence.database import SessionLocal
from gridlens.persistence.models import Evidence, Interpretation, NeedObservation, Observation, PowerNeed, Project, Source
source_id=f'a6-ui-sourcebacked-{uuid4()}'
fixture_key=f'a6-ui-permit-{uuid4()}'
with SessionLocal.begin() as session:
    source=Source(id=source_id,publisher='Synthetic UI Test',endpoint='https://example.test/ui',family='construction-permits',geography='Test City',industries=['construction'],retrieval_method='socrata-permits',health={})
    session.add(source); session.flush()
    project=Project(identity_key=fixture_key,name=f'Synthetic UI Facility {fixture_key[-8:]}',location='Test City',source_id=source_id,external_id=fixture_key,asset_type='construction')
    session.add(project); session.flush()
    need=PowerNeed(project_id=project.id,activity_key='construction',tier='Signal',rationale='Synthetic current support unavailable; persisted UI workflow fixture.',supply='Unknown',active=True)
    session.add(need); session.flush()
    content_hash=hashlib.sha256(fixture_key.encode()).hexdigest()
    title=f'Synthetic construction permit for {project.name}'
    abstract=f'Current permit filing for {project.name} in Test City. No verified power supply or qualified Lead claim.'
    url=f'https://example.test/synthetic-permit/{fixture_key}'
    observation=Observation(source_id=source_id,external_id=fixture_key,title=title,abstract=abstract,published_at=date(2026,10,8),url=url,content_hash=content_hash)
    session.add(observation); session.flush()
    evidence=Evidence(observation_id=observation.id,content_hash=content_hash,title=title,abstract=abstract,url=url,published_at=observation.published_at,observed_at=datetime.now(UTC),extraction_location='title and abstract')
    session.add(evidence); session.flush()
    assessment={'decision':'accepted','semantic_hash':content_hash,'evidence_hash':content_hash,'project_identity_key':project.identity_key,'power_activity':'construction','tier':'Signal','reason':'Synthetic current permit context; no verified power supply or Lead claim.','subject':project.name,'location':project.location,'evidence':{'id':str(evidence.id),'url':url}}
    session.add(Interpretation(observation_id=observation.id,content_hash=content_hash,status='accepted',assessment=assessment))
    session.add(NeedObservation(need_id=need.id,observation_id=observation.id))
    output={'need_id':str(need.id),'project_id':str(project.id),'name':project.name,'evidence_id':str(evidence.id),'content_hash':content_hash,'source_id':source_id}
out=Path(os.environ["A6_UI_FIXTURE_RECEIPT"])
out.write_text(json.dumps(output,sort_keys=True),encoding='utf-8')
print(json.dumps(output,sort_keys=True))



