import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-UI-STATUS-RECOVERY-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())
line_endings = []
for entry in manifest['entries']:
    path = entry['path']
    working = (root / path).read_bytes()
    committed = subprocess.check_output(['git', '-C', str(root), 'show', f"HEAD:{path}"])
    assert hashlib.sha256(working).hexdigest() == entry['working_sha256'], path
    assert hashlib.sha256(committed).hexdigest() == entry['git_content_sha256'], path
    if working != committed:
        assert working.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n'), path
        line_endings.append(path)
print(json.dumps({'tested_head': manifest['tested_head'], 'entries_verified': len(manifest['entries']), 'working_and_git_recorded_hashes_match': True, 'raw_working_git_line_ending_differences': line_endings, 'other_working_git_differences': []}))
