param([Parameter(Mandatory=$true)][string]$Candidate)
$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath $Candidate).Path
$taskArtifacts=Join-Path $taskRoot '.artifacts'
$taskReceipt=Join-Path $taskArtifacts 'root-a6-ui-recovery-persisted-fixture.json'
$taskSeedLog=Join-Path $taskArtifacts 'root-a6-ui-recovery-persisted-seed.log'
$taskBrowserLog=Join-Path $taskArtifacts 'root-a6-ui-recovery-persisted-browser.log'
$taskResults=Join-Path $taskArtifacts 'root-a6-ui-recovery-persisted-browser-results'
foreach($taskPath in @($taskReceipt,$taskSeedLog,$taskBrowserLog,$taskResults)){if(Test-Path -LiteralPath $taskPath){throw 'Refusing persisted proof overwrite'}}
foreach($taskProvider in @('FIRECRAWL_API_KEY','OPENAI_API_KEY','TYPESAFE_API_KEY')){[Environment]::SetEnvironmentVariable($taskProvider,'','Process')}
if(Test-Path -LiteralPath (Join-Path $taskRoot '.env')){throw 'No candidate .env permitted'}
$env:WORKER_AUTO_REFRESH='false';$env:AUTONOMOUS_RESEARCH_ENABLED='false'
$env:DATABASE_URL='postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_ui_root_persisted_test'
$env:TEST_DATABASE_URL=$env:DATABASE_URL
$env:SESSION_SECRET='gl3-a6-root-persisted-synthetic-session-secret-2026'
$env:A6_UI_PERSISTED_PASSWORD='GL3 A6 root disposable password 2026!'
$env:A6_UI_FIXTURE_DATABASE_NAME='gl3audit_a6_ui_root_persisted_test'
$env:A6_UI_FIXTURE_RECEIPT=$taskReceipt
$env:PATH='C:/Users/nrsan/AppData/Local/hermes/bin;'+$env:PATH
$env:PYTHONPATH=Join-Path $taskRoot 'backend/src'
$taskUv='C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe'
Set-Location (Join-Path $taskRoot 'backend')
$env:APP_PASSWORD_HASH=(& $taskUv run --locked --extra dev python -c "import bcrypt,os; print(bcrypt.hashpw(os.environ['A6_UI_PERSISTED_PASSWORD'].encode(),bcrypt.gensalt()).decode())")
if($LASTEXITCODE -ne 0 -or -not $env:APP_PASSWORD_HASH.StartsWith('$2b$')){throw 'Synthetic hash generation failed'}
& $taskUv run --locked --extra dev python (Join-Path $taskRoot '.agent/artifacts/GL3-AUDIT-A6-UI-STATUS-READY/seed_persisted_fixture.py') *> $taskSeedLog
if($LASTEXITCODE -ne 0){Get-Content -LiteralPath $taskSeedLog -Tail 12;exit $LASTEXITCODE}
$taskFixture=Get-Content -LiteralPath $taskReceipt -Raw | ConvertFrom-Json
$env:A6_UI_PERSISTED_NEED_ID=$taskFixture.need_id
$env:A6_UI_PERSISTED_PROJECT_ID=$taskFixture.project_id
$env:A6_UI_PERSISTED_NAME=$taskFixture.name
$env:GRIDLENS_API_PORT='55545';$env:GRIDLENS_WEB_PORT='55546'
$env:VITE_API_PROXY_TARGET='http://127.0.0.1:55545'
$env:TRUSTED_ORIGINS='http://127.0.0.1:55546'
$env:COOKIE_SECURE='false';$env:CI='1'
Set-Location (Join-Path $taskRoot 'web')
& npm.cmd exec playwright test -- tests/call-facts.spec.ts -g 'synthetic authenticated browser writes persist through the isolated local API' --project=regression --output=$taskResults *> $taskBrowserLog
$taskExit=$LASTEXITCODE
Get-Content -LiteralPath $taskBrowserLog -Tail 12
exit $taskExit
