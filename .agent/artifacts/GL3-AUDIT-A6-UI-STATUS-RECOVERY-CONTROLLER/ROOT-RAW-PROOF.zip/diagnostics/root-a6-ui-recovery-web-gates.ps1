$ErrorActionPreference='Stop'
$env:FIRECRAWL_API_KEY=''; $env:OPENAI_API_KEY=''; $env:TYPESAFE_API_KEY=''
$env:WORKER_AUTO_REFRESH='false'; $env:AUTONOMOUS_RESEARCH_ENABLED='false'
$taskRoot=Split-Path $PSScriptRoot -Parent
Set-Location (Join-Path $taskRoot 'web')
foreach($taskGate in @('typecheck','build','audit')) {
 $taskLog=Join-Path $PSScriptRoot "root-a6-ui-recovery-final-web-$taskGate.log"
 if(Test-Path -LiteralPath $taskLog){throw 'Refusing overwrite'}
 if($taskGate -eq 'audit'){ & npm.cmd audit --audit-level=low *> $taskLog } else { & npm.cmd run $taskGate *> $taskLog }
 $taskCode=$LASTEXITCODE
 Get-Content -LiteralPath $taskLog -Tail 8
 if($taskCode -ne 0){exit $taskCode}
}
