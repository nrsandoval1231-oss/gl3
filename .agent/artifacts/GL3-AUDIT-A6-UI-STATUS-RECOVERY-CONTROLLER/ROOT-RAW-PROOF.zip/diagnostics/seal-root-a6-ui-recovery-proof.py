import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
assert head == sys.argv[1]
output = root / '.agent/artifacts/GL3-AUDIT-A6-UI-STATUS-RECOVERY-CONTROLLER'
inputs = {}
for path in (root / '.artifacts').iterdir():
    if path.is_file() and (path.suffix in {'.log', '.py', '.ps1', '.json', '.txt'} or path.name.endswith('generated-check.ts')):
        inputs['diagnostics/' + path.name] = path
for name in ('root-a6-ui-recovery-controller-before', 'root-a6-ui-recovery-final-browser-results', 'root-a6-ui-recovery-persisted-browser-results'):
    directory = root / '.artifacts' / name
    assert directory.is_dir(), name
    extended = Path('\\\\?\\' + str(directory.absolute())) if os.name == 'nt' else directory
    for path in extended.rglob('*'):
        if path.is_file():
            inputs[name + '/' + path.relative_to(extended).as_posix()] = path
for directory in (root / '.agent/artifacts').iterdir():
    if directory.is_dir() and directory.name.startswith('GL3-AUDIT-A6-UI-STATUS-RECOVERY') and directory != output:
        for path in directory.rglob('*'):
            if path.is_file():
                inputs['evidence/' + directory.name + '/' + path.relative_to(directory).as_posix()] = path
prior = root / '.agent/artifacts/GL3-AUDIT-A6-UI-CONTROLLER'
for name in ('ROOT-RAW-PROOF-FINAL.zip', 'RAW-HASH-MANIFEST-FINAL.json', 'TESTED-SOURCE-MANIFEST.json', 'GATES.md', 'COMPLETION.json', 'EPISODE.md'):
    inputs['rejected-ui-ce3a03b/' + name] = prior / name
for name in ('TESTED-SOURCE-MANIFEST.json', 'GATES.md', 'COMPLETION.json', 'EPISODE.md'):
    inputs['controller/' + name] = output / name
for name in ('CURRENT_STATE.md', 'WORK_GRAPH.md'):
    inputs['controller/' + name] = root / '.agent' / name
archive_path = output / 'ROOT-RAW-PROOF.zip'
entries = []
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(inputs.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        entries.append({'entry': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive_path) as archive:
    for entry in entries:
        assert hashlib.sha256(archive.read(entry['entry'])).hexdigest() == entry['sha256']
receipt = {'tested_head': head, 'previous_rejected_ui_head': 'ce3a03bf8e7bef6f4a4edc212c8c77fd31e175ec', 'previous_ui_review_sha256': '9c2d1290807cc01b702140ce998a27718b5b5d6c549580f407dd1d07697b5415', 'archive': archive_path.name, 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'entries': entries, 'private_exclusions': ['No configuration, original private auth trace or original corpus dump/oracles included'], 'limitations': ['Local deterministic proof; fresh independent acceptance pending; authentic external gates remain OPEN']}
with (output / 'RAW-HASH-MANIFEST.json').open('x') as manifest:
    json.dump(receipt, manifest, indent=2)
print(json.dumps({'tested_head': head, 'entries': len(entries), 'archive_sha256': receipt['archive_sha256']}))
