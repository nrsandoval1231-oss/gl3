from pathlib import Path

folder = Path(__file__).resolve().parent
copies = {
    'root-a6-ui-separated-backend-gate.ps1': 'root-a6-ui-recovery-separated-backend-gate.ps1',
    'root-a6-final-browser-gate.ps1': 'root-a6-ui-recovery-browser-gate.ps1',
    'root-a6-ui-web-gates.ps1': 'root-a6-ui-recovery-web-gates.ps1',
    'root-a6-ui-safe.ps1': 'root-a6-ui-recovery-safe.ps1',
    'capture-a6-ui-source.py': 'capture-a6-ui-recovery-source.py',
    'root-a6-ui-verify-source.py': 'root-a6-ui-recovery-verify-source.py',
    'write-a6-ui-root-gates.py': 'write-a6-ui-recovery-root-gates.py',
    'root-a6-ui-persisted-gate.ps1': 'root-a6-ui-recovery-persisted-gate.ps1',
}
for old, new in copies.items():
    content = (folder / old).read_text()
    if 'separated-backend' in new or new.endswith('recovery-safe.ps1'):
        for name in ('test', 'migration', 'application', 'browser'):
            content = content.replace('gl3audit_a6_ui_final_' + name, 'gl3audit_a6_ui_recovery_' + name)
        content = content.replace('gl3audit_a6_ui_fresh_migration', 'gl3audit_a6_ui_recovery_fresh_migration')
    if new.endswith('recovery-web-gates.ps1'):
        content = content.replace('root-a6-ui-final-web-', 'root-a6-ui-recovery-final-web-')
    if new.endswith('recovery-source.py'):
        content = content.replace("packet_paths.append('.agent/packets/GL3-AUDIT-A6-UI-BUYING-CHAIN-FIXTURE-REPAIR.md')", "packet_paths.append('.agent/packets/GL3-AUDIT-A6-UI-BUYING-CHAIN-FIXTURE-REPAIR.md')\npacket_paths.append('.agent/packets/GL3-AUDIT-A6-UI-STATUS-RECOVERY.md')")
    if new in {'capture-a6-ui-recovery-source.py', 'root-a6-ui-recovery-verify-source.py', 'write-a6-ui-recovery-root-gates.py'}:
        content = content.replace('GL3-AUDIT-A6-UI-CONTROLLER', 'GL3-AUDIT-A6-UI-STATUS-RECOVERY-CONTROLLER')
    if new == 'write-a6-ui-recovery-root-gates.py':
        content = content.replace('root-a6-ui-r1-final-', 'root-a6-ui-recovery-final-')
        content = content.replace("'prior_independent_verdict': 'PASS_BOUNDED_BACKEND'", "'prior_independent_verdict': 'PASS_BOUNDED_BACKEND', 'previous_ui_verdict': 'FIX', 'previous_ui_head': 'ce3a03bf8e7bef6f4a4edc212c8c77fd31e175ec', 'previous_ui_review_sha256': '9c2d1290807cc01b702140ce998a27718b5b5d6c549580f407dd1d07697b5415'")
    if new == 'root-a6-ui-recovery-persisted-gate.ps1':
        content = content.replace('root-a6-ui-persisted-', 'root-a6-ui-recovery-persisted-')
        content = content.replace("'55541'", "'55545'").replace("'55542'", "'55546'")
        content = content.replace('http://127.0.0.1:55541', 'http://127.0.0.1:55545').replace('http://127.0.0.1:55542', 'http://127.0.0.1:55546')
    with (folder / new).open('x') as output:
        output.write(content)
print('Prepared eight independent recovery runners; prior runners unchanged')
