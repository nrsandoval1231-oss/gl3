# A5B active-tier FIX — October 8, 2026

Exact candidate 0415f19bfbe2ee54a56715f0fcb777d0226cae16 / tree fe64ea873fd55e353b2522069ef265f9cd305090 receives independent FIX. Receipt .artifacts/audit-20261007/a5b-back-independent-review.json SHA256 4174cb1491b9b284d4fef6069de9fdb7aab523f7fff521a37905e582660e39a6. Prior missing-token and Back-selection defects are corrected. Root mandatory gates, 1,419 backend and 44 browser, remain positive evidence for their tested paths, not acceptance.

Clicking the already-active tier on page one clears opportunityPage without changing a fetch dependency. Counts/CSV/pagination lose their authoritative metadata. Cancelling a matching pending request without replacement can leave loading stuck. The worktree remained clean; original application data is untouched.

Direction CORRECT: Sol prepares a bounded same-cohort request-state packet. One Luna checks existing invalidation handlers and implements reproducing ready/pending same-key tests, preserving fixed token and Back semantics. Root freezes and validates; independent Sol reviews. This is a distinct UI-state invariant, not permission for an unchanged retry or a broader redesign. Earlier negative receipts and exact source/proof bytes remain retained. A5B publication, A6 READY and parent completion remain withheld; no merge/deployment/paid activation/external communication.
