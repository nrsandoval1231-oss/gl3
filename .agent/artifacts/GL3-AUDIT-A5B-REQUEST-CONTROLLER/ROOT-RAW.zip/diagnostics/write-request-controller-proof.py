import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / '.agent/artifacts/GL3-AUDIT-A5B-REQUEST-CONTROLLER'
def receipt(prefix):
    paths = list((root / '.artifacts').glob(prefix + '-*-python.log'))
    assert len(paths) == 1, paths
    return json.loads(paths[0].read_text().strip().splitlines()[-1])
commercial = receipt('root-request-final-commercial')
public = receipt('root-request-final-public')
traversal = receipt('root-request-final-traversal')
completion = {
    'node': 'GL3-AUDIT-A5B same-cohort request-state repair',
    'state': 'DETERMINISTIC_PASS_REVIEW_PENDING',
    'tested_head': '3d67ac87cb82ff8221fd2047f13e4c016eb3a3d4',
    'tested_tree': 'bfb37c81755e104fb38414ff3cc5f83af9def866',
    'implementation': '7c29da3e6e52494f026ac78e66a55e1567f901b9',
    'backend': {'passed': 1419, 'skipped': 2, 'warnings': 5, 'seconds': 202.00},
    'browser': {'passed': 53, 'seconds': 39.6, 'ports_closed': [55521, 55522]},
    'static_contract_migration_dependency_gates': 'PASS',
    'retained_records': 1167, 'retained_opportunity_groups': 1149, 'retained_pages': 24,
    'commercial_measurements': commercial, 'public_measurements': public,
    'traversal_seconds': traversal['elapsed_seconds'],
    'original_column_scope_table_differences': 0, 'builder_raw_logs_verified': 13,
    'integration_repair_packets': 5, 'independent_acceptance': 'PENDING',
    'parent_objective': 'OPEN', 'model': 'UNKNOWN', 'config_identity': 'UNKNOWN',
    'tokens': 'UNKNOWN', 'elapsed_to_accepted': 'UNKNOWN',
    'authority': 'Draft publication after independent acceptance only; no merge, deployment, paid activation, external messages or original application-data mutation'
}
with (out / 'COMPLETION.json').open('x') as f:
    json.dump(completion, f, indent=2)
gates = '''# A5B request-state repair — root gates, independent acceptance pending

Tested HEAD 3d67ac87cb82ff8221fd2047f13e4c016eb3a3d4 / tree bfb37c81755e104fb38414ff3cc5f83af9def866; implementation 7c29da3e6e52494f026ac78e66a55e1567f901b9. The 257-file source/test/migration/workflow/dependency manifest binds tested bytes. This repair changes only App.tsx and project_cards.spec.ts product/test code. Backend policy, migrations, authentication, client API, styles and original data remain unchanged.

All three prior independent FIX receipts remain negative evidence: missing later-page token, Back selection, and same-cohort request cancellation/metadata loss. The new equality guards preserve valid metadata and matching in-flight requests for same-key controls. Intentional scope changes clear stale rows and trigger replacement requests. Record open/move preserves the current request epoch while cancelling obsolete restoration intent. Active tier on later pages still returns to page one. Focused 23-test suite covers ready/pending controls and retains earlier token/Back/stale-response tests. Thirteen builder logs hash-match; all available failed attempts and native traces are preserved. No self-acceptance is claimed.

Root final: 1,419 backend passed, two environmental skips, five warnings, 202.00 seconds; all 53 browser passed, 39.6 seconds. Ruff including backend scripts, mypy src (78 files), web typecheck/build, exact 31-path OpenAPI, npm audit and locked pip-audit 2.10.1 passed. Three separately catalog-proven-empty disposable databases retained; fresh migration to 0016, repeat and drift passed. Ports 55521/55522 closed. Skips: absent optional NC local access probe and unavailable Windows symlink privilege. Existing deprecations and unchanged exploratory test-tree typing failure remain documented; no whole-test-tree typing PASS. CSS Bgkt5XFA unchanged; no A7 visual acceptance claim.

Read-only retained stream matches 1,167 records / 1,149 opportunity groups, exact titles/membership/decisions and 17 searches. All 24 bounded pages match exact order/count/group metadata/token navigation without duplicates: 2,215 total diagnostic SQL, 32.397686499985866 seconds. Commercial grouping remains separately 1,144 groups. Exact fresh commercial/public measurement receipts are in COMPLETION.json and original logs; each commercial run used 102 SQL, each public run 92 SQL, below the 200 gate. Commercial 202,084 handler bytes retain SHA256 4d44821139abdd92a657aa7f419f86754abb33be0e1e0d5082278dee0bed4812. Workloads differ; Python allocation is not RSS, first process does not evict database/disk caches, handler bytes are not compressed HTTP, and no production SLO/speedup is claimed. Later tokenless links use a bounded bootstrap; off-page selection may request one exact scoped need. These extra navigation requests are outside single-handler measurements.

Original-column fingerprints match all 24 tables against accepted after-0016 baseline. Preserved dump SHA256 remains 828beace65cd2b06182f30e4713857656a993d3969c8cbecb02e6ee40ff8a886. A first fingerprint command used a Python runtime without psycopg and failed before database access; its log is retained and the locked project-runtime retry passed. A post-OpenAPI listing used the wrapper's changed working directory and failed; the OpenAPI check itself passed. Available exact raw bytes are sealed in ROOT-RAW.zip; prior overwritten native traces and unretained bootstrap/path/tool-fragment bytes remain UNKNOWN. Known-secret scans recursively inspect proof/native ZIPs and exclude tool history; no tool-history removal claim.

Five distinct integration repair packets are retained. Root source capture/migration began by 2026-10-08T18:15:40Z; fresh raw timestamps and command durations govern validation timing. Model/config/tokens and elapsed-to-accepted remain UNKNOWN unless separately evidenced. Fresh exact-candidate independent review is PENDING. A6 attributed facts/seven-state workflow/functional UI/bulk status integration, A7 original PNG/HTML, A8 operations/recovery/readiness and real feed/quality/seven-day/customer Lead gates remain OPEN. Status UNKNOWN-only is partial, not a waiver. No parent completion, merge, deployment, paid activation or external communication.
'''
with (out / 'GATES.md').open('x', encoding='utf-8') as f:
    f.write(gates)
for name in ('CURRENT_STATE.md', 'WORK_GRAPH.md'):
    old = (root / '.artifacts/a5b-request-controller-before' / (name + '.bin')).read_bytes().decode('utf-8')
    prefix = '# Current request-state repair frontier — October 8, 2026\n\nA5A accepted / draft PR40 / recorded CI PASS. Three prior A5B independent FIX receipts are preserved. Request-state implementation 7c29da3 / tested 3d67ac8 passes root 1,419 backend tests (two environmental skips), 53 browser tests, mandatory gates, retained parity and query bounds. Exact proof is .agent/artifacts/GL3-AUDIT-A5B-REQUEST-CONTROLLER. Fresh independent review is PENDING; A5B is not accepted or published. This supersedes earlier pending states below.\n\nDirection: VALIDATE the exact proof descendant. A6 facts/seven-state workflow → functional UI and bulk status integration → A8 remain dependent on A5B acceptance. A7 original PNG/HTML and real launch gates remain OPEN. UNKNOWN-only status is partial, not a waiver. Parent objective OPEN. No original data mutation, merge, deployment, paid activation or external messages.\n\n## Historical checkpoints\n\n'
    (root / '.agent' / name).write_text(prefix + old, encoding='utf-8')
print(json.dumps({'proof_docs_written': True, 'independent_review': 'PENDING'}))
