# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> active first-page tier click while loading lets the matching request settle
- Location: tests\project_cards.spec.ts:527:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('status', { name: 'Updating this view…' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('status', { name: 'Updating this view…' }) with timeout 5000ms
  - waiting for getByRole('status', { name: 'Updating this view…' })

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Signals" [level=1]
  - paragraph: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Signals · 0 filtered project cards · 0 filtered opportunity records" [level=2]
  - paragraph: All · 0 cards and 0 records on this page of 0 filtered cards and 0 records. SHOW means worth investigating, not qualified.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - group "Filter Signals by review decision":
    - button "All 0" [pressed]
    - button "SHOW 0"
    - button "REVIEW 0"
    - button "HOLD 0"
  - status: Updating this view…
  - text: 0 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  452 |     }
  453 |     const body = url.pathname === '/api/auth/session'
  454 |       ? { authenticated: true }
  455 |       : url.pathname === '/api/health'
  456 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  457 |         : url.pathname.startsWith('/api/power-needs/')
  458 |           ? { status: 'unavailable', result: null, citations: [] }
  459 |           : []
  460 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  461 |   })
  462 | 
  463 |   try {
  464 |     await page.goto('/?tier=Signals&offset=25')
  465 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
  466 |     await page.getByRole('button', { name: 'Prospects' }).click()
  467 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  468 | 
  469 |     restoreSignalPage = true
  470 |     await page.goBack()
  471 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  472 |     await page.goForward()
  473 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  474 |     releaseDelayedResponse?.()
  475 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  476 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  477 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  478 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  479 |   } finally {
  480 |     releaseDelayedResponse?.()
  481 |   }
  482 | })
  483 | 
  484 | test('active first-page tier click preserves ready metadata and closes its detail without refetching', async ({ page }) => {
  485 |   const record = permit('active-tier-ready', 'Campus facility activity')
  486 |   const requests: URL[] = []
  487 |   await page.route(apiRoute, async (route) => {
  488 |     const url = new URL(route.request().url())
  489 |     if (url.pathname === '/api/opportunities') {
  490 |       requests.push(url)
  491 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  492 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  493 |       return
  494 |     }
  495 |     const body = url.pathname === '/api/auth/session'
  496 |       ? { authenticated: true }
  497 |       : url.pathname === '/api/health'
  498 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  499 |         : url.pathname.startsWith('/api/power-needs/')
  500 |           ? { status: 'unavailable', result: null, citations: [] }
  501 |           : []
  502 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  503 |   })
  504 | 
  505 |   await page.goto('/?tier=Signals')
  506 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  507 |   const initialUrl = page.url()
  508 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  509 |   await expect(csv).toBeVisible()
  510 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  511 |   await page.getByRole('button', { name: 'Signals' }).click()
  512 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
  513 |   await expect(csv).toBeVisible()
  514 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  515 |   expect(page.url()).toBe(initialUrl)
  516 |   expect(requests).toHaveLength(1)
  517 | 
  518 |   await page.locator('[data-opportunity-id="active-tier-ready"]').click()
  519 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  520 |   await page.getByRole('button', { name: 'Signals' }).click()
  521 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  522 |   await expect(csv).toBeVisible()
  523 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  524 |   expect(requests).toHaveLength(1)
  525 | })
  526 | 
  527 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  528 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  529 |   let requestStarted = false
  530 |   let releaseRequest: (() => void) | undefined
  531 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  532 |   await page.route(apiRoute, async (route) => {
  533 |     const url = new URL(route.request().url())
  534 |     if (url.pathname === '/api/opportunities') {
  535 |       requestStarted = true
  536 |       await gate
  537 |       const payload = serverOpportunityPage([record])
  538 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  539 |       return
  540 |     }
  541 |     const body = url.pathname === '/api/auth/session'
  542 |       ? { authenticated: true }
  543 |       : url.pathname === '/api/health'
  544 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  545 |         : []
  546 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  547 |   })
  548 |   try {
  549 |     await page.goto('/?tier=Signals')
  550 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  551 |     await expect.poll(() => requestStarted).toBe(true)
> 552 |     await expect(page.getByRole('status', { name: 'Updating this view…' })).toBeVisible()
      |                                                                             ^ Error: expect(locator).toBeVisible() failed
  553 |     await page.getByRole('button', { name: 'Signals' }).click()
  554 |     releaseRequest?.()
  555 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  556 |     await expect(page.getByRole('status', { name: 'Updating this view…' })).toHaveCount(0)
  557 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  558 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  559 |   } finally {
  560 |     releaseRequest?.()
  561 |   }
  562 | })
  563 | 
  564 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  565 |   const record = permit('same-decision-search', 'Campus facility activity')
  566 |   const requests: URL[] = []
  567 |   await page.route(apiRoute, async (route) => {
  568 |     const url = new URL(route.request().url())
  569 |     if (url.pathname === '/api/opportunities') {
  570 |       requests.push(url)
  571 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  572 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  573 |       return
  574 |     }
  575 |     const body = url.pathname === '/api/auth/session'
  576 |       ? { authenticated: true }
  577 |       : url.pathname === '/api/health'
  578 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  579 |         : []
  580 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  581 |   })
  582 |   await page.goto('/?tier=Signals&q=campus')
  583 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
  584 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  585 |   await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  586 |   await expect(csv).toBeVisible()
  587 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  588 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  589 |   await expect(csv).toBeVisible()
  590 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  591 |   expect(requests).toHaveLength(1)
  592 | })
  593 | 
  594 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  595 |   const record = permit('open-during-refresh', 'Campus facility activity')
  596 |   let opportunityRequests = 0
  597 |   let secondRequestStarted = false
  598 |   let releaseSecondRequest: (() => void) | undefined
  599 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  600 |   await page.route(apiRoute, async (route) => {
  601 |     const url = new URL(route.request().url())
  602 |     if (url.pathname === '/api/opportunities') {
  603 |       opportunityRequests += 1
  604 |       if (opportunityRequests === 2) {
  605 |         secondRequestStarted = true
  606 |         await secondRequestGate
  607 |       }
  608 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  609 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  610 |       return
  611 |     }
  612 |     const body = url.pathname === '/api/auth/session'
  613 |       ? { authenticated: true }
  614 |       : url.pathname === '/api/health'
  615 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  616 |         : url.pathname.startsWith('/api/power-needs/')
  617 |           ? { status: 'unavailable', result: null, citations: [] }
  618 |           : []
  619 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  620 |   })
  621 |   try {
  622 |     await page.goto('/?tier=Signals')
  623 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  624 |     await page.getByRole('button', { name: '← Back to Signals' }).click()
  625 |     await expect.poll(() => secondRequestStarted).toBe(true)
  626 |     await expect(page.locator('[data-opportunity-id="open-during-refresh"]')).toBeVisible()
  627 |     await page.locator('[data-opportunity-id="open-during-refresh"]').click()
  628 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  629 |     releaseSecondRequest?.()
  630 |     await expect(page.getByRole('status', { name: 'Updating this view…' })).toHaveCount(0)
  631 |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  632 |   } finally {
  633 |     releaseSecondRequest?.()
  634 |   }
  635 | })
  636 | 
  637 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  638 |   const record = permit('roles', 'Facility construction', {
  639 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  640 |   })
  641 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  642 |   record.evidence[0].assessment_current = false
  643 |   expect(projectTitle(record)).not.toContain('Owner Company')
  644 | })
  645 | 
  646 | test('city permit company title shows source role and does not infer ownership', () => {
  647 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  648 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  649 |   })
  650 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  651 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  652 | 
```