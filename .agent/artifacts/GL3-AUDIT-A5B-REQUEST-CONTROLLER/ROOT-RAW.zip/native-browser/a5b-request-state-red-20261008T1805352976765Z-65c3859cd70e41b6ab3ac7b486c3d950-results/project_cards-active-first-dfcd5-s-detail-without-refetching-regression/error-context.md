# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> active first-page tier click preserves ready metadata and closes its detail without refetching
- Location: tests\project_cards.spec.ts:484:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('1 filtered records · page 1')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('1 filtered records · page 1') with timeout 5000ms
  - waiting for getByText('1 filtered records · page 1')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Signals" [level=1]
  - paragraph: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Signals · 1 filtered project cards · 1 filtered opportunity records" [level=2]
  - paragraph: All · 1 cards and 1 records on this page of 0 filtered cards and 0 records. SHOW means worth investigating, not qualified.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - group "Filter Signals by review decision":
    - button "All 0" [pressed]
    - button "SHOW 0"
    - button "REVIEW 0"
    - button "HOLD 0"
  - 'button "Campus Facility Activity 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal"':
    - strong: Campus Facility Activity
    - text: 2100 BARTON SPRINGS RD, AUSTIN, TX
    - strong: "Decision: SHOW"
    - text: Signal
  - text: 0 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  412 |   expect(detailRequests).toHaveLength(1)
  413 |   expect(detailRequests[0].searchParams.get('tier')).toBe('Signal')
  414 |   expect(detailRequests[0].searchParams.get('activity')).toBe('event-power')
  415 |   expect(detailRequests[0].searchParams.get('cohort_token')).toBe('restored-scope-token')
  416 | })
  417 | 
  418 | test('late restored-page response cannot replace a newer Back/Forward destination', async ({ page }) => {
  419 |   const firstSignal = permit('late-first-signal', 'First Signal page')
  420 |   const selectedSignal = permit('late-selected-signal', 'Delayed Signal detail record')
  421 |   const prospect = permit('late-prospect', 'Current Prospect destination', { tier: 'Prospect' })
  422 |   const requests: URL[] = []
  423 |   let restoreSignalPage = false
  424 |   let delayedResponseStarted = false
  425 |   let releaseDelayedResponse: (() => void) | undefined
  426 |   const delayedResponseGate = new Promise<void>((resolve) => { releaseDelayedResponse = resolve })
  427 |   await page.route(apiRoute, async (route) => {
  428 |     const url = new URL(route.request().url())
  429 |     if (url.pathname === '/api/opportunities') {
  430 |       requests.push(url)
  431 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  432 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  433 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  434 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  435 |       if (restoreSignalPage && tier === 'Signal' && offset === 25 && !delayedResponseStarted) {
  436 |         delayedResponseStarted = true
  437 |         await delayedResponseGate
  438 |       }
  439 |       await route.fulfill({
  440 |         status: 200,
  441 |         contentType: 'application/json',
  442 |         headers: {
  443 |           ...payload.headers,
  444 |           'X-Limit': '25',
  445 |           'X-Offset': String(offset),
  446 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-race-token' : 'signal-race-token',
  447 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  448 |         },
  449 |         body: JSON.stringify(payload.items),
  450 |       })
  451 |       return
  452 |     }
  453 |     const body = url.pathname === '/api/auth/session'
  454 |       ? { authenticated: true }
  455 |       : url.pathname === '/api/health'
  456 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  457 |         : url.pathname.startsWith('/api/power-needs/')
  458 |           ? { status: 'unavailable', result: null, citations: [] }
  459 |           : []
  460 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  461 |   })
  462 | 
  463 |   try {
  464 |     await page.goto('/?tier=Signals&offset=25')
  465 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
  466 |     await page.getByRole('button', { name: 'Prospects' }).click()
  467 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  468 | 
  469 |     restoreSignalPage = true
  470 |     await page.goBack()
  471 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  472 |     await page.goForward()
  473 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  474 |     releaseDelayedResponse?.()
  475 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  476 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  477 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  478 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  479 |   } finally {
  480 |     releaseDelayedResponse?.()
  481 |   }
  482 | })
  483 | 
  484 | test('active first-page tier click preserves ready metadata and closes its detail without refetching', async ({ page }) => {
  485 |   const record = permit('active-tier-ready', 'Campus facility activity')
  486 |   const requests: URL[] = []
  487 |   await page.route(apiRoute, async (route) => {
  488 |     const url = new URL(route.request().url())
  489 |     if (url.pathname === '/api/opportunities') {
  490 |       requests.push(url)
  491 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  492 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  493 |       return
  494 |     }
  495 |     const body = url.pathname === '/api/auth/session'
  496 |       ? { authenticated: true }
  497 |       : url.pathname === '/api/health'
  498 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  499 |         : url.pathname.startsWith('/api/power-needs/')
  500 |           ? { status: 'unavailable', result: null, citations: [] }
  501 |           : []
  502 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  503 |   })
  504 | 
  505 |   await page.goto('/?tier=Signals')
  506 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  507 |   const initialUrl = page.url()
  508 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  509 |   await expect(csv).toBeVisible()
  510 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  511 |   await page.getByRole('button', { name: 'Signals' }).click()
> 512 |   await expect(page.getByText('1 filtered records · page 1')).toBeVisible()
      |                                                               ^ Error: expect(locator).toBeVisible() failed
  513 |   await expect(csv).toBeVisible()
  514 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  515 |   expect(page.url()).toBe(initialUrl)
  516 |   expect(requests).toHaveLength(1)
  517 | 
  518 |   await page.locator('[data-opportunity-id="active-tier-ready"]').click()
  519 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  520 |   await page.getByRole('button', { name: 'Signals' }).click()
  521 |   await expect(page.locator('[data-opportunity-id="active-tier-ready"]')).toBeVisible()
  522 |   await expect(csv).toBeVisible()
  523 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  524 |   expect(requests).toHaveLength(1)
  525 | })
  526 | 
  527 | test('active first-page tier click while loading lets the matching request settle', async ({ page }) => {
  528 |   const record = permit('active-tier-pending', 'Pending campus facility activity')
  529 |   let requestStarted = false
  530 |   let releaseRequest: (() => void) | undefined
  531 |   const gate = new Promise<void>((resolve) => { releaseRequest = resolve })
  532 |   await page.route(apiRoute, async (route) => {
  533 |     const url = new URL(route.request().url())
  534 |     if (url.pathname === '/api/opportunities') {
  535 |       requestStarted = true
  536 |       await gate
  537 |       const payload = serverOpportunityPage([record])
  538 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  539 |       return
  540 |     }
  541 |     const body = url.pathname === '/api/auth/session'
  542 |       ? { authenticated: true }
  543 |       : url.pathname === '/api/health'
  544 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  545 |         : []
  546 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  547 |   })
  548 |   try {
  549 |     await page.goto('/?tier=Signals')
  550 |     await expect(page.getByRole('button', { name: 'Signals' })).toBeVisible()
  551 |     await expect.poll(() => requestStarted).toBe(true)
  552 |     await expect(page.getByRole('status', { name: 'Updating this view…' })).toBeVisible()
  553 |     await page.getByRole('button', { name: 'Signals' }).click()
  554 |     releaseRequest?.()
  555 |     await expect(page.locator('[data-opportunity-id="active-tier-pending"]')).toBeVisible()
  556 |     await expect(page.getByRole('status', { name: 'Updating this view…' })).toHaveCount(0)
  557 |     await expect(page.getByRole('link', { name: 'Download filtered CSV' })).toBeVisible()
  558 |     await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  559 |   } finally {
  560 |     releaseRequest?.()
  561 |   }
  562 | })
  563 | 
  564 | test('active Signals decision and unchanged search preserve ready page metadata', async ({ page }) => {
  565 |   const record = permit('same-decision-search', 'Campus facility activity')
  566 |   const requests: URL[] = []
  567 |   await page.route(apiRoute, async (route) => {
  568 |     const url = new URL(route.request().url())
  569 |     if (url.pathname === '/api/opportunities') {
  570 |       requests.push(url)
  571 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  572 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0', 'X-Next-Offset': '25' }, body: JSON.stringify(payload.items) })
  573 |       return
  574 |     }
  575 |     const body = url.pathname === '/api/auth/session'
  576 |       ? { authenticated: true }
  577 |       : url.pathname === '/api/health'
  578 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  579 |         : []
  580 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  581 |   })
  582 |   await page.goto('/?tier=Signals&q=campus')
  583 |   await expect(page.locator('[data-opportunity-id="same-decision-search"]')).toBeVisible()
  584 |   const csv = page.getByRole('link', { name: 'Download filtered CSV' })
  585 |   await page.getByRole('group', { name: 'Filter Signals by review decision' }).getByRole('button', { name: /All/ }).click()
  586 |   await expect(csv).toBeVisible()
  587 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  588 |   await page.getByRole('textbox', { name: 'Search projects' }).fill('campus')
  589 |   await expect(csv).toBeVisible()
  590 |   await expect(page.locator('.collection-pagination button').nth(1)).toBeEnabled()
  591 |   expect(requests).toHaveLength(1)
  592 | })
  593 | 
  594 | test('opening a same-cohort record during a pending Back page request does not strand loading', async ({ page }) => {
  595 |   const record = permit('open-during-refresh', 'Campus facility activity')
  596 |   let opportunityRequests = 0
  597 |   let secondRequestStarted = false
  598 |   let releaseSecondRequest: (() => void) | undefined
  599 |   const secondRequestGate = new Promise<void>((resolve) => { releaseSecondRequest = resolve })
  600 |   await page.route(apiRoute, async (route) => {
  601 |     const url = new URL(route.request().url())
  602 |     if (url.pathname === '/api/opportunities') {
  603 |       opportunityRequests += 1
  604 |       if (opportunityRequests === 2) {
  605 |         secondRequestStarted = true
  606 |         await secondRequestGate
  607 |       }
  608 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  609 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: { ...payload.headers, 'X-Limit': '25', 'X-Offset': '0' }, body: JSON.stringify(payload.items) })
  610 |       return
  611 |     }
  612 |     const body = url.pathname === '/api/auth/session'
```