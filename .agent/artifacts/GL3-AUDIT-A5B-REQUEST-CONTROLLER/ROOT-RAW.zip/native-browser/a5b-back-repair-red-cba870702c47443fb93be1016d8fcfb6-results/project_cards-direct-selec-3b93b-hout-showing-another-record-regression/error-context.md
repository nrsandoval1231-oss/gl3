# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> direct selected URL reports an exact need outside its filtered cohort without showing another record
- Location: tests\project_cards.spec.ts:338:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "selected opportunity is not available in this filtered cohort"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Signals" [level=1]
  - paragraph: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Signals · 1 filtered project cards · 1 filtered opportunity records" [level=2]
  - paragraph: All · 1 cards and 1 records on this page of 1 filtered cards and 1 records. SHOW means worth investigating, not qualified.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
    - text: visible
  - link "Download filtered CSV":
    - /url: /api/opportunities/export.csv?tier=Signal&search=visible&decision=ALL&cohort_token=fixture-server-cohort&activity=event-power
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
    - text: event-power
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - group "Filter Signals by review decision":
    - button "All 1" [pressed]
    - button "SHOW 1"
    - button "REVIEW 0"
    - button "HOLD 0"
  - 'button "Visible Record In The Selected Filter 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal"':
    - strong: Visible Record In The Selected Filter
    - text: 2100 BARTON SPRINGS RD, AUSTIN, TX
    - strong: "Decision: SHOW"
    - text: Signal
  - text: 1 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →" [disabled]
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  262 |   const opportunityRequests = requests
  263 |   const laterRequest = opportunityRequests.find((request) => request.searchParams.get('offset') === '25')
  264 |   expect(laterRequest?.searchParams.get('cohort_token')).toBe('old-cohort-token')
  265 |   const restarted = opportunityRequests.find((request, index) => index > opportunityRequests.indexOf(laterRequest!) && (request.searchParams.get('offset') ?? '0') === '0')
  266 |   expect(restarted?.searchParams.get('cohort_token')).toBeNull()
  267 | })
  268 | 
  269 | test('Back restores the exact selected need across tiers and pages with its cohort and focus', async ({ page }) => {
  270 |   const firstSignal = permit('signal-first-page', 'First Signal page record')
  271 |   const selectedSignal = permit('signal-later-page', 'Exact Signal later-page record')
  272 |   selectedSignal.evidence[0].title = 'Citation for the exact later-page Signal'
  273 |   const prospect = permit('prospect-first-page', 'Distinct Prospect page record', { tier: 'Prospect' })
  274 |   const requests: URL[] = []
  275 |   await page.route(apiRoute, async (route) => {
  276 |     const url = new URL(route.request().url())
  277 |     const path = url.pathname
  278 |     if (path === '/api/opportunities') {
  279 |       requests.push(url)
  280 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  281 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  282 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  283 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  284 |       await route.fulfill({
  285 |         status: 200,
  286 |         contentType: 'application/json',
  287 |         headers: {
  288 |           ...payload.headers,
  289 |           'X-Limit': '25',
  290 |           'X-Offset': String(offset),
  291 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-scope-token' : 'signal-scope-token',
  292 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  293 |         },
  294 |         body: JSON.stringify(payload.items),
  295 |       })
  296 |       return
  297 |     }
  298 |     const body = path === '/api/auth/session'
  299 |       ? { authenticated: true }
  300 |       : path === '/api/health'
  301 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  302 |         : path.startsWith('/api/power-needs/')
  303 |           ? { status: 'unavailable', result: null, citations: [] }
  304 |           : []
  305 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  306 |   })
  307 | 
  308 |   await page.goto('/?tier=Signals&decision=SHOW&offset=25&activity=event-power')
  309 |   const selectedCard = page.locator('[data-opportunity-id="signal-later-page"]')
  310 |   await expect(selectedCard).toBeVisible()
  311 |   await selectedCard.click()
  312 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
  313 |   expect(new URL(page.url()).hash).toBe('#signal-later-page')
  314 |   await page.getByRole('button', { name: 'Prospects' }).click()
  315 |   await expect(page.locator('[data-opportunity-id="prospect-first-page"]')).toBeVisible()
  316 | 
  317 |   await page.goBack()
  318 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
  319 |   expect(new URL(page.url()).searchParams.get('tier')).toBe('Signals')
  320 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  321 |   expect(new URL(page.url()).searchParams.get('decision')).toBe('SHOW')
  322 |   expect(new URL(page.url()).searchParams.get('activity')).toBe('event-power')
  323 |   expect(new URL(page.url()).hash).toBe('#signal-later-page')
  324 |   const restoreRequests = requests.filter((request) => request.searchParams.get('tier') === 'Signal').slice(-2)
  325 |   expect(restoreRequests.map((request) => request.searchParams.get('offset'))).toEqual(['0', '25'])
  326 |   expect(restoreRequests[0].searchParams.get('cohort_token')).toBeNull()
  327 |   expect(restoreRequests[1].searchParams.get('cohort_token')).toBe('signal-scope-token')
  328 | 
  329 |   await page.goBack()
  330 |   await expect(page.locator('[data-opportunity-id="signal-later-page"]')).toBeFocused()
  331 |   await page.goForward()
  332 |   await expect(page.getByRole('link', { name: 'Citation for the exact later-page Signal' })).toBeVisible()
  333 |   await page.goForward()
  334 |   await expect(page.locator('[data-opportunity-id="prospect-first-page"]')).toBeVisible()
  335 |   expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  336 | })
  337 | 
  338 | test('direct selected URL reports an exact need outside its filtered cohort without showing another record', async ({ page }) => {
  339 |   const visibleRecord = permit('visible-filtered-record', 'Visible record in the selected filter')
  340 |   const detailRequests: URL[] = []
  341 |   await page.route(apiRoute, async (route) => {
  342 |     const url = new URL(route.request().url())
  343 |     if (url.pathname === '/api/opportunities') {
  344 |       const payload = serverOpportunityPage([visibleRecord], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  345 |       await route.fulfill({ status: 200, contentType: 'application/json', headers: payload.headers, body: JSON.stringify(payload.items) })
  346 |       return
  347 |     }
  348 |     if (url.pathname === '/api/opportunities/needs/not-in-filtered-cohort') {
  349 |       detailRequests.push(url)
  350 |       await route.fulfill({ status: 404, json: { detail: 'Opportunity is outside the requested filtered cohort' } })
  351 |       return
  352 |     }
  353 |     const body = url.pathname === '/api/auth/session'
  354 |       ? { authenticated: true }
  355 |       : url.pathname === '/api/health'
  356 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  357 |         : []
  358 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  359 |   })
  360 | 
  361 |   await page.goto('/?tier=Signals&q=visible&activity=event-power#not-in-filtered-cohort')
> 362 |   await expect(page.getByRole('alert')).toContainText('selected opportunity is not available in this filtered cohort')
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  363 |   await expect(page.getByRole('heading', { level: 1, name: 'Signals' })).toBeVisible()
  364 |   await expect(page.locator('[data-opportunity-id="visible-filtered-record"]')).toBeVisible()
  365 |   await expect(page.getByRole('link', { name: /not-in-filtered-cohort/ })).toHaveCount(0)
  366 |   expect(new URL(page.url()).hash).toBe('')
  367 |   expect(detailRequests).toHaveLength(1)
  368 |   expect(detailRequests[0].searchParams.get('tier')).toBe('Signal')
  369 |   expect(detailRequests[0].searchParams.get('search')).toBe('visible')
  370 |   expect(detailRequests[0].searchParams.get('activity')).toBe('event-power')
  371 |   expect(detailRequests[0].searchParams.get('cohort_token')).toBe('fixture-server-cohort')
  372 | })
  373 | 
  374 | test('late restored-page response cannot replace a newer Back/Forward destination', async ({ page }) => {
  375 |   const firstSignal = permit('late-first-signal', 'First Signal page')
  376 |   const selectedSignal = permit('late-selected-signal', 'Delayed Signal detail record')
  377 |   const prospect = permit('late-prospect', 'Current Prospect destination', { tier: 'Prospect' })
  378 |   const requests: URL[] = []
  379 |   let restoreSignalPage = false
  380 |   let delayedResponseStarted = false
  381 |   let releaseDelayedResponse: (() => void) | undefined
  382 |   const delayedResponseGate = new Promise<void>((resolve) => { releaseDelayedResponse = resolve })
  383 |   await page.route(apiRoute, async (route) => {
  384 |     const url = new URL(route.request().url())
  385 |     if (url.pathname === '/api/opportunities') {
  386 |       requests.push(url)
  387 |       const tier = url.searchParams.get('tier') ?? 'Signal'
  388 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  389 |       const record = tier === 'Prospect' ? prospect : offset === 0 ? firstSignal : selectedSignal
  390 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL', url.searchParams.get('search') ?? '')
  391 |       if (restoreSignalPage && tier === 'Signal' && offset === 25 && !delayedResponseStarted) {
  392 |         delayedResponseStarted = true
  393 |         await delayedResponseGate
  394 |       }
  395 |       await route.fulfill({
  396 |         status: 200,
  397 |         contentType: 'application/json',
  398 |         headers: {
  399 |           ...payload.headers,
  400 |           'X-Limit': '25',
  401 |           'X-Offset': String(offset),
  402 |           'X-Cohort-Token': tier === 'Prospect' ? 'prospect-race-token' : 'signal-race-token',
  403 |           ...(tier === 'Signal' && offset === 0 ? { 'X-Next-Offset': '25' } : {}),
  404 |         },
  405 |         body: JSON.stringify(payload.items),
  406 |       })
  407 |       return
  408 |     }
  409 |     const body = url.pathname === '/api/auth/session'
  410 |       ? { authenticated: true }
  411 |       : url.pathname === '/api/health'
  412 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  413 |         : url.pathname.startsWith('/api/power-needs/')
  414 |           ? { status: 'unavailable', result: null, citations: [] }
  415 |           : []
  416 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  417 |   })
  418 | 
  419 |   try {
  420 |     await page.goto('/?tier=Signals&offset=25')
  421 |     await page.locator('[data-opportunity-id="late-selected-signal"]').click()
  422 |     await page.getByRole('button', { name: 'Prospects' }).click()
  423 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  424 | 
  425 |     restoreSignalPage = true
  426 |     await page.goBack()
  427 |     await expect.poll(() => delayedResponseStarted).toBe(true)
  428 |     await page.goForward()
  429 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  430 |     releaseDelayedResponse?.()
  431 |     await expect(page.locator('[data-opportunity-id="late-prospect"]')).toBeVisible()
  432 |     await expect(page.getByRole('link', { name: /Delayed Signal detail record/ })).toHaveCount(0)
  433 |     expect(new URL(page.url()).searchParams.get('tier')).toBe('Prospects')
  434 |     expect(requests.some((request) => request.searchParams.get('tier') === 'Signal' && request.searchParams.get('offset') === '25')).toBe(true)
  435 |   } finally {
  436 |     releaseDelayedResponse?.()
  437 |   }
  438 | })
  439 | 
  440 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  441 |   const record = permit('roles', 'Facility construction', {
  442 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  443 |   })
  444 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  445 |   record.evidence[0].assessment_current = false
  446 |   expect(projectTitle(record)).not.toContain('Owner Company')
  447 | })
  448 | 
  449 | test('city permit company title shows source role and does not infer ownership', () => {
  450 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  451 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  452 |   })
  453 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  454 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  455 | 
  456 |   const houston = permit('houston-1', 'Commercial facility construction')
  457 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  458 |   houston.title_company_role = 'permit-listed owner / occupant'
  459 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  460 | })
  461 | 
  462 | test('city permit organization labels preserve the source role and role uncertainty', () => {
```