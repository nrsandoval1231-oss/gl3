from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'a6-ui-status-populated-proof.py').read_text()
begin = source.index('with psycopg.connect(plain_url)')
end = source.index('app = importlib.import_module', begin)
replacement = '''with psycopg.connect(plain_url) as connection:
    connection.execute("SET TRANSACTION READ ONLY")
    needs = connection.execute("SELECT id, project_id FROM power_needs WHERE active IS TRUE ORDER BY id").fetchall()
    inserted = connection.execute("SELECT count(*) FROM need_workflow_status_events").fetchone()[0]
    unknown = connection.execute("SELECT count(*) FROM power_needs p WHERE active IS TRUE AND NOT EXISTS (SELECT 1 FROM need_workflow_status_events e WHERE e.need_id=p.id)").fetchone()[0]
    assert len(needs) == 1168 and inserted == 1022 and unknown == 146
    connection.rollback()

'''
source = source[:begin] + replacement + source[end:]
source = source.replace('synthetic_status_events_inserted', 'synthetic_status_events_present')
source = source.replace('"original_corpus_tables_written": [],', '"original_corpus_tables_written": [], "root_database_writes": 0,')
source = source.replace('Append-only synthetic status load and bounded read-only A6 UI scale check.', 'Independent read-only check of existing synthetic status load; zero writes.')
with (root / 'root-a6-ui-status-readonly-proof.py').open('x') as output:
    output.write(source)
print('Prepared independent read-only status scale runner; original seeder unchanged')
