import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
receipts = []
for folder in ('GL3-AUDIT-A6-UI-STATUS-READY', 'GL3-AUDIT-A6-UI-BUYING-CHAIN-REPAIR'):
    directory = root / '.agent/artifacts' / folder
    manifest = json.loads((directory / 'RAW-MANIFEST.json').read_text())
    archive = directory / manifest['archive']['path']
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archive']['sha256']
    entries = manifest.get('evidence', manifest.get('files'))
    with zipfile.ZipFile(archive) as zipped:
        for entry in entries:
            name = entry.get('archive_path', entry.get('path'))
            data = zipped.read(name) if name is not None else (root / entry['source_path']).read_bytes()
            assert len(data) == entry['bytes']
            assert hashlib.sha256(data).hexdigest() == entry['sha256']
    receipts.append({'folder': folder, 'entries_verified': len(entries), 'archive_sha256': manifest['archive']['sha256']})
print(json.dumps({'builder_archives_exact': receipts}))
