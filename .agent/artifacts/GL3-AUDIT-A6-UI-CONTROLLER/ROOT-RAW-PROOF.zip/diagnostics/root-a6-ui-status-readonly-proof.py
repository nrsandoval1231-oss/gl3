"""Independent read-only check of existing synthetic status load; zero writes."""
import hashlib
import importlib
import json
import os
import time
import tracemalloc
import uuid

provider_keys = ("FIRECRAWL_API_KEY", "OPENAI_API_KEY", "TYPESAFE_API_KEY")
assert all(not os.environ.get(key) for key in provider_keys)
assert os.environ.get("WORKER_AUTO_REFRESH", "").lower() == "false"
assert os.environ.get("AUTONOMOUS_RESEARCH_ENABLED", "").lower() == "false"
expected_url = "postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_ui_status_scale_test"
assert os.environ.get("DATABASE_URL") == expected_url

import psycopg
from fastapi import Response
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker

plain_url = "postgresql://gl3audit@127.0.0.1:55437/gl3audit_a6_ui_status_scale_test"
statuses = ("New", "Investigating", "Contacted", "Qualified", "Won", "Lost", "Closed")
with psycopg.connect(plain_url) as connection:
    connection.execute("SET TRANSACTION READ ONLY")
    needs = connection.execute("SELECT id, project_id FROM power_needs WHERE active IS TRUE ORDER BY id").fetchall()
    inserted = connection.execute("SELECT count(*) FROM need_workflow_status_events").fetchone()[0]
    unknown = connection.execute("SELECT count(*) FROM power_needs p WHERE active IS TRUE AND NOT EXISTS (SELECT 1 FROM need_workflow_status_events e WHERE e.need_id=p.id)").fetchone()[0]
    assert len(needs) == 1168 and inserted == 1022 and unknown == 146
    connection.rollback()

app = importlib.import_module("gridlens.api.app")
engine = create_engine(expected_url, connect_args={"options": "-c default_transaction_read_only=on"})
app.SessionLocal = sessionmaker(bind=engine)
query_count = 0

def count_query(*_args):
    global query_count
    query_count += 1

event.listen(engine, "before_cursor_execute", count_query)
measurements = []
for selected in (*[value.upper() for value in statuses], "UNKNOWN"):
    before = query_count
    started = time.perf_counter()
    response = Response()
    rows = app.opportunities(
        tier=None, search=None, decision=None, limit=50, offset=0,
        cohort=None, response=response, status=selected,
    )
    elapsed = time.perf_counter() - started
    payload = json.dumps(rows, default=str, sort_keys=True, separators=(",", ":")).encode()
    measurements.append({
        "status": selected,
        "returned_records": len(rows),
        "group_total": response.headers.get("X-Group-Total-Count"),
        "page_records": response.headers.get("X-Page-Record-Count"),
        "query_count": query_count - before,
        "elapsed_seconds": elapsed,
        "serialized_page_bytes": len(payload),
        "serialized_page_sha256": hashlib.sha256(payload).hexdigest(),
    })

before = query_count
started = time.perf_counter()
tracemalloc.start()
with Session(engine) as session:
    cards = app._commercial_triage_cards(session, 50)
    session.rollback()
_, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()
elapsed = time.perf_counter() - started
commercial_payload = json.dumps(cards, default=str, sort_keys=True, separators=(",", ":")).encode()
commercial = {
    "returned_cards": len(cards), "query_count": query_count - before,
    "elapsed_seconds": elapsed, "peak_python_bytes": peak,
    "serialized_page_bytes": len(commercial_payload),
    "serialized_page_sha256": hashlib.sha256(commercial_payload).hexdigest(),
}
engine.dispose()
failures = [entry["status"] for entry in measurements if entry["query_count"] > 200 or entry["returned_records"] > 50]
if commercial["query_count"] > 200 or commercial["returned_cards"] > 50:
    failures.append("commercial")
print(json.dumps({
    "database": "gl3audit_a6_ui_status_scale_test",
    "scope": "Synthetic append-only workflow events on retained-scale copy; reads are transaction read-only",
    "active_needs_seen": len(needs), "synthetic_status_events_present": inserted,
    "real_unknown_needs_left_without_events": len(needs) - inserted,
    "status_pages": measurements, "commercial_page": commercial,
    "query_bound_failures": failures, "provider_calls": 0,
    "original_corpus_tables_written": [], "root_database_writes": 0,
}, sort_keys=True))
raise SystemExit(bool(failures))
