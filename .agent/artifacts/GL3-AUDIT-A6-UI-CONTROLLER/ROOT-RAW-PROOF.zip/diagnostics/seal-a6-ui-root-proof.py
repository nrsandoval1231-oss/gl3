import hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
assert head==sys.argv[1]
output=root/'.agent/artifacts/GL3-AUDIT-A6-UI-CONTROLLER'
inputs={}
for p in (root/'.artifacts').iterdir():
 if p.is_file() and (p.suffix in {'.log','.py','.ps1','.json','.txt'} or p.name=='root-a6-ui-generated-check.ts'):inputs['diagnostics/'+p.name]=p
for name in ['root-a6-ui-controller-before','root-a6-ui-first-source-capture','root-a6-ui-final-browser-results','root-a6-ui-r1-final-browser-results','root-a6-ui-persisted-browser-results','root-a6-accepted-pr43-remote']:
 d=root/'.artifacts'/name
 assert d.is_dir(),name
 extended=Path('\\\\?\\'+str(d.absolute())) if os.name=='nt' else d
 for p in extended.rglob('*'):
  if p.is_file():inputs[name+'/'+p.relative_to(extended).as_posix()]=p
for d in (root/'.agent/artifacts').iterdir():
 if d.is_dir() and (d.name=='GL3-AUDIT-A6-SELECTED-INTERVAL-CONTROLLER' or (d.name.startswith('GL3-AUDIT-A6-UI') and d.name!=output.name)):
  for p in d.rglob('*'):
   if p.is_file():inputs['evidence/'+d.name+'/'+p.relative_to(d).as_posix()]=p
for name in ['TESTED-SOURCE-MANIFEST.json','GATES.md','COMPLETION.json','EPISODE.md']:inputs['controller/'+name]=output/name
for name in ['CURRENT_STATE.md','WORK_GRAPH.md']:inputs['controller/'+name]=root/'.agent'/name
archive_path=output/'ROOT-RAW-PROOF.zip'
entries=[]
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(inputs.items()):
  data=p.read_bytes();z.writestr(name,data);entries.append({'entry':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive_path) as z:
 for e in entries:assert hashlib.sha256(z.read(e['entry'])).hexdigest()==e['sha256']
with (output/'RAW-HASH-MANIFEST.json').open('x') as f:
 json.dump({'tested_head':head,'archive':archive_path.name,'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'entries':entries,'private_exclusions':['Configuration, original private failed auth trace and corpus dumps/oracles excluded; accepted backend archive preserves attributed redacted proof'],'limitations':['Local deterministic proof; independent acceptance pending; unretained tool bytes UNKNOWN']},f,indent=2)
print(json.dumps({'tested_head':head,'entries':len(entries),'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest()}))
