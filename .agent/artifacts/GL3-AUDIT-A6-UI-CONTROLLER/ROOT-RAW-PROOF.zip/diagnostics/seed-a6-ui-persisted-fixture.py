import json
from uuid import uuid4
from pathlib import Path
from sqlalchemy import select
from gridlens.persistence.database import SessionLocal
from gridlens.persistence.models import PowerNeed, Project, Source

source_id = 'a6-ui-builder-synthetic'
with SessionLocal.begin() as session:
    if session.get(Source, source_id) is None:
        session.add(Source(id=source_id, publisher='Synthetic UI Test', endpoint='https://example.test/ui', family='synthetic', geography='Test City', industries=['construction'], retrieval_method='synthetic', health={}))
        session.flush()
    fixture_key = f'a6-ui-browser-{uuid4()}'
    project = Project(identity_key=fixture_key, name=f'Synthetic UI Facility {fixture_key[-8:]}', location='Test City', source_id=source_id, external_id=fixture_key)
    session.add(project)
    session.flush()
    need = PowerNeed(project_id=project.id, activity_key='construction', tier='Signal', rationale='Synthetic isolated UI fixture; no qualified source lead.', supply='Unknown', active=True)
    session.add(need)
    session.flush()
    output = {'need_id': str(need.id), 'project_id': str(project.id), 'name': project.name}
Path(__file__).resolve().parent.joinpath('a6-ui-persisted-fixture.json').write_text(json.dumps(output, sort_keys=True), encoding='utf-8')
print(json.dumps(output, sort_keys=True))