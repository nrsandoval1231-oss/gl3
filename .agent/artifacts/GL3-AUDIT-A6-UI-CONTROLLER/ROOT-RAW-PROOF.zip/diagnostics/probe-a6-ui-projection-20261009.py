from uuid import UUID
from sqlalchemy import select
from gridlens.persistence.database import SessionLocal
from gridlens.persistence.models import Evidence, Interpretation, NeedObservation, Observation, PowerNeed, Project, Source
from gridlens.api.app import opportunity_projection, _need_has_current_support
from gridlens.domain.signal_admission import admitted_from_source
from gridlens.ingestion.service import effective_need_qualification
need_id=UUID('eee7cf28-97d1-4aad-93d6-177c9a7bfa93')
with SessionLocal() as session:
    need=session.get(PowerNeed,need_id)
    project=session.get(Project,need.project_id) if need else None
    print({'need':str(need.id) if need else None,'active':need.active if need else None,'tier':need.tier if need else None,'source':project.source_id if project else None,'support':_need_has_current_support(session,need,project) if need and project else None})
    rows=session.execute(select(Observation,Evidence,Interpretation,Source).join(NeedObservation,NeedObservation.observation_id==Observation.id).join(Evidence,Evidence.observation_id==Observation.id).outerjoin(Interpretation,Interpretation.observation_id==Observation.id).join(Source,Source.id==Observation.source_id).where(NeedObservation.need_id==need_id)).all()
    for obs,ev,it,src in rows:
        print({'source_family':src.family,'retrieval':src.retrieval_method,'obs_hash':obs.content_hash,'evidence_hash':ev.content_hash,'interp_status':it.status if it else None,'interp_hash':it.content_hash if it else None,'assessment':it.assessment if it else None,'admitted':admitted_from_source(src,it.assessment or {},ev).admitted if it else None})
    print({'summary':opportunity_projection(session,tier='Signal',summary_only=True,selected_need_ids={need_id})})
    print({'detail':opportunity_projection(session,selected_need_ids={need_id})})
