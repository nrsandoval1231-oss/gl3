from uuid import UUID
from gridlens.persistence.database import SessionLocal
from gridlens.api.app import opportunity_projection, _need_has_current_support
from gridlens.persistence.models import PowerNeed, Project
need_id=UUID('144e26ae-e8a3-4654-b497-14069d8ebd9f')
with SessionLocal() as session:
    need=session.get(PowerNeed,need_id); project=session.get(Project,need.project_id)
    summary=opportunity_projection(session,tier='Signal',summary_only=True,selected_need_ids={need_id})
    detail=opportunity_projection(session,selected_need_ids={need_id})
    print({'need':str(need.id),'support':_need_has_current_support(session,need,project),'summary_count':len(summary),'summary_tiers':[row['tier'] for row in summary],'detail_count':len(detail),'detail_ids':[str(row['id']) for row in detail]})
