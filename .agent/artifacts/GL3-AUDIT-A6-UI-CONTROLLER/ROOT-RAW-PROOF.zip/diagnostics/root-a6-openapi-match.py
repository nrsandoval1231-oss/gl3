import json
from pathlib import Path
from gridlens.api.app import app

expected = json.loads((Path(__file__).resolve().parents[1] / "web/src/api/openapi.json").read_text(encoding="utf-8"))
actual = app.openapi()
assert actual == expected, "Generated OpenAPI differs from frozen API"
print(json.dumps({"openapi_exact_match": True, "paths": len(actual["paths"])}))
