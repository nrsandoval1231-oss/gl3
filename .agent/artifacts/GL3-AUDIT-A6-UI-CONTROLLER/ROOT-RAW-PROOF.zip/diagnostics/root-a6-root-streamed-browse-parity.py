"""Independent read-only retained-corpus comparator; providers must be absent."""
import gzip
import hashlib
import importlib
import json
import os
import time
from datetime import date
from pathlib import Path
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session

assert all(not os.environ.get(key) for key in ("FIRECRAWL_API_KEY", "OPENAI_API_KEY", "TYPESAFE_API_KEY"))
root = Path(__file__).resolve().parents[1]
archive = root.parent / "gl3-audit-repair-20261007/.artifacts/audit-20261007/root-a5b-frozen-client-oracle"
oracle = json.loads(gzip.decompress((archive / "oracle.json.gz").read_bytes()))
decisions = json.loads(gzip.decompress((archive / "decision-oracle.json.gz").read_bytes()))
app = importlib.import_module("gridlens.api.app")
project_state = importlib.import_module("gridlens.intelligence.project_state")
class FrozenDate(date):
    @classmethod
    def today(cls):
        return cls(2026, 10, 7)
project_state.date = FrozenDate
engine = create_engine("postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_corpus_test")
sql_count = 0
@event.listens_for(engine, "before_cursor_execute")
def count_sql(*args):
    global sql_count
    sql_count += 1
failures = []
def compare(label, actual, expected):
    if actual != expected:
        failures.append({"check": label, "actual_sha256": hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest(), "expected_sha256": hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest()})
started = time.perf_counter()
with Session(engine) as session:
    session.execute(text("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY"))
    assert session.scalar(text("SHOW transaction_read_only")) == "on"
    rows = app.opportunity_projection(session, summary_only=True)
    rows.sort(key=lambda r: str(r["id"]))
    rows.sort(key=lambda r: r["_updated_at"], reverse=True)
    # The scalar evidence stream also folds canonical metadata before grouping.
    app._opportunity_evidence_search_matches(session, rows, "")
    groups = app.grouped_opportunities(rows)
    compare("group_keys_members_order", [{"key": key, "ids": [str(r["id"]) for r in members]} for key, members in groups], [{"key": g["key"], "ids": g["ids"]} for g in oracle["groups"]])
    actual_titles = [{"id": str(r["id"]), "title": app.opportunity_project_title(r)} for r in rows]
    compare("all_record_titles", actual_titles, oracle["titles"])
    expected_title_by_id = {r["id"]: r["title"] for r in oracle["titles"]}
    title_mismatch_ids = [r["id"] for r in actual_titles if r["title"] != expected_title_by_id.get(r["id"])]
    compare("all_group_decisions", [{"key": key, "decision": app.grouped_signal_decision(members)} for key, members in groups], decisions["group_decisions"])
    for query in oracle["queries"]:
        term = query["query"]
        matches = app._opportunity_evidence_search_matches(session, rows, term)
        matched = {str(r["id"]): app.matched_opportunity(r, term, matches.get(str(r["id"]), False)) for r in rows}
        compare("matched_ids:" + hashlib.sha256(term.encode()).hexdigest()[:12], [str(r["id"]) for r in rows if matched[str(r["id"])]], query["matched_ids"])
        compare("selected_groups:" + hashlib.sha256(term.encode()).hexdigest()[:12], [key for key, members in groups if any(matched[str(r["id"])] for r in members)], query["selected_group_keys"])
    session.rollback()
engine.dispose()
print(json.dumps({"scope": "Read-only retained stream; frozen project-state date 2026-10-07; exact grouping/titles/decisions and 17 searches", "rows": len(rows), "groups": len(groups), "queries": len(oracle["queries"]), "sql_count": sql_count, "elapsed_seconds": time.perf_counter() - started, "title_mismatch_ids": title_mismatch_ids, "failures": failures, "provider_calls": 0, "original_data_writes": 0}))
raise SystemExit(bool(failures))
