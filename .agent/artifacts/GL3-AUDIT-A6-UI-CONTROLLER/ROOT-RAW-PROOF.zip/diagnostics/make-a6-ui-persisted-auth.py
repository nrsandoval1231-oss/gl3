from pathlib import Path
import bcrypt
password = b'SyntheticUiPass2026!'
encoded = bcrypt.hashpw(password, bcrypt.gensalt(rounds=4)).decode('ascii')
Path(__file__).resolve().parent.joinpath('a6-ui-persisted-password-hash.txt').write_text(encoded, encoding='ascii')