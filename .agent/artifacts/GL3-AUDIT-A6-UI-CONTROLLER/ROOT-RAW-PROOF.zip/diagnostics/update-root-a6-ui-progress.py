import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-UI-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())
paths = {entry['path'] for entry in manifest['entries']}
updates = {
    '.agent/CURRENT_STATE.md': '''# Current state — GL3 audit repair

Parent OPEN. Canonical PRD, Finish Contract, original evidence and protected reference manifest govern. No merge, deployment, paid activation or external sends authorized.

Bounded A3/A9/A1/A2/A4/A5A/A5B and A6 backend remain independently accepted. A6 backend draft PR43 is published at daedade06adc0dbe18fb09c46a5dcfc2444681f5; push and PR Actions succeeded. Remote join remains 5c03880584f6aacae95a81ab2231a80e63503cc8.

A6 UI/status is frozen at 86ada778cec8c7f3d21e26872f9421c3fb82b209 with 278 source/governing inputs. Root backend: 1471 passed, 2 environment skips, 7 warnings, 237.52s. Full regression browser: 72 passed, one dedicated persistence test skipped, 47.3s. That persisted API/browser flow separately passed on a fresh root-owned synthetic source-backed PostgreSQL fixture, including real current detail and before/after tier truth. Static, fresh/repeat migration/drift, 34-path OpenAPI/client, dependency, 1167-record/1149-group parity, 24-page and original-column preservation checks passed. Final performance/status receipts, sealed archive and independent Sol review remain required before acceptance/publication. Known-credential pre-seal scan: 46936 entries, zero matches; tool history and unretained bytes UNKNOWN.

Prior navigation/version product repairs, incomplete browser DTO fixtures, invalid synthetic source admission, stale repeated fixture and controller capture/manifest-reader mistakes remain attributed and preserved. Admission/qualification was not weakened. Original 24 table fingerprints and preserved dump checksum match. Test-only registered source metadata is not authentic feed/customer evidence.

A7 checksum-matching original PNG/HTML remain absent; supplied video supplemental. A8A supplement is prepared but dependent on exact UI PASS; A8B and authentic feed/quality/seven-day/customer gates remain OPEN. Runtime model/config and unmeasured tokens UNKNOWN. Direction VALIDATE then ordinary independent review; no parent completion.
''',
    '.agent/WORK_GRAPH.md': '''# Work graph — GL3 audit frontier

Parent OPEN; canonical PRD, Finish Contract and protected reference manifest govern. Previous state/graph bytes preserved under dispatch and controller-before archives.

- ACCEPTED bounded A3/A9/A1/A2/A4/A5A/A5B and A6 backend. PR43 published with successful push/PR Actions; no merge/deploy.
- FROZEN A6-UI-STATUS and bounded buying-chain fixture repair at 86ada778cec8c7f3d21e26872f9421c3fb82b209. Sole Luna terminal handoff. Root backend1471/2 environment skips and browser72/1 dedicated skip PASS; separate fresh persisted API/browser PASS. Prior failures retained.
- VALIDATING exact source, retained performance/status population, immutable data and proof archive. Ordinary independent review pending; green deterministic gates do not accept UI or parent.
- DEPENDENT A8A inert deployment/alerts/diagnostics/restore. Ready-to-bind supplement prepared in old controller; actual accepted UI base and migration identity wait for exact PASS. A8B follows A8A. Authentic feed, quality, consecutive-cycle and customer gates OPEN.
- EXTERNAL A7 original PNG/HTML absent; supplied video supplemental, protected visual identity unchanged.

Direction VALIDATE then Sol review. Findings become bounded correction packets. No speculative parallel work, original-data mutation, paid activation, external sends or parent completion. Status/notes are not qualification evidence; Reported dates and immutable saved history remain separate from current reports.
''',
}
receipts = []
for name in updates:
    assert name not in paths, 'Progress update would change a frozen governing source'
for name, content in updates.items():
    path = root / name
    original = path.read_bytes()
    destination = root / '.artifacts/root-a6-ui-controller-before' / ('pre-proof-' + path.name)
    with destination.open('xb') as saved:
        saved.write(original)
    path.write_text(content, encoding='utf-8')
    receipts.append({'path': name, 'preserved_bytes': len(original), 'preserved_sha256': hashlib.sha256(original).hexdigest()})
print(json.dumps({'progress_updates': receipts, 'source_manifest_unchanged': True}))
