"""Frozen retained public-page traversal; database connection is read-only by default."""
import gzip
import importlib
import json
import os
import time
from collections import Counter
from datetime import date
from pathlib import Path
from fastapi import Response
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker

assert all(not os.environ.get(k) for k in ("FIRECRAWL_API_KEY", "OPENAI_API_KEY", "TYPESAFE_API_KEY"))
root = Path(__file__).resolve().parents[1]
archive = root.parent / "gl3-audit-repair-20261007/.artifacts/audit-20261007"
rows = json.loads(gzip.decompress((archive / "a5-accepted-oracle/semantic-oracle.json.gz").read_bytes()))["rows"]
oracle = json.loads(gzip.decompress((archive / "root-a5b-frozen-client-oracle/oracle.json.gz").read_bytes()))
group_by_id = {need_id: group for group in oracle["groups"] for need_id in group["ids"]}
app = importlib.import_module("gridlens.api.app")
state = importlib.import_module("gridlens.intelligence.project_state")
class FrozenDate(date):
    @classmethod
    def today(cls):
        return cls(2026, 10, 7)
state.date = FrozenDate
engine = create_engine("postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_corpus_test", connect_args={"options": "-c default_transaction_read_only=on"})
app.SessionLocal = sessionmaker(bind=engine)
sql = 0
@event.listens_for(engine, "before_cursor_execute")
def count(*args):
    global sql
    sql += 1
started = time.perf_counter()
visited = []
token = None
receipts = []
for offset in range(0, len(rows), 50):
    response = Response()
    sql_before = sql
    page = app.opportunities(offset=offset, cohort=token, response=response)
    ids = [str(item["id"]) for item in page]
    assert ids == [r["id"] for r in rows[offset:offset + 50]], "Record order or membership changed"
    assert len(page) <= 50
    assert int(response.headers["X-Total-Count"]) == len(rows)
    assert int(response.headers["X-Group-Total-Count"]) == len(oracle["groups"])
    current_token = response.headers["X-Cohort-Token"]
    assert token is None or token == current_token, "Read-only stable cohort changed"
    token = current_token
    loaded = Counter(group_by_id[need_id]["key"] for need_id in ids)
    for item in page:
        group = group_by_id[str(item["id"])]
        assert item["group_id"] == app.opportunity_group_id(group["key"])
        assert item["group_total_filtered"] == len(group["ids"])
        assert item["group_loaded_on_page"] == loaded[group["key"]]
        assert item["group_complete_on_page"] == (loaded[group["key"]] == len(group["ids"]))
        assert item["group_title"] == group["title"]
    assert response.headers.get("X-Next-Offset") == (str(offset + len(page)) if offset + len(page) < len(rows) else None)
    visited.extend(ids)
    receipts.append({"offset": offset, "records": len(page), "sql": sql - sql_before})
assert len(set(visited)) == len(rows)
engine.dispose()
print(json.dumps({"scope": "Default 50-record public handler traversal, frozen actual TypeScript grouping/title/metadata, read-only retained clone", "records": len(visited), "groups": len(oracle["groups"]), "pages": receipts, "sql": sql, "elapsed_seconds": time.perf_counter() - started, "provider_calls": 0, "original_data_writes": 0}))
