$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$taskSafe=Join-Path $PSScriptRoot 'root-a6-ui-safe.ps1'
foreach($taskProvider in @('FIRECRAWL_API_KEY','OPENAI_API_KEY','TYPESAFE_API_KEY')){[Environment]::SetEnvironmentVariable($taskProvider,'','Process')}
$env:WORKER_AUTO_REFRESH='false';$env:AUTONOMOUS_RESEARCH_ENABLED='false'
foreach($taskStep in @(@('upgrade','head'),@('upgrade','head'),@('check'))){
 $taskLabel='root-a6-ui-fresh-'+($taskStep -join '-')+'-'+[Guid]::NewGuid().ToString('N')
 & $taskSafe -Tool alembic -ToolArguments $taskStep -ApplicationDatabase gl3audit_a6_ui_fresh_migration -Label $taskLabel
 if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
}
& $taskSafe -Tool python -ToolArguments @((Join-Path $PSScriptRoot 'root-a6-openapi-match.py')) -Label root-a6-ui-openapi
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$taskExport=Join-Path $PSScriptRoot 'root-a6-ui-requirements.txt'
$taskAudit=Join-Path $PSScriptRoot 'root-a6-ui-python-audit.log'
if((Test-Path -LiteralPath $taskExport) -or (Test-Path -LiteralPath $taskAudit)){throw 'Refusing dependency proof overwrite'}
Set-Location (Join-Path $taskRoot 'backend')
& 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' export --locked --no-dev --no-emit-project --format requirements-txt --output-file $taskExport *> (Join-Path $PSScriptRoot 'root-a6-ui-locked-export.log')
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' tool run --from pip-audit==2.10.1 pip-audit -r $taskExport --require-hashes --disable-pip --no-deps *> $taskAudit
$taskExit=$LASTEXITCODE
Get-Content -LiteralPath $taskAudit -Tail 6
if($taskExit -ne 0){exit $taskExit}
Set-Location (Join-Path $taskRoot 'web')
& npm.cmd exec openapi-typescript -- src/api/openapi.json -o (Join-Path $PSScriptRoot 'root-a6-ui-generated-check.ts') *> (Join-Path $PSScriptRoot 'root-a6-ui-generated-check.log')
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$taskActual=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'root-a6-ui-generated-check.ts') -Algorithm SHA256).Hash
$taskExpected=(Get-FileHash -LiteralPath (Join-Path $taskRoot 'web/src/api/generated.ts') -Algorithm SHA256).Hash
if($taskActual -ne $taskExpected){throw 'Generated client differs'}
Write-Output "Generated client exact SHA-256 $taskActual"
