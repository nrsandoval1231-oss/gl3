from datetime import UTC, datetime, timedelta
from fastapi.testclient import TestClient
from gridlens.api.app import app
from gridlens.security import token_for
client = TestClient(app)
client.cookies.set('gridlens_session', token_for(int((datetime.now(UTC) + timedelta(hours=1)).timestamp())))
for tier in (None, 'Signal', 'Prospect', 'Lead'):
 params = {'search':'','decision':'ALL','limit':50,'offset':0}
 if tier is not None: params['tier']=tier
 r = client.get('/api/opportunities', params=params)
 items = r.json() if r.status_code == 200 else []
 match = [item for item in items if item.get('id') == 'ba03cefa-00b5-47b7-8b32-96028ed448ca']
 print({'tier':tier,'http':r.status_code,'returned':len(items),'groups':r.headers.get('X-Group-Total-Count'),'match_count':len(match),'match_tier':match[0].get('tier') if match else None})