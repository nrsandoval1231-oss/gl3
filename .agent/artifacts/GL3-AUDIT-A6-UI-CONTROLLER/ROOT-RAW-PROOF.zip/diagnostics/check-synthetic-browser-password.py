import bcrypt
candidate = b'password'
digest = b'$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxNQSZBlN/1VGziLI9YCVWVBzJu'
print('synthetic_login_candidate_matches=' + str(bcrypt.checkpw(candidate, digest)))