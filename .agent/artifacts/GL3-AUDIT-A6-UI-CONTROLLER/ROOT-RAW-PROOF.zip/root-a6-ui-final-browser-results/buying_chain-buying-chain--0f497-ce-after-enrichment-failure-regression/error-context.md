# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: buying_chain.spec.ts >> buying chain exposes three separate relationships and retains evidence after enrichment failure
- Location: tests\buying_chain.spec.ts:46:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Buying chain' }).getByRole('heading', { name: 'Test Electrical one' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('region', { name: 'Buying chain' }).getByRole('heading', { name: 'Test Electrical one' }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Buying chain' }).getByRole('heading', { name: 'Test Electrical one' })

```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | import type { BuyingChainResult, Opportunity } from '../src/api/client'
  3   | 
  4   | const apiRoute = `http://127.0.0.1:${process.env.GRIDLENS_WEB_PORT ?? '5173'}/api/**`
  5   | const stamp = '2026-09-30T12:00:00Z'
  6   | const project = (id: string): Opportunity => ({
  7   |   id, project_id: id, name: `Test facility ${id}`, location: 'Chicago, IL', tier: 'Signal',
  8   |   workflow_status: 'UNKNOWN',
  9   |   activity: 'construction', rationale: 'A test-only sourced construction event.',
  10  |   brief_status: 'unavailable', brief_stale: false,
  11  |   required_mw: null, start_window: null, duration: null, supply: 'Unknown',
  12  |   next_action: 'Confirm temporary power procurement.', conflict_state: 'Not assessed',
  13  |   signal_display_decision: 'SHOW', signal_display_decision_state: 'adjudicated', signal_evidence_state: 'active_evidence', evidence: [],
  14  | })
  15  | const chain = (id: string): BuyingChainResult => ({
  16  |   project_id: id, status: 'complete', policy_version: 'buying-chain-v1',
  17  |   unresolved: ['Temporary power purchasing authority remains UNKNOWN.'], runs: [],
  18  |   candidates: [{
  19  |     id: `candidate-${id}`, organization: `Test Electrical ${id}`, person_name: 'Test Person',
  20  |     title: 'Director of Construction', category: 'electrical_contractor',
  21  |     organization_relationship: 'DIRECT', person_organization_relationship: 'CURRENT',
  22  |     person_project_relationship: 'ROLE_SUPPORTED', evidence_strength: 'Medium',
  23  |     reason: 'Test fixture: employer involved, current relevant role, no personal assignment evidence.',
  24  |     observed_at: stamp, verified_at: stamp, stale: false, history_count: 1,
  25  |     public_contacts: [], evidence: [{
  26  |       id: 'evidence-1', url: 'https://example.com/project', quote: 'Test Electrical is the electrical contractor.',
  27  |       supports: 'project_organization', extraction_location: 'contractor field',
  28  |       published_at: null, observed_at: stamp, content_hash: 'fixture-hash',
  29  |     }],
  30  |   }],
  31  | })
  32  | 
  33  | async function shell(page: import('@playwright/test').Page, buying: (route: import('@playwright/test').Route) => Promise<void>) {
  34  |   await page.route(apiRoute, async (route) => {
  35  |     const path = new URL(route.request().url()).pathname
  36  |     if (path.includes('/buying-chain')) { await buying(route); return }
  37  |     const body = path === '/api/auth/session' ? { authenticated: true }
  38  |       : path === '/api/opportunities' ? [project('one'), project('two')]
  39  |       : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  40  |     await route.fulfill({ contentType: 'application/json', body: JSON.stringify(body) })
  41  |   })
  42  |   await page.goto('/?tier=Signals')
  43  |   await page.getByRole('button', { name: /Test facility one/ }).click()
  44  | }
  45  | 
  46  | test('buying chain exposes three separate relationships and retains evidence after enrichment failure', async ({ page }) => {
  47  |   let posts = 0
  48  |   await shell(page, async (route) => {
  49  |     if (route.request().method() === 'POST') {
  50  |       posts += 1
  51  |       await route.fulfill({ status: 503, body: 'unavailable' })
  52  |     } else await route.fulfill({ contentType: 'application/json', body: JSON.stringify(chain('one')) })
  53  |   })
  54  |   const section = page.getByRole('region', { name: 'Buying chain' })
> 55  |   await expect(section.getByRole('heading', { name: 'Test Electrical one' })).toBeVisible()
      |                                                                               ^ Error: expect(locator).toBeVisible() failed
  56  |   await expect(section.getByText('Project → organization')).toBeVisible()
  57  |   await expect(section.getByText('Organization → person')).toBeVisible()
  58  |   await expect(section.getByText('Person → project')).toBeVisible()
  59  |   await expect(section.getByText('Role-supported · project assignment unknown', { exact: true })).toBeVisible()
  60  |   await expect(section.getByText('Public business contact details unknown')).toBeVisible()
  61  |   await section.getByText('Inspect relationship evidence (1)').click()
  62  |   await expect(section.getByText('Test Electrical is the electrical contractor.')).toBeVisible()
  63  |   await section.getByRole('button', { name: 'Enrich buying chain' }).click()
  64  |   await expect(section.getByRole('alert')).toContainText('Previously retained findings remain below')
  65  |   await expect(section.getByRole('heading', { name: 'Test Electrical one' })).toBeVisible()
  66  |   expect(posts).toBe(1)
  67  | })
  68  | 
  69  | test('navigation ignores a late enrichment result and limits repeated requests', async ({ page }) => {
  70  |   let finish: (() => void) | undefined
  71  |   let posts = 0
  72  |   const release = new Promise<void>((resolve) => { finish = resolve })
  73  |   await shell(page, async (route) => {
  74  |     const id = route.request().url().includes('/one/') ? 'one' : 'two'
  75  |     if (route.request().method() === 'POST') { posts += 1; await release }
  76  |     await route.fulfill({ contentType: 'application/json', body: JSON.stringify(chain(id)) })
  77  |   })
  78  |   const button = page.getByRole('button', { name: 'Enrich buying chain' })
  79  |   await expect(button).toBeEnabled()
  80  |   await button.click()
  81  |   await expect(page.getByRole('button', { name: 'Checking evidence…' })).toBeDisabled()
  82  |   await page.getByRole('button', { name: 'Next →' }).click()
  83  |   await expect(page.getByRole('heading', { name: 'Test Electrical two' })).toBeVisible()
  84  |   const finished = page.waitForResponse((response) => response.request().method() === 'POST' && response.url().includes('/buying-chain/enrich'))
  85  |   finish!()
  86  |   await finished
  87  |   await expect(page.getByRole('heading', { name: 'Test Electrical one' })).toHaveCount(0)
  88  |   expect(posts).toBe(1)
  89  |   await page.getByRole('button', { name: /Back to Signals/ }).click()
  90  |   await expect(page.getByRole('button', { name: /Test facility one/ })).toBeVisible()
  91  |   await page.goForward()
  92  |   await expect(page.getByRole('heading', { name: 'Test Electrical two' })).toBeVisible()
  93  | })
  94  | 
  95  | test('mobile buying chain keeps unknown and empty results readable', async ({ page }) => {
  96  |   await page.setViewportSize({ width: 390, height: 844 })
  97  |   await shell(page, async (route) => {
  98  |     await route.fulfill({ contentType: 'application/json', body: JSON.stringify({ ...chain('one'), candidates: [], status: 'unresolved' }) })
  99  |   })
  100 |   await expect(page.getByText('No supported buying-chain candidates retained yet. Buyer and project contacts remain unknown.')).toBeVisible()
  101 |   await expect(page.getByText('Temporary power purchasing authority remains UNKNOWN.')).toBeVisible()
  102 |   await page.getByText('Add supporting source links').click()
  103 |   await page.getByRole('textbox', { name: 'Public project or organization sources (up to four)' }).fill('http://127.0.0.1/private')
  104 |   await page.getByRole('button', { name: 'Enrich buying chain' }).click()
  105 |   await expect(page.getByRole('alert')).toHaveText('Use up to four public HTTPS source links, one per line.')
  106 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy()
  107 | })
  108 | 
  109 | test('retained permit fields are useful before enrichment and preserve source roles', async ({ page }) => {
  110 |   const result = chain('one')
  111 |   result.permit_summaries = [{
  112 |     evidence_id: 'permit-1', source_id: 'chicago-building-permits',
  113 |     url: 'https://data.cityofchicago.org/resource/ydr8-5enu.json',
  114 |     title: 'Synthetic data-center permit', observed_at: stamp,
  115 |     extraction_location: 'Official Chicago permit fields',
  116 |     facts: [
  117 |       { label: 'Permit scope', value: 'Data center conversion with MEP upgrades', quote: 'description: Data center conversion with MEP upgrades' },
  118 |       { label: 'Permit-listed party · ARCHITECT', value: 'DOE, JANE', quote: 'contact_2_name: DOE, JANE', role_quote: 'contact_2_type: ARCHITECT' },
  119 |       { label: 'Application start date', value: '2026-06-17', quote: 'application_start: 2026-06-17' },
  120 |     ],
  121 |   }]
  122 |   await shell(page, async (route) => {
  123 |     expect(route.request().method()).toBe('GET')
  124 |     await route.fulfill({ contentType: 'application/json', body: JSON.stringify(result) })
  125 |   })
  126 |   await expect(page.getByRole('heading', { name: 'Retained permit facts' })).toBeVisible()
  127 |   await expect(page.getByText('Data center conversion with MEP upgrades', { exact: true })).toBeVisible()
  128 |   await expect(page.getByText('DOE, JANE', { exact: true })).toBeVisible()
  129 |   await page.getByText('Field evidence', { exact: true }).nth(1).click()
  130 |   await expect(page.getByText('contact_2_type: ARCHITECT', { exact: true })).toBeVisible()
  131 |   await expect(page.getByText(/Permit dates describe permitting/)).toBeVisible()
  132 | })
  133 | 
```