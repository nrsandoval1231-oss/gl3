# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project_cards.spec.ts >> stale later-page cohort restarts at page one without showing the previous cohort
- Location: tests\project_cards.spec.ts:222:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /Old cohort construction filing/ })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: /Old cohort construction filing/ }) with timeout 5000ms
  - waiting for getByRole('button', { name: /Old cohort construction filing/ })

```

```yaml
- banner:
  - link "GridLens home":
    - /url: /?tier=Signals&q=
    - img "GridLens"
  - navigation "Workspace views":
    - button "Signals"
    - button "Prospects"
    - button "Leads"
    - button "Today’s pursuits"
    - button "Ingestion"
  - button "Source health"
  - button "Sign out"
- main:
  - paragraph: Evidence-led project discovery
  - heading "Signals" [level=1]
  - paragraph: SHOW means this project or event is worth investigating. It does not mean a qualified opportunity.
  - paragraph: Today
  - strong: 0 material changes
  - text: No material opportunity changes today.
  - heading "Signals · 1 filtered project cards · 1 filtered opportunity records" [level=2]
  - paragraph: All · 1 cards and 1 records on this page of 1 filtered cards and 1 records. SHOW means worth investigating, not qualified.
  - text: Search projects
  - textbox "Search projects":
    - /placeholder: Search projects, work, or permit ID
  - link "Download filtered CSV":
    - /url: /api/opportunities/export.csv?tier=Signal&search=&decision=ALL&cohort_token=old-cohort-token
  - text: Geography
  - combobox "Select unknown geography":
    - option "Any exact location" [selected]
    - option "Unknown"
  - textbox "Filter by exact geography":
    - /placeholder: Exact stored location
  - text: Industry
  - combobox "Select unknown industry":
    - option "Any exact asset type" [selected]
    - option "Unknown"
  - textbox "Filter by exact project asset type":
    - /placeholder: Exact stored asset type
  - text: Activity
  - combobox "Select unknown activity":
    - option "Any exact activity" [selected]
    - option "Unknown"
  - textbox "Filter by exact power activity":
    - /placeholder: Exact stored activity
  - text: Timing
  - combobox "Filter by supported timing availability":
    - option "Any timing" [selected]
    - option "Known"
    - option "Unknown"
  - text: Required MW
  - combobox "Filter by required MW availability":
    - option "Any MW status" [selected]
    - option "Known"
    - option "Unknown"
  - text: MW minimum
  - textbox "Minimum overlapping required MW":
    - /placeholder: MW minimum
  - text: MW maximum
  - textbox "Maximum overlapping required MW":
    - /placeholder: MW maximum
  - text: Priority
  - combobox "Filter by canonical priority segment":
    - option "Any priority" [selected]
    - option "Segment 0"
    - option "Segment 1"
    - option "Segment 2"
    - option "Segment 3"
    - option "Segment 4"
    - option "Segment 5"
    - option "Segment 6"
    - option "Segment 7"
    - option "Segment 8"
  - text: Workflow status
  - combobox "Filter by workflow status":
    - option "Any status" [selected]
    - option "Unknown"
  - group "Filter Signals by review decision":
    - button "All 1" [pressed]
    - button "SHOW 1"
    - button "REVIEW 0"
    - button "HOLD 0"
  - 'button "Old Cohort Construction Filing 2100 BARTON SPRINGS RD, AUSTIN, TX Decision: SHOW Signal"':
    - strong: Old Cohort Construction Filing
    - text: 2100 BARTON SPRINGS RD, AUSTIN, TX
    - strong: "Decision: SHOW"
    - text: Signal
  - text: 1 filtered records · page 1
  - button "← Previous" [disabled]
  - button "Next →"
- contentinfo: Coverage is limited to configured and checked sources. Unknown project facts stay unknown.
```

# Test source

```ts
  156 |   record.group_total_filtered = 1
  157 |   record.group_loaded_on_page = 1
  158 |   record.group_complete_on_page = true
  159 |   record.matched_search = true
  160 |   const requests: URL[] = []
  161 |   await page.route(apiRoute, async (route) => {
  162 |     const url = new URL(route.request().url())
  163 |     const path = url.pathname
  164 |     if (path === '/api/opportunities') requests.push(url)
  165 |     const body = path === '/api/auth/session'
  166 |       ? { authenticated: true }
  167 |       : path === '/api/opportunities'
  168 |         ? [record]
  169 |         : path === '/api/health'
  170 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  171 |           : []
  172 |     await route.fulfill({
  173 |       status: 200,
  174 |       contentType: 'application/json',
  175 |       headers: path === '/api/opportunities'
  176 |         ? { 'X-Total-Count': '1', 'X-Group-Total-Count': '1', 'X-Page-Record-Count': '1', 'X-Page-Group-Count': '1', 'X-Limit': '25', 'X-Offset': url.searchParams.get('offset') ?? '0', 'X-Cohort-Token': 'fixture-cohort', 'X-Decision-Counts': '{"SHOW":1,"REVIEW":0,"HOLD":0}' }
  177 |         : undefined,
  178 |       body: JSON.stringify(body),
  179 |     })
  180 |   })
  181 |   await page.goto('/?tier=Signals&q=campus&decision=SHOW&offset=25&geography=UNKNOWN&industry=data_center&activity=facility-expansion&timing=UNKNOWN&mw_status=UNKNOWN&mw_min=0.3&priority_segment=8&status=UNKNOWN')
  182 |   await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  183 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  184 |   await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('facility-expansion')
  185 |   await expect(page.getByRole('button', { name: /Back to Signals/ })).toHaveCount(0)
  186 |   await expect.poll(() => requests.some((request) => request.searchParams.get('geography') === 'UNKNOWN'
  187 |     && request.searchParams.get('industry') === 'data_center'
  188 |     && request.searchParams.get('activity') === 'facility-expansion'
  189 |     && request.searchParams.get('timing') === 'UNKNOWN'
  190 |     && request.searchParams.get('mw_status') === 'UNKNOWN'
  191 |     && request.searchParams.get('mw_min') === '0.3'
  192 |     && request.searchParams.get('priority_segment') === '8'
  193 |     && request.searchParams.get('status') === 'UNKNOWN')).toBe(true)
  194 |   const opportunityRequests = requests.filter((request) => request.pathname === '/api/opportunities')
  195 |   const laterPageIndex = opportunityRequests.findIndex((request) => request.searchParams.get('offset') === '25')
  196 |   expect(laterPageIndex).toBeGreaterThan(0)
  197 |   expect(opportunityRequests.slice(0, laterPageIndex).every((request) => (request.searchParams.get('offset') ?? '0') === '0'
  198 |     && request.searchParams.get('cohort_token') === null)).toBe(true)
  199 |   expect(opportunityRequests[laterPageIndex].searchParams.get('cohort_token')).toBe('fixture-cohort')
  200 |   await page.locator('[data-opportunity-id="filter-back"]').first().click()
  201 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
  202 |   await page.getByRole('button', { name: /Back to Signals/ }).click()
  203 |   await expect(page.getByRole('textbox', { name: 'Search projects' })).toHaveValue('campus')
  204 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  205 |   await expect(page.getByRole('textbox', { name: 'Filter by exact power activity' })).toHaveValue('facility-expansion')
  206 |   const restored = new URL(page.url())
  207 |   expect(restored.searchParams.get('offset')).toBe('25')
  208 |   expect(restored.searchParams.get('geography')).toBe('UNKNOWN')
  209 |   expect(restored.searchParams.get('industry')).toBe('data_center')
  210 |   expect(restored.searchParams.get('activity')).toBe('facility-expansion')
  211 |   expect(restored.searchParams.get('timing')).toBe('UNKNOWN')
  212 |   expect(restored.searchParams.get('mw_min')).toBe('0.3')
  213 |   expect(restored.searchParams.get('priority_segment')).toBe('8')
  214 |   expect(restored.searchParams.get('status')).toBe('UNKNOWN')
  215 |   await page.goForward()
  216 |   await expect(page.getByRole('heading', { level: 1 })).toContainText('Synthetic campus')
  217 |   await page.goBack()
  218 |   await expect(page.getByRole('textbox', { name: 'Filter by exact project asset type' })).toHaveValue('data_center')
  219 |   expect(new URL(page.url()).searchParams.get('offset')).toBe('25')
  220 | })
  221 | 
  222 | test('stale later-page cohort restarts at page one without showing the previous cohort', async ({ page }) => {
  223 |   const staleRecord = permit('old-cohort-record', 'Old cohort construction filing')
  224 |   const currentRecord = permit('current-cohort-record', 'Current cohort construction filing')
  225 |   let changed = false
  226 |   const requests: URL[] = []
  227 |   await page.route(apiRoute, async (route) => {
  228 |     const url = new URL(route.request().url())
  229 |     if (url.pathname === '/api/opportunities') {
  230 |       requests.push(url)
  231 |       const offset = Number(url.searchParams.get('offset') ?? '0')
  232 |       if (offset > 0 && url.searchParams.get('cohort_token') === 'old-cohort-token' && !changed) {
  233 |         changed = true
  234 |         await route.fulfill({ status: 409, json: { detail: 'Opportunity cohort changed; restart pagination' } })
  235 |         return
  236 |       }
  237 |       const record = changed ? currentRecord : staleRecord
  238 |       const payload = serverOpportunityPage([record], url.searchParams.get('decision') ?? 'ALL')
  239 |       await route.fulfill({
  240 |         status: 200,
  241 |         contentType: 'application/json',
  242 |         headers: { ...payload.headers, 'X-Offset': String(offset), 'X-Cohort-Token': changed ? 'current-cohort-token' : 'old-cohort-token', ...(offset === 0 && !changed ? { 'X-Next-Offset': '25' } : {}) },
  243 |         body: JSON.stringify(payload.items),
  244 |       })
  245 |       return
  246 |     }
  247 |     const body = url.pathname === '/api/auth/session'
  248 |       ? { authenticated: true }
  249 |       : url.pathname === '/api/health'
  250 |         ? { sources: [], backlog: 0, pending_interpretations: 0 }
  251 |         : []
  252 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  253 |   })
  254 |   await page.goto('/?tier=Signals')
  255 |   const oldCard = page.getByRole('button', { name: /Old cohort construction filing/ })
> 256 |   await expect(oldCard).toBeVisible()
      |                         ^ Error: expect(locator).toBeVisible() failed
  257 |   await page.getByRole('button', { name: /Next/ }).click()
  258 |   const currentCard = page.getByRole('button', { name: /Current cohort construction filing/ })
  259 |   await expect(currentCard).toBeVisible()
  260 |   await expect(page.getByRole('button', { name: /Old cohort construction filing/ })).toHaveCount(0)
  261 |   expect(new URL(page.url()).searchParams.get('offset')).toBeNull()
  262 |   const opportunityRequests = requests
  263 |   const laterRequest = opportunityRequests.find((request) => request.searchParams.get('offset') === '25')
  264 |   expect(laterRequest?.searchParams.get('cohort_token')).toBe('old-cohort-token')
  265 |   const restarted = opportunityRequests.find((request, index) => index > opportunityRequests.indexOf(laterRequest!) && (request.searchParams.get('offset') ?? '0') === '0')
  266 |   expect(restarted?.searchParams.get('cohort_token')).toBeNull()
  267 | })
  268 | 
  269 | test('project title prefers a current owner over operator, applicant, and contractor claims', () => {
  270 |   const record = permit('roles', 'Facility construction', {
  271 |     abstract: 'owner_company_name: Owner Company\noperator_company_name: Operating Company\napplicant_org: Applicant Company\ncontractor_company_name: Builder Company',
  272 |   })
  273 |   expect(projectTitle(record)).toBe('Owner Company · owner')
  274 |   record.evidence[0].assessment_current = false
  275 |   expect(projectTitle(record)).not.toContain('Owner Company')
  276 | })
  277 | 
  278 | test('city permit company title shows source role and does not infer ownership', () => {
  279 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  280 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  281 |   })
  282 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  283 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  284 | 
  285 |   const houston = permit('houston-1', 'Commercial facility construction')
  286 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  287 |   houston.title_company_role = 'permit-listed owner / occupant'
  288 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  289 | })
  290 | 
  291 | test('city permit organization labels preserve the source role and role uncertainty', () => {
  292 |   const dallas = permit('dallas-1', 'Warehouse construction', {
  293 |     abstract: 'lp_business_name: TRICORE BUILDERS INC\ncontact_name: Example Person',
  294 |   })
  295 |   dallas.evidence[0].source_id = 'dallas-monthly-permits'
  296 |   expect(projectTitle(dallas)).toBe('TRICORE BUILDERS INC · LP Business Name · role unverified')
  297 | 
  298 |   const houston = permit('houston-1', 'Commercial facility construction')
  299 |   houston.title_company = '*MERICHEM TECHNOLOGIES LLC'
  300 |   houston.title_company_role = 'permit-listed owner / occupant'
  301 |   expect(projectTitle(houston)).toBe('*MERICHEM TECHNOLOGIES LLC · permit-listed owner / occupant')
  302 | })
  303 | 
  304 | test('grouped permit members use company-first titles while retaining each permit record', async ({ page }) => {
  305 |   const keeter = permit('COM-NEW-26-000129', 'New data center construction', {
  306 |     projectId: 'dallas-campus',
  307 |     abstract: 'lp_business_name: KEETER INVESTMENTS LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  308 |   })
  309 |   const merichem = permit('COM-NEW-26-000130', 'Data center electrical expansion', {
  310 |     projectId: 'dallas-campus',
  311 |     abstract: 'owner_company_name: MERICHEM TECHNOLOGIES LLC\naddress: 2444 FABENS RD, DALLAS, TX',
  312 |   })
  313 |   keeter.evidence[0].source_id = 'dallas-monthly-permits'
  314 |   merichem.evidence[0].source_id = 'dallas-monthly-permits'
  315 |   const records = [keeter, merichem]
  316 |   await page.route(apiRoute, async (route) => {
  317 |     const path = new URL(route.request().url()).pathname
  318 |     if (path === '/api/opportunities') {
  319 |       await fulfillServerOpportunityPage(route, records)
  320 |       return
  321 |     }
  322 |     const body = path === '/api/auth/session'
  323 |       ? { authenticated: true }
  324 |       : path === '/api/health'
  325 |           ? { sources: [], backlog: 0, pending_interpretations: 0 }
  326 |           : []
  327 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  328 |   })
  329 |   await page.goto('/?tier=Signals')
  330 |   await page.getByRole('button', { name: /KEETER INVESTMENTS LLC · LP Business Name · role unverified/ }).click()
  331 |   const keeterMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000129"]')
  332 |   const merichemMember = page.locator('.project-member[data-opportunity-id="COM-NEW-26-000130"]')
  333 |   await expect(keeterMember).toContainText('KEETER INVESTMENTS LLC · LP Business Name · role unverified')
  334 |   await expect(merichemMember).toContainText('MERICHEM TECHNOLOGIES LLC · owner')
  335 |   await keeterMember.click()
  336 |   await expect(page.getByRole('heading', { level: 1, name: 'KEETER INVESTMENTS LLC · LP Business Name · role unverified' })).toBeVisible()
  337 |   await expect(page.getByText('COM-NEW-26-000129', { exact: false }).first()).toBeVisible()
  338 | })
  339 | 
  340 | test('Signals default to All and keep SHOW, REVIEW, and HOLD selectable', async ({ page }) => {
  341 |   let records = [
  342 |     permit('hold-member', 'Routine hospital maintenance', { projectId: 'shared-project', decision: 'HOLD' }),
  343 |     permit('show-member', 'New data center electrical buildout', { projectId: 'shared-project', decision: 'SHOW' }),
  344 |     permit('review', 'Possible industrial expansion', { projectId: 'review-project', decision: 'REVIEW' }),
  345 |     permit('hold', 'Marathon temporary stage', { projectId: 'hold-project', decision: 'HOLD' }),
  346 |     permit('unknown', 'Unadjudicated project', { projectId: 'unknown-project', decision: null }),
  347 |   ]
  348 |   await page.route(apiRoute, async (route) => {
  349 |     const path = new URL(route.request().url()).pathname
  350 |     if (path === '/api/opportunities') {
  351 |       await fulfillServerOpportunityPage(route, records)
  352 |       return
  353 |     }
  354 |     const body = path === '/api/auth/session' ? { authenticated: true } : path === '/api/health' ? { sources: [], backlog: 0, pending_interpretations: 0 } : []
  355 |     await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) })
  356 |   })
```