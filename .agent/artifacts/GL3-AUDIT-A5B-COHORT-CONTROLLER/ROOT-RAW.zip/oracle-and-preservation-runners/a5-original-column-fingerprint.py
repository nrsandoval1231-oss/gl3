import hashlib
import json
from pathlib import Path
import sys
import psycopg
from psycopg import sql

output = Path(sys.argv[1])
if output.exists():
    raise RuntimeError("Refusing overwrite")
baseline = json.loads(Path(sys.argv[2]).read_text()) if len(sys.argv) > 2 else None
tables = {}
with psycopg.connect("host=127.0.0.1 port=55437 user=gl3audit dbname=gl3audit_a5_corpus_test") as conn:
    conn.execute("SET TRANSACTION READ ONLY")
    names = list(baseline["tables"]) if baseline else [row[0] for row in conn.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")]
    for name in names:
        columns = baseline["tables"][name]["columns"] if baseline else [row[0] for row in conn.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s ORDER BY ordinal_position", (name,))]
        query = sql.SQL("SELECT row_to_json(t)::text FROM (SELECT {} FROM {}) t ORDER BY row_to_json(t)::text").format(sql.SQL(",").join(map(sql.Identifier, columns)), sql.Identifier(name))
        digest = hashlib.sha256()
        count = 0
        for (value,) in conn.execute(query):
            digest.update(value.encode())
            digest.update(b"\n")
            count += 1
        tables[name] = {"columns": columns, "rows": count, "sha256": digest.hexdigest()}
    conn.rollback()
differences = [name for name, value in tables.items() if baseline and value != baseline["tables"][name]]
report = {"database": "gl3audit_a5_corpus_test", "scope": "Original-column row fingerprints; readonly copy", "tables": tables, "differences": differences, "alembic_metadata_expected_to_change": bool(baseline)}
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"tables": len(tables), "differences": differences}))
