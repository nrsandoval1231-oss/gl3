# A5B independent development checkpoint — October 8, 2026

Unfrozen candidate: gl3-public-browse-20261008, base fb65ceb. This is intermediate evidence, not acceptance or coverage of a later frozen candidate.

Root offline helper comparator folded every frozen retained Evidence row, then compared actual frozen TypeScript oracle: 1,167 records / 1,149 groups; exact group keys/member order, all record titles and group decisions PASS. Guarded raw root-offline-helper-parity-path-repair-20261008T1529490226576Z-fdf3ab081f2d457091448beb768fdc2c-python.log. Earlier relative-path invocation exit2 is retained; absolute-path repair succeeded. No providers or data writes.

Root streamed comparator opened only gl3audit_a5_corpus_test under REPEATABLE READ, READ ONLY, with project_state.date fixed to 2026-10-07. Exact groups/member order, decisions and all 17 matched-record/group search queries PASS. All-record title parity FAIL for only 81a3ec21-a9b2-4fe0-9dc5-92c795864114 and f54e0708-d8e4-4337-bb23-d0f640f7110c. First raw root-streamed-retained-parity-development-20261008T1533086338931Z-9b7dd0aa5c6d4dfdb04ae3525c10828f-python.log; ID-only diagnostic root-streamed-title-mismatch-ids-20261008T1533437882665Z-f8ae8359ce374f3cb4ab4952294903b9-python.log. Corpus text is not emitted or admitted to Git evidence archives. Full route/filter/page/CSV/client/performance/frozen gates remain pending. Luna received a bounded title-parity repair; no unchanged failing comparator reruns.

Direction CORRECT remaining title parity and finish client/history contract; then freeze, root validate and independent Sol review. Workflow status stays UNKNOWN-only in this slice and partial until the prepared A6 workflow-status amendment and subsequent bulk A5 integration are accepted.

## Independent development repair and final-DB preparation

After the bounded Houston owner/occupant batch attribution repair, root streamed retained comparison PASS: root-streamed-retained-title-repair-20261008T1540287639712Z-cdbfc2977db044618cf25a80931c9bb5-python.log,1167records/1149groups, all titles/group member order/decisions/17 search queries,151SQL over the entire multi-query diagnostic,6.334815s. This is an unfrozen development comparator, not a public-page benchmark or final acceptance. Earlier two-title FAIL remains retained.

Root verified gl3audit_a5b_final_migration absent from pg_database, created it without reset, verified public base tables0. Candidate migrations unchanged from acceptedfb65. Database remains EMPTY pending frozen fresh-migration proof; it is exclusively root-owned, distinct from builder test/migration DBs and retained corpus. Terminal tools returned exit0 for catalog/create/zero-table checks. No original-data writes, provider calls or deployment.
