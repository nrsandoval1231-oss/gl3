# A5B independent FIX — October 8, 2026

Exact candidate f15deee344cd3f161169412e0ee62cd329225f60 / tree 44c958cb9125e2266ff398654553cc1bd652832a is NOT accepted. Raw independent Sol verdict FIX: .artifacts/audit-20261007/a5b-independent-review.json, SHA256 47f09fd59f40136ae2f5cafa3c1a71e68ba08d1d75c69dbd60b60ccb4178f800. Audit UTC 17:05:17–17:07:20.2099521, 123.21 seconds; raw declared model gpt-6.1-sol; configuration/tokens UNKNOWN.

Subsequent public opportunity offsets accept absent cohort_token; direct nonzero-offset URL reload requests precisely that unbound page. This violates the existing first-page cohort contract and permits changed-cohort omissions/duplicates. Root deterministic gates passed but did not cover this invariant. Preserve all original source/proof bytes and the negative outcome.

Direction CORRECT: a new narrow integration packet must require a nonempty token for subsequent offsets, validate stale tokens, and safely bootstrap or explicitly restart URL/Back restoration. Add reproducing backend and browser coverage. This is a distinct independent-review finding after earlier compatibility and batching repairs, not permission to repeat an unchanged failed approach or expand scope. Sol controller is preparing bounded ownership; one Luna implements, root validates, independent Sol reviews the new frozen candidate.

A6 remains dependent on accepted A5B. No publication, parent completion, merge, deployment, paid activation, external messages or application-data mutation. No elapsed-to-accepted or speedup claim.
