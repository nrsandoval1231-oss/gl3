import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
results = []
bad = []
for name in ("GL3-AUDIT-A5B/RAW_LOGS.json", "GL3-AUDIT-A5B/R1-RAW_LOGS.json", "GL3-AUDIT-A5B-R2/RAW_LOGS.json"):
    manifest = root / ".agent/artifacts" / name
    entries = json.loads(manifest.read_text())["logs"]
    results.append({"manifest": name, "entries": len(entries)})
    for entry in entries:
        relative = entry["path"]
        path = root / (relative if relative.startswith(".artifacts/") else ".artifacts/" + relative)
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest().lower() != entry["sha256"].lower():
            bad.append(relative)
print(json.dumps({"manifests": results, "differences": bad}))
assert not bad
