param([Parameter(Mandatory=$true)][string]$Candidate,[Parameter(Mandatory=$true)][string]$Label,[Parameter(Mandatory=$true)][string]$Database,[Parameter(Mandatory=$true)][int]$ApiPort,[Parameter(Mandatory=$true)][int]$WebPort)
$ErrorActionPreference='Stop'
$env:PATH='C:/Users/nrsan/AppData/Local/hermes/bin;'+$env:PATH
$env:DATABASE_URL="postgresql+psycopg://gl3audit@127.0.0.1:55437/$Database"
$env:TEST_DATABASE_URL=$env:DATABASE_URL
$env:FIRECRAWL_API_KEY='';$env:OPENAI_API_KEY='';$env:TYPESAFE_API_KEY=''
$env:WORKER_AUTO_REFRESH='false';$env:AUTONOMOUS_RESEARCH_ENABLED='false'
$env:GRIDLENS_API_PORT=[string]$ApiPort;$env:GRIDLENS_WEB_PORT=[string]$WebPort
$env:VITE_API_PROXY_TARGET="http://127.0.0.1:$ApiPort"
$env:TRUSTED_ORIGINS="http://127.0.0.1:$WebPort"
$env:COOKIE_SECURE='false';$env:CI='1'
Get-Content 'C:/Users/nrsan/Nucleus/02_Projects/GridLens/gl3-audit-repair-20261007/.env' | ForEach-Object {if($_ -match '^(APP_PASSWORD_HASH|SESSION_SECRET)=(.*)$'){[Environment]::SetEnvironmentVariable($Matches[1],$Matches[2],'Process')}}
$env:GRIDLENS_TEST_PASSWORD=(Get-Content 'C:/Users/nrsan/Nucleus/02_Projects/GridLens/gl3-audit-repair-20261007/.artifacts/local-auth.txt')[1]
$taskLog=Join-Path $Candidate ".artifacts/$Label-browser.log"
if(Test-Path -LiteralPath $taskLog){throw 'Refusing overwrite'}
Set-Location (Join-Path $Candidate 'web')
$taskTraceDir=Join-Path $Candidate ".artifacts/$Label-browser-results"
if(Test-Path -LiteralPath $taskTraceDir){throw 'Refusing browser results overwrite'}
& npm.cmd exec playwright test -- --project=regression --output=$taskTraceDir *> $taskLog
$taskExit=$LASTEXITCODE
Get-Content -LiteralPath $taskLog -Tail 12
exit $taskExit

