import gzip
import json
from pathlib import Path

path = Path(
    r"C:\Users\nrsan\Nucleus\02_Projects\GridLens\gl3-audit-repair-20261007"
    r"\.artifacts\audit-20261007\root-a5b-frozen-client-oracle\oracle.json.gz"
)
with gzip.open(path, "rt", encoding="utf-8") as stream:
    value = json.load(stream)
print("dict", sorted(value.keys()))
for key in ("titles", "groups", "queries"):
    child = value.get(key)
    if isinstance(child, dict):
        print(key, "dict", len(child), "keys", list(child.keys())[:3])
    elif isinstance(child, list):
        print(key, "list", len(child), "item", sorted(child[0].keys()) if child and isinstance(child[0], dict) else None)
