import hashlib,json,os,pathlib
root=pathlib.Path(r'C:\Users\nrsan\Nucleus\02_Projects\GridLens\gl3-public-browse-20261008')
parent=pathlib.Path(r'C:\Users\nrsan\Nucleus\02_Projects\GridLens\gl3-audit-repair-20261007')
known=[os.environ.get(n,'') for n in ('FIRECRAWL_API_KEY','OPENAI_API_KEY','TYPESAFE_API_KEY')]
for line in (parent/'.env').read_text().splitlines():
    if line.startswith(('APP_PASSWORD_HASH=','SESSION_SECRET=')): known.append(line.split('=',1)[1])
auth=(parent/'.artifacts/local-auth.txt').read_text().splitlines()
if len(auth)>1: known.append(auth[1])
needles=set()
for value in known:
    if len(value)>=12:
        needles.add(value.encode())
        if len(value)>=40: needles.update((value[:24].encode(),value[-24:].encode()))
paths=[]
for directory in (root/'backend/src',root/'backend/tests',root/'web/src',root/'.artifacts'):
    for path in directory.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix not in ('.pyc','.zip','.gz') and path.stat().st_size<10_000_000: paths.append(path)
hits=[str(p.relative_to(root)) for p in paths if any(n in p.read_bytes() for n in needles)]
result={'scope':'working source/test/client files and local diagnostic files; tool history excluded','files_scanned':len(paths),'known_secret_match_files':hits,'original_incident_tool_output_bytes':'UNKNOWN'}
out=root/'.artifacts/root-a5b-bootstrap-file-secret-scan.json'
with out.open('x') as f: json.dump(result,f,indent=2)
print(json.dumps(result))
raise SystemExit(bool(hits))
