import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])
assert git("rev-parse", "HEAD").decode().strip() == "d5f950c677b830f0a1b3fba8dbe3d9213191cddc"
before = root / ".artifacts/a5b-controller-before"
before.mkdir(exist_ok=False)
for name in ("CURRENT_STATE.md", "WORK_GRAPH.md"):
    (before / (name + ".bin")).write_bytes((root / ".agent" / name).read_bytes())
paths = git("ls-files", "backend/src", "backend/tests", "backend/migrations", "backend/scripts", "backend/uv.lock", "backend/pyproject.toml", "web/src", "web/tests", "web/package.json", "web/package-lock.json", ".github/workflows", "scripts").decode().splitlines()
entries = []
for path in paths:
    file = root / path
    blob = git("show", f"HEAD:{path}")
    entries.append({"path": path, "working_sha256": hashlib.sha256(file.read_bytes()).hexdigest(), "git_content_sha256": hashlib.sha256(blob).hexdigest(), "git_blob_oid": git("rev-parse", f"HEAD:{path}").decode().strip()})
output = root / ".agent/artifacts/GL3-AUDIT-A5B-CONTROLLER"
output.mkdir(exist_ok=True)
with (output / "TESTED-SOURCE-MANIFEST.json").open("x") as target:
    json.dump({"tested_head": "d5f950c677b830f0a1b3fba8dbe3d9213191cddc", "scope": "Product/test/migration/workflow/dependency bytes; working and Git hashes distinguish line endings", "entries": entries}, target, indent=2)
print(json.dumps({"source_entries": len(entries), "prior_controller_files": 2}))
