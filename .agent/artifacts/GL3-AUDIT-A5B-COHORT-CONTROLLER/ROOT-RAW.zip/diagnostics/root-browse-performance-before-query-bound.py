"""Read-only matched card/public-page measurement; stdout has receipts, no corpus payload."""
import hashlib
import importlib
import json
import os
import sys
import time
import tracemalloc
from datetime import date
from fastapi import Response
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker

assert all(not os.environ.get(k) for k in ("FIRECRAWL_API_KEY", "OPENAI_API_KEY", "TYPESAFE_API_KEY"))
mode = sys.argv[1]
assert mode in {"commercial", "public"}
app = importlib.import_module("gridlens.api.app")
state = importlib.import_module("gridlens.intelligence.project_state")
class FrozenDate(date):
    @classmethod
    def today(cls):
        return cls(2026, 10, 7)
state.date = FrozenDate
app.chicago_today = lambda now=None: date(2026, 10, 7)
engine = create_engine("postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a5_corpus_test", connect_args={"options": "-c default_transaction_read_only=on"})
app.SessionLocal = sessionmaker(bind=engine)
sql = 0
@event.listens_for(engine, "before_cursor_execute")
def count(*args):
    global sql
    sql += 1
receipts = []
for label in ("first_in_process", "warm_same_process"):
    before = sql
    tracemalloc.start()
    started = time.perf_counter()
    if mode == "commercial":
        with Session(engine) as session:
            cards = app._commercial_triage_cards(session, 50)
            session.rollback()
    else:
        response = Response()
        cards = app.opportunities(response=response)
    elapsed = time.perf_counter() - started
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    payload = json.dumps(cards, default=str, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(payload).hexdigest()
    if mode == "commercial":
        assert digest == "4d44821139abdd92a657aa7f419f86754abb33be0e1e0d5082278dee0bed4812", "Canonical commercial card parity changed"
    receipts.append({"run": label, "returned_items": len(cards), "query_count": sql - before, "latency_seconds": elapsed, "peak_python_bytes": peak, "serialized_handler_bytes": len(payload), "serialized_handler_sha256": digest})
engine.dispose()
print(json.dumps({"mode": mode, "database": "gl3audit_a5_corpus_test", "date": "2026-10-07", "measurements": receipts, "scope": "Read-only retained clone, first process not database/disk cache eviction; Python allocation not RSS; no production SLO", "provider_calls": 0, "original_data_writes": 0}))
