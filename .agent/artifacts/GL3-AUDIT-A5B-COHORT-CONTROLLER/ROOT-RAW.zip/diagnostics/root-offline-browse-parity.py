"""Read-only frozen client oracle comparator; no settings, database, or provider import."""
import copy
import gzip
import hashlib
import json
import runpy
from pathlib import Path

candidate = Path(__file__).resolve().parents[1]
parent = candidate.parent / "gl3-audit-repair-20261007"
archive = parent / ".artifacts/audit-20261007"
helpers = runpy.run_path(str(candidate / "backend/src/gridlens/intelligence/opportunity_browse.py"))
raw = gzip.decompress((archive / "a5-accepted-oracle/semantic-oracle.json.gz").read_bytes())
assert hashlib.sha256(raw).hexdigest() == "85e3d525b199bcb42f65e8fd6e10cf0e2be08bd9673e3a6cb23930a8b6352bab"
rows = copy.deepcopy(json.loads(raw)["rows"])
oracle = json.loads(gzip.decompress((archive / "root-a5b-frozen-client-oracle/oracle.json.gz").read_bytes()))
decision = json.loads(gzip.decompress((archive / "root-a5b-frozen-client-oracle/decision-oracle.json.gz").read_bytes()))
for row in rows:
    for evidence in row.get("evidence", []):
        helpers["add_browse_evidence"](row, evidence)
groups = helpers["grouped_opportunities"](rows)
failures = []
def compare(label, actual, expected):
    if actual != expected:
        failures.append({"check": label, "actual_sha256": hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest(), "expected_sha256": hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest()})
compare("group_keys_members_order", [{"key": key, "ids": [r["id"] for r in members]} for key, members in groups], [{"key": g["key"], "ids": g["ids"]} for g in oracle["groups"]])
compare("all_record_titles", [{"id": r["id"], "title": helpers["project_title"](r)} for r in rows], oracle["titles"])
compare("all_group_decisions", [{"key": key, "decision": helpers["grouped_signal_decision"](members)} for key, members in groups], decision["group_decisions"])
print(json.dumps({"scope": "Offline folded helper parity only; streamed database matcher and routes require separate validation", "rows": len(rows), "groups": len(groups), "failures": failures, "provider_calls": 0}))
raise SystemExit(bool(failures))
