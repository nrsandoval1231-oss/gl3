"""Seal exact raw diagnostic bytes; exclude private configuration and corpus payloads."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parent = root.parent / "gl3-audit-repair-20261007"
head = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
assert head == sys.argv[1]
output = root / ".agent/artifacts/GL3-AUDIT-A5B-COHORT-CONTROLLER"
output.mkdir(parents=True, exist_ok=True)
archive_path = output / "ROOT-RAW.zip"
manifest_path = output / "RAW-HASH-MANIFEST.json"
if archive_path.exists() or manifest_path.exists():
    raise RuntimeError("Refusing archive overwrite")
inputs = {}
inputs["tested-source-manifest.json"] = output / "TESTED-SOURCE-MANIFEST.json"
for path in (root / ".artifacts").iterdir():
    if path.is_file() and path.suffix in {".log", ".py", ".ps1", ".json", ".txt"}:
        inputs["diagnostics/" + path.name] = path
for path in (root / ".artifacts/a5b-cohort-controller-before").glob("*"):
    if path.is_file():
        inputs["prior-controller-bytes/" + path.name] = path
for directory in (root / ".artifacts").iterdir():
    if directory.is_dir() and (directory.name.startswith("a5b-cohort-browser-") or directory.name == "root-cohort-final-browser-results"):
        for path in directory.rglob("*"):
            if path.is_file():
                inputs["native-browser/" + str(path.relative_to(root / ".artifacts")).replace("\\", "/")] = path
for name in ("GL3-AUDIT-A5B-INDEPENDENT-FIX-20261008.md", "GL3-AUDIT-A6-PREBUILD-DIRECTION-20261008.md"):
    inputs["controller-directions/" + name] = parent / ".agent/graphs" / name
inputs["controller-packets/GL3-AUDIT-A5B-COHORT-REVIEW-REPAIR.md"] = parent / ".agent/packets/GL3-AUDIT-A5B-COHORT-REVIEW-REPAIR.md"
inputs["independent-review/f15deee-FIX.json"] = parent / ".artifacts/audit-20261007/a5b-independent-review.json"
names = [
    "GL3-AUDIT-A5B-DEVELOPMENT-PARITY-20261008.md",
    "GL3-AUDIT-A5B-FROZEN-VALIDATION-PLAN-20261008.md",
    "GL3-AUDIT-A5B-R1-CONTROLLER-CHECKPOINT-20261008.md",
    "GL3-AUDIT-A5B-BROWSER-R2-DIRECTION.md",
    "GL3-AUDIT-A5B-BOOTSTRAP-INCIDENT-20261008.md",
    "GL3-AUDIT-A5B-DISPOSABLE-BOOTSTRAP-20261008.md",
]
for name in names:
    path = parent / ".agent/graphs" / name
    assert path.is_file(), name
    inputs["controller-directions/" + name] = path
for name in ("GL3-AUDIT-A5B-FILTER-CONTRACT.md", "GL3-AUDIT-A6-UI.md", "GL3-AUDIT-A6-WORKFLOW-STATUS.md", "GL3-AUDIT-A8A-CONFIG-DIAGNOSTICS.md"):
    path = parent / ".agent/packets" / name
    assert path.is_file(), name
    inputs["controller-packets/" + name] = path
oracle = parent / ".artifacts/audit-20261007/root-a5b-frozen-client-oracle"
for name in ("receipt.json", "decision-receipt.json", "normalization-cases.json"):
    inputs["frozen-oracle-receipts/" + name] = oracle / name
for name in ("root-a5b-frozen-client-oracle.mjs", "root-a5b-frozen-decision-oracle.mjs", "root-a5b-normalization-oracle.mjs", "a5-original-column-fingerprint.py"):
    inputs["oracle-and-preservation-runners/" + name] = parent / ".artifacts/audit-20261007" / name
entries = []
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(inputs.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        entries.append({"entry": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "source": str(path)})
with zipfile.ZipFile(archive_path) as archive:
    for entry in entries:
        assert hashlib.sha256(archive.read(entry["entry"])).hexdigest() == entry["sha256"]
report = {"tested_head": head, "archive": "ROOT-RAW.zip", "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(), "entries": entries, "scope": "Exact raw bytes, including retained red attempts; metadata/runners only for private frozen corpus oracles; no corpus payloads or private configuration", "limitations": ["Unretained bootstrap/path diagnostics explicitly UNKNOWN", "Earlier default-directory native browser traces UNKNOWN; complete text logs retained", "Some development runner versions changed; final reproducible runner bytes sealed, performance pre-budget runner retained separately", "No independent acceptance claimed"]}
with manifest_path.open("x") as target:
    json.dump(report, target, indent=2)
print(json.dumps({"tested_head": head, "archive_sha256": report["archive_sha256"], "entries": len(entries)}))

