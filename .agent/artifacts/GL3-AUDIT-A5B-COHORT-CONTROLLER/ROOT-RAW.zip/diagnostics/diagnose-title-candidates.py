import gzip
import hashlib
import json
from datetime import date

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from gridlens.api import app as api_module
from gridlens.intelligence import project_state


class FrozenDate(date):
    @classmethod
    def today(cls):
        return cls(2026, 10, 7)


project_state.date = FrozenDate
ids = {
    "81a3ec21-a9b2-4fe0-9dc5-92c795864114",
    "f54e0708-d8e4-4337-bb23-d0f640f7110c",
}
oracle_path = r"C:\Users\nrsan\Nucleus\02_Projects\GridLens\gl3-audit-repair-20261007\.artifacts\audit-20261007\root-a5b-frozen-client-oracle\oracle.json.gz"
with gzip.open(oracle_path, "rt", encoding="utf-8") as stream:
    oracle = json.load(stream)
expected = {row["id"]: row["title"] for row in oracle["titles"] if row["id"] in ids}
engine = create_engine(
    "postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a5_corpus_test",
    connect_args={"options": "-c default_transaction_read_only=on"},
)
api = api_module
with Session(engine, expire_on_commit=False) as session:
    assert session.scalar(text("SHOW transaction_read_only")) == "on"
    api._begin_consistent_read(session)
    summaries = api.opportunity_projection(session, summary_only=True)
    selected = [row for row in summaries if str(row["id"]) in ids]
    api._opportunity_evidence_search_matches(session, selected, None)
    details_by_id = {
        str(row["id"]): row
        for row in api.opportunity_projection(
            session, selected_need_ids={row["id"] for row in selected}
        )
    }
    for summary in selected:
        key = str(summary["id"])
        detail = details_by_id[key]
        summary_title = api.opportunity_project_title(summary)
        detail_title = api.opportunity_project_title(detail)
        title_with_detail_company = api.opportunity_project_title(
            {
                **summary,
                "title_company": detail.get("title_company"),
                "title_company_role": detail.get("title_company_role"),
            }
        )
        expected_title = expected[key]
        source_ids = sorted({row.get("source_id", "") for row in detail.get("evidence", [])})
        print(
            json.dumps(
                {
                    "id": key,
                    "summary_matches_frozen": summary_title == expected_title,
                    "detail_matches_frozen": detail_title == expected_title,
                    "company_metadata_repairs_summary": title_with_detail_company == expected_title,
                    "summary_company_metadata_present": bool(summary.get("title_company")),
                    "detail_company_metadata_present": bool(detail.get("title_company")),
                    "source_ids": source_ids,
                    "summary_evidence_count": len(summary.get("_browse_action_candidates", [])),
                    "summary_action_candidate_count": len(summary.get("_browse_action_candidates", [])),
                    "expected_title_sha256": hashlib.sha256(expected_title.encode()).hexdigest(),
                    "summary_title_sha256": hashlib.sha256(summary_title.encode()).hexdigest(),
                    "detail_title_sha256": hashlib.sha256(detail_title.encode()).hexdigest(),
                },
                sort_keys=True,
            )
        )
