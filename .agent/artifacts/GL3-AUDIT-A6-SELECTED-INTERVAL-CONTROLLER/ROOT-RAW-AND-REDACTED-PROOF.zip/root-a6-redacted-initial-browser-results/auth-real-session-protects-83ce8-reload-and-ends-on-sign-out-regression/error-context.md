# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.spec.ts >> real session protects the workspace, survives reload, and ends on sign-out
- Location: tests\auth.spec.ts:8:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Signals', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Signals', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Signals', exact: true })

```

```yaml
- main:
  - img "GridLens"
  - heading "Sign in" [level=1]
  - paragraph: Your private GridLens workspace.
  - text: Password
  - textbox "Password": [REDACTED_PRIVATE_TEST_VALUE]
  - button "Continue"
  - alert: GridLens could not complete this request (500).
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { existsSync, readFileSync } from 'node:fs'
  3  | import { resolve } from 'node:path'
  4  | 
  5  | const credentialPath = resolve(process.cwd(), '../.artifacts/local-auth.txt')
  6  | const password = process.env.GRIDLENS_TEST_PASSWORD ?? (existsSync(credentialPath) ? readFileSync(credentialPath, 'utf8').split(/\r?\n/)[1] : undefined)
  7  | 
  8  | test('real session protects the workspace, survives reload, and ends on sign-out', async ({ page }) => {
  9  |   if (!password) throw new Error('Set GRIDLENS_TEST_PASSWORD to the password for the disposable test API')
  10 | 
  11 |   expect((await page.request.get('/api/health')).status()).toBe(401)
  12 |   await page.goto('/?tier=Signals')
  13 |   await expect(page.getByRole('heading', { name: 'Sign in', exact: true })).toBeVisible()
  14 |   await page.getByLabel('Password').fill(password)
  15 |   await page.getByRole('button', { name: 'Continue', exact: true }).click()
> 16 |   await expect(page.getByRole('heading', { name: 'Signals', exact: true })).toBeVisible()
     |                                                                             ^ Error: expect(locator).toBeVisible() failed
  17 |   expect((await page.request.get('/api/health')).status()).toBe(200)
  18 | 
  19 |   await page.reload()
  20 |   await expect(page.getByRole('heading', { name: 'Signals', exact: true })).toBeVisible()
  21 |   await page.getByRole('button', { name: 'Sign out', exact: true }).click()
  22 |   await expect(page.getByRole('heading', { name: 'Sign in', exact: true })).toBeVisible()
  23 |   expect((await page.request.get('/api/health')).status()).toBe(401)
  24 |   expect(await (await page.request.get('/api/auth/session')).json()).toEqual({ authenticated: false })
  25 | })
  26 | 
```