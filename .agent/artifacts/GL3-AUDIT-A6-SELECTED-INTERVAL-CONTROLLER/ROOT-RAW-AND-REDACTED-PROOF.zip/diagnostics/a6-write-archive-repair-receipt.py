import hashlib, json, subprocess
from pathlib import Path
root = Path.cwd()
repair_dir = Path(".agent/artifacts/GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR")
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
tree = subprocess.check_output(["git", "show", "-s", "--format=%T", commit], text=True).strip()
paths = [
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/CURRENT_STATE.md.before-compact.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/CURRENT_STATE.md.prior.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/WORK_GRAPH.md.before-compact.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/WORK_GRAPH.md.prior.bin",
]
original = json.loads((repair_dir / "ROOT-EVIDENCE/root-a6-archive-bin-identity.json").read_text(encoding="utf-8"))
by_path = {item["path"]: item for item in original}
archives=[]
for path in paths:
    working = Path(path).read_bytes()
    git_data = subprocess.check_output(["git", "cat-file", "blob", f"{commit}:{path}"])
    oid = subprocess.check_output(["git", "rev-parse", f"{commit}:{path}"], text=True).strip()
    working_sha = hashlib.sha256(working).hexdigest()
    old = by_path[path]
    archives.append({
        "path": path,
        "original_working_sha256_from_root": old["working_sha256"],
        "pre_repair_head_blob_sha256": old["git_sha256"],
        "pre_repair_working_sha256_unchanged": working_sha == old["working_sha256"],
        "working_bytes": len(working),
        "working_sha256_after": working_sha,
        "repair_commit_blob_oid": oid,
        "repair_commit_blob_bytes": len(git_data),
        "repair_commit_blob_sha256": hashlib.sha256(git_data).hexdigest(),
        "working_equals_committed_blob": working == git_data,
    })
source_paths = subprocess.check_output(["git", "diff", "--name-only", "209caeb1551afa3dbda2650cd8fa64e93f68de2b", commit, "--", "backend/src", "backend/tests", "backend/migrations", "web/src/api"], text=True).splitlines()
packet = Path(".agent/artifacts/GL3-AUDIT-A6-DISPATCH/ARCHIVE-BYTE-REPAIR-PACKET.md")
root_copies=[]
for name in ["root-a6-builder-diff-check.log", "root-a6-archive-bin-identity.json"]:
    source = Path(".artifacts") / name
    copy = repair_dir / "ROOT-EVIDENCE" / name
    a,b=source.read_bytes(),copy.read_bytes()
    root_copies.append({"source": source.as_posix(), "copy": copy.as_posix(), "bytes": len(a), "source_sha256": hashlib.sha256(a).hexdigest(), "copy_sha256": hashlib.sha256(b).hexdigest(), "identical": a==b})
check_path=Path(".artifacts/a6-archive-binary-repair-diffcheck-20261008T203900Z.log")
manifest=json.loads((repair_dir/"PRE-REPAIR-PRESERVATION.json").read_text(encoding="utf-8"))
receipt={
  "schema":"codex-task-completion/v1",
  "packet_id":"GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR",
  "status":"FROZEN_FOR_ROOT_VALIDATION",
  "acceptance_claim":False,
  "repair_commit":{"commit":commit,"tree":tree,"branch":subprocess.check_output(["git","branch","--show-current"],text=True).strip()},
  "product_source_anchor":{"commit":"209caeb1551afa3dbda2650cd8fa64e93f68de2b","tree":"a567e9e2ed71ee65b3644de0d383ee205ba282bb"},
  "source_scope_unchanged":source_paths==[],
  "source_paths_changed_since_product_anchor":source_paths,
  "attribute_rule":".agent/artifacts/GL3-AUDIT-A6-DISPATCH/*.bin -text -diff",
  "archive_blobs":archives,
  "all_four_working_bytes_preserved":all(x["pre_repair_working_sha256_unchanged"] for x in archives),
  "all_four_committed_blobs_equal_working_bytes":all(x["working_equals_committed_blob"] for x in archives),
  "pre_repair_normalized_blobs_archive":{
    "path":manifest["archive"],"sha256":manifest["archive_sha256"],"entry_count":len(manifest["entries"]),"entries":manifest["entries"]
  },
  "root_failure_evidence":root_copies,
  "validation":{"command":"git diff --check HEAD^ HEAD","exit_code":0,"raw_log":check_path.as_posix(),"bytes":check_path.stat().st_size,"sha256":hashlib.sha256(check_path.read_bytes()).hexdigest(),"classification":"Archived .bin files are binary; no source changes were made and whitespace check passed."},
  "product_tests_repeated":False,
  "reason":"Artifact-only repair; root owns full/frozen validation and independent review.",
  "safety":{"provider_calls":0,"original_data_mutations":0,"push_merge_deploy":False},
  "artifact_metadata_commit":"reported in terminal handoff to avoid recursive self-hashing"
}
if not receipt["all_four_working_bytes_preserved"] or not receipt["all_four_committed_blobs_equal_working_bytes"] or source_paths or not all(x["identical"] for x in root_copies):
    raise SystemExit("Archive repair verification failed; receipt not written")
(repair_dir/"COMPLETION.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
