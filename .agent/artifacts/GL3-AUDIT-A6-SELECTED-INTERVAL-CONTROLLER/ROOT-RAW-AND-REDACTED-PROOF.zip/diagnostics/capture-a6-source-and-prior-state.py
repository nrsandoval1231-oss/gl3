import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
expected = sys.argv[1]
def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])
assert git("rev-parse", "HEAD").decode().strip() == expected
assert not git("status", "--porcelain").strip()
before = root / ".artifacts/root-a6-controller-before"
before.mkdir(exist_ok=False)
for name in ("CURRENT_STATE.md", "WORK_GRAPH.md"):
    (before / (name + ".bin")).write_bytes((root / ".agent" / name).read_bytes())
paths = git("ls-files", "backend/src", "backend/tests", "backend/migrations", "backend/scripts", "backend/uv.lock", "backend/pyproject.toml", "web/src", "web/tests", "web/package.json", "web/package-lock.json", ".github/workflows", "scripts", ".gitattributes", "AGENTS.md", ".agent/AGENT_RULES.md", "docs/PRD.md", "backend/.python-version", "web/tsconfig.json", "web/tsconfig.app.json", "web/tsconfig.node.json", "web/vite.config.ts").decode().splitlines()
entries = []
for path in paths:
    blob = git("show", f"HEAD:{path}")
    entries.append({"path": path, "working_sha256": hashlib.sha256((root/path).read_bytes()).hexdigest(), "git_content_sha256": hashlib.sha256(blob).hexdigest(), "git_blob_oid": git("rev-parse", f"HEAD:{path}").decode().strip()})
output = root / ".agent/artifacts/GL3-AUDIT-A6-CONTROLLER"
output.mkdir(exist_ok=False)
with (output / "TESTED-SOURCE-MANIFEST.json").open("x") as target:
    json.dump({"tested_head": expected, "scope": "Product/test/migration/workflow/dependency exact working and Git bytes", "entries": entries}, target, indent=2)
print(json.dumps({"tested_head": expected, "source_entries": len(entries)}))


