"""Preserve private original traces; create separately attributed review copies."""
import hashlib
import io
import json
import os
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parent = root.parent / 'gl3-audit-repair-20261007'
known = [os.environ.get(k, '') for k in ('FIRECRAWL_API_KEY', 'OPENAI_API_KEY', 'TYPESAFE_API_KEY')]
for line in (parent / '.env').read_text().splitlines():
    if line.startswith(('APP_PASSWORD_HASH=', 'SESSION_SECRET=')):
        known.append(line.split('=', 1)[1])
known.append((parent / '.artifacts/local-auth.txt').read_text().splitlines()[1])
patterns = set()
for value in known:
    if not value:
        continue
    forms = (value, json.dumps(value)[1:-1])
    for form in forms:
        for encoding in ('utf-8', 'utf-16-le', 'utf-16-be'):
            patterns.add(form.encode(encoding))
        if len(form) >= 24:
            patterns.update(form[i:i+24].encode() for i in range(len(form)-23))

def redact(data):
    for pattern in sorted(patterns, key=len, reverse=True):
        data = data.replace(pattern, b'[REDACTED_PRIVATE_TEST_VALUE]')
    return data

source = root / '.artifacts/root-a6-final-browser-results'
target = root / '.artifacts/root-a6-redacted-initial-browser-results'
target.mkdir(exist_ok=False)
prefix = '\\\\?\\' if os.name == 'nt' else ''
records = []
for path in Path(prefix + str(source.absolute())).rglob('*'):
    if not path.is_file():
        continue
    relative = path.relative_to(Path(prefix + str(source.absolute())))
    original = path.read_bytes()
    if path.suffix == '.zip':
        output = io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(original)) as old, zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as new:
            for entry in old.infolist():
                if not entry.is_dir():
                    new.writestr(entry.filename, redact(old.read(entry)))
        cleaned = output.getvalue()
    else:
        cleaned = redact(original)
    destination = Path(prefix + str((target / relative).absolute()))
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(cleaned)
    records.append({'path': str(relative), 'private_original_sha256': hashlib.sha256(original).hexdigest(), 'review_copy_sha256': hashlib.sha256(cleaned).hexdigest(), 'changed': original != cleaned})
with (root / '.artifacts/root-a6-browser-redaction-manifest.json').open('x') as stream:
    json.dump({'scope': 'Private originals retained locally unchanged; review copies redact known private values. Review copies are not original raw bytes.', 'files': records}, stream, indent=2)
print(json.dumps({'files': len(records), 'changed_files': sum(x['changed'] for x in records)}))
