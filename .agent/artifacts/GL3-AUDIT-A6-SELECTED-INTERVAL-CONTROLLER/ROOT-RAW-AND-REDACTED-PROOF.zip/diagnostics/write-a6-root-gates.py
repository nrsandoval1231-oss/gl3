import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8', errors='replace')
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'a752049343f4ffff1e153426893c9b23902daccc'
log = root / '.artifacts/root-a6-repaired-final-full.log'
summary = read(log)
matches = re.findall(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', summary)
assert matches and not re.search(r'^FAILED |^ERROR ', summary, re.M), 'Full backend gate has not passed'
passed, skipped, warnings, seconds = matches[-1]
output = root / '.agent/artifacts/GL3-AUDIT-A6-REPAIRED-CONTROLLER'
manifest = json.loads((output / 'TESTED-SOURCE-MANIFEST.json').read_text())
assert manifest['tested_head'] == head
for entry in manifest['entries']:
    assert hashlib.sha256((root / entry['path']).read_bytes()).hexdigest() == entry['working_sha256']
receipt = {'status': 'DETERMINISTIC_GATES_PASS_PENDING_INDEPENDENT_REVIEW', 'parent_complete': False, 'tested_head': head, 'utc_recorded': datetime.now(timezone.utc).isoformat(), 'backend': {'passed': int(passed), 'skipped': int(skipped), 'warnings': int(warnings), 'seconds': float(seconds)}, 'browser': {'passed': 62, 'seconds': 44.4, 'source_anchor': '0b81c2de358213d7d5760aebc8faa3f659924c34', 'subsequent_changed_input': manifest['changed_inputs']}, 'source_inputs': len(manifest['entries']), 'independent_review': 'PENDING', 'deployment': False, 'tokens': 'UNKNOWN', 'config_identity': 'UNKNOWN', 'limitations': ['Browser original failed trace remains private, separate redacted copy included', 'Historical tool output bytes not retained remain UNKNOWN', 'Python allocation metrics are not RSS or production SLO', 'Mypy checks 80 source files, not entire test tree', 'Actual feed, quality, seven-day, customer and protected canonical UI gates remain OPEN']}
with (output / 'COMPLETION.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
with (output / 'GATES.md').open('x') as stream:
    stream.write(f'# A6 backend controller gates\n\nTested candidate `{head}`. Parent OPEN; independent review pending.\n\nFull backend: {passed} passed, {skipped} skipped, {warnings} warnings, {seconds}s. Browser: 62 passed, 44.4s on unchanged product/browser source; subsequent change is one disposable-database test guard. Ruff, mypy (80 source files), web type/build, locked Python and npm dependency audit passed. Exact OpenAPI: 34 paths. Migration 0017 upgrade/repeat/drift passed.\n\nRead-only retained proof: 1167 records, 1149 groups, 17 searches; all 24 public pages. Commercial/public payload hashes remain accepted hashes; 135/125 queries respectively, final short public page132. Original-column fingerprints match post-schema baseline across24tables; preserved original dump SHA828BEACE65CD2B06182F30E4713857656A993D3969C8CBECB02E6EE40FF8A886 unchanged. No retained-data or provider writes.\n\nInitial failed gates and diagnosis retained in prior controller artifact. Eight fixture errors corrected with safe disposable DB guard; authentication failures corrected by separating and migrating disposable application database. Private original browser trace retained locally, redacted review copy explicitly attributed. No independent acceptance or deployment claim.\n')
print(json.dumps(receipt))
