import hashlib

import json

import subprocess

import sys

from pathlib import Path



root = Path(__file__).resolve().parents[1]

def git(*args):

    return subprocess.check_output(['git', '-C', str(root), *args])

head = git('rev-parse', 'HEAD').decode().strip()

assert head == sys.argv[1]

assert not git('status', '--porcelain').strip()

old = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-TIMING-R1-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())

old_by_path = {x['path']: x for x in old['entries']}

paths = set(old_by_path) | set(git('ls-files', 'backend/src', 'backend/tests', 'web/src', 'web/tests').decode().splitlines())

packet_paths = ['.agent/packets/GL3-AUDIT-A6-TIMING-PROJECTION-INTEGRATION-REPAIR.md', '.agent/packets/GL3-AUDIT-A6-LOWER-TIER-TIMING-PROJECTION-AMENDMENT.md', '.agent/packets/GL3-AUDIT-A6-COMMERCIAL-EXACT-TARGET-PROOF-AMENDMENT.md']
packet_paths.append('.agent/packets/GL3-AUDIT-A6-SELECTED-INTERVAL-DIRECTION.md')
paths.update(packet_paths)
entries = []

for path in sorted(paths):

    entries.append({'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()})

changed = [x['path'] for x in entries if x['path'] not in old_by_path or x != old_by_path[x['path']]]

allowed = {'backend/src/gridlens/domain/call_facts.py', 'backend/tests/unit/test_call_facts.py', 'backend/tests/integration/test_call_fact_workflow_integration.py'}
allowed.update(packet_paths)
assert set(changed) <= allowed, changed
source_changes = [path for path in changed if path.startswith(('backend/', 'web/'))]

output = root / '.agent/artifacts/GL3-AUDIT-A6-SELECTED-INTERVAL-CONTROLLER'

output.mkdir(exist_ok=False)

with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as stream:

    json.dump({'tested_head': head, 'rejected_head': 'e3c7005fd18e95db25ae5eba1a7490e4406e50b0', 'source_changes': source_changes, 'governing_packet_inputs': packet_paths, 'entries': entries}, stream, indent=2)

print(json.dumps({'tested_head': head, 'entries': len(entries), 'source_changes': source_changes, 'governing_packet_inputs': packet_paths}))

