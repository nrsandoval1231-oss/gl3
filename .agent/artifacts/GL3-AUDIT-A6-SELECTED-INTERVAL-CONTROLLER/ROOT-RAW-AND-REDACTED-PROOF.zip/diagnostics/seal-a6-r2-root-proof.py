"""Seal nonprivate diagnostics; preserve attribution of redacted browser copies."""
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
assert head == sys.argv[1]
output = root / '.agent/artifacts/GL3-AUDIT-A6-R2-CONTROLLER'
inputs = {}
for path in (root / '.artifacts').iterdir():
    if path.is_file() and path.suffix in {'.log', '.py', '.ps1', '.json', '.txt'}:
        inputs['diagnostics/' + path.name] = path
for folder in ('root-a6-controller-before', 'root-a6-r1-controller-before', 'root-a6-r2-controller-before', 'root-a6-redacted-initial-browser-results', 'root-a6-final-browser-migrated-browser-results', 'root-a6-r1-final-browser-results', 'root-a6-r2-final-browser-results'):
    directory = root / '.artifacts' / folder
    assert directory.is_dir(), folder
    extended = Path('\\\\?\\' + str(directory.absolute())) if os.name == 'nt' else directory
    for path in extended.rglob('*'):
        if path.is_file():
            inputs[folder + '/' + str(path.relative_to(extended)).replace('\\', '/')] = path
for folder in ('GL3-AUDIT-A6-CONTROLLER', 'GL3-AUDIT-A6-BACKEND', 'GL3-AUDIT-A6-TEST-DB-GUARD-REPAIR', 'GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR', 'GL3-AUDIT-A6-QUALIFICATION-R1', 'GL3-AUDIT-A6-QUALIFICATION-R2', 'GL3-AUDIT-A6-ADEQUATE-SUPPLY-RECONCILIATION', 'GL3-AUDIT-A6-R1-CONTROLLER', 'GL3-AUDIT-A6-REPAIRED-CONTROLLER'):
    for path in (root / '.agent/artifacts' / folder).rglob('*'):
        if path.is_file():
            inputs['evidence/' + folder + '/' + str(path.relative_to(root / '.agent/artifacts' / folder)).replace('\\', '/')] = path
inputs['tested-source-manifest.json'] = output / 'TESTED-SOURCE-MANIFEST.json'
for name in ('GATES.md', 'COMPLETION.json'):
    inputs['controller/' + name] = output / name
archive_path = output / 'ROOT-RAW-AND-REDACTED-PROOF.zip'
entries = []
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(inputs.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        entries.append({'entry': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive_path) as archive:
    for entry in entries:
        assert hashlib.sha256(archive.read(entry['entry'])).hexdigest() == entry['sha256']
with (output / 'RAW-HASH-MANIFEST.json').open('x') as stream:
    json.dump({'tested_head': head, 'archive': archive_path.name, 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'entries': entries, 'private_exclusions': ['Original failed browser traces contain test password and remain unchanged locally; separately hashed redacted copies included', 'Private corpus dumps and compressed payload oracles and configuration excluded'], 'limitations': ['Unretained tool output remains UNKNOWN', 'No independent acceptance claimed']}, stream, indent=2)
print(json.dumps({'tested_head': head, 'entries': len(entries), 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()}))
