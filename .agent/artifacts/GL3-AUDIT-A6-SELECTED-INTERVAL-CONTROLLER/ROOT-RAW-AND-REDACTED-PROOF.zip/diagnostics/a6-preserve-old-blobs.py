import hashlib, json, subprocess, zipfile
from pathlib import Path
root = Path.cwd()
commits = ["80dbc2f6f5a7a5cc43534ad995501fb63c0c3885", "209caeb1551afa3dbda2650cd8fa64e93f68de2b"]
paths = [
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/CURRENT_STATE.md.before-compact.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/CURRENT_STATE.md.prior.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/WORK_GRAPH.md.before-compact.bin",
    ".agent/artifacts/GL3-AUDIT-A6-DISPATCH/WORK_GRAPH.md.prior.bin",
]
archive = Path(".agent/artifacts/GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR/PRE-REPAIR-GIT-BLOBS.zip")
entries=[]
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for commit in commits:
        for path in paths:
            data = subprocess.check_output(["git", "show", f"{commit}:{path}"])
            entry = f"{commit}/{path}"
            zf.writestr(entry, data)
            entries.append({"commit": commit, "path": path, "zip_entry": entry, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
receipt = {
    "schema": "gl3-a6-archive-preservation/v1",
    "candidate_head_before_repair": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "archive": archive.as_posix(),
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "entries": entries,
    "root_evidence_copies": [],
}
for path in [Path(".artifacts/root-a6-builder-diff-check.log"), Path(".artifacts/root-a6-archive-bin-identity.json")]:
    copy = Path(".agent/artifacts/GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR/ROOT-EVIDENCE") / path.name
    source_bytes, copy_bytes = path.read_bytes(), copy.read_bytes()
    receipt["root_evidence_copies"].append({"source": path.as_posix(), "copy": copy.as_posix(), "source_sha256": hashlib.sha256(source_bytes).hexdigest(), "copy_sha256": hashlib.sha256(copy_bytes).hexdigest(), "bytes": len(source_bytes), "identical": source_bytes == copy_bytes})
Path(".agent/artifacts/GL3-AUDIT-A6-ARCHIVE-BINARY-REPAIR/PRE-REPAIR-PRESERVATION.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
