import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
head = git('rev-parse', 'HEAD').decode().strip()
assert head == sys.argv[1]
assert not git('status', '--porcelain').strip()
old = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-R2-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())
old_by_path = {x['path']: x for x in old['entries']}
paths = set(old_by_path) | set(git('ls-files', 'backend/src', 'backend/tests', 'web/src', 'web/tests').decode().splitlines())
entries = []
for path in sorted(paths):
    entries.append({'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()})
changed = [x['path'] for x in entries if x['path'] not in old_by_path or x != old_by_path[x['path']]]
allowed = {'backend/src/gridlens/domain/call_facts.py', 'backend/src/gridlens/domain/power_qualification.py', 'backend/tests/unit/test_power_qualification.py', 'backend/src/gridlens/domain/commercial_presentation.py', 'backend/src/gridlens/ingestion/service.py', 'backend/src/gridlens/api/app.py', 'backend/tests/unit/test_call_facts.py', 'backend/tests/unit/test_commercial_presentation.py', 'backend/tests/integration/test_call_fact_workflow_integration.py', 'backend/tests/integration/test_ingestion.py'}
assert set(changed) <= allowed, changed
output = root / '.agent/artifacts/GL3-AUDIT-A6-TIMING-CONTROLLER'
output.mkdir(exist_ok=False)
with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as stream:
    json.dump({'tested_head': head, 'rejected_head': 'd99ef3477096baa2519e882b60f4a26deba2316b', 'source_changes': changed, 'entries': entries}, stream, indent=2)
print(json.dumps({'tested_head': head, 'entries': len(entries), 'source_changes': changed}))
