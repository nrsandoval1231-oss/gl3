from datetime import UTC,datetime
from types import SimpleNamespace
from uuid import uuid4
from gridlens.domain.call_facts import _activity_interval,_fact_covers_interval,qualification_from_facts
from gridlens.domain.power_qualification import qualify_official_power
n,p=uuid4(),uuid4(); need=SimpleNamespace(id=n,project_id=p,activity_key='construction'); project=SimpleNamespace(id=p,location='Test City')
def row(t,v): return SimpleNamespace(id=uuid4(),need_id=n,project_id=p,activity_key='construction',facility_scope='Test City',fact_type=t,value=v,content_hash=t,effective_from=datetime(2026,1,1,tzinfo=UTC),effective_until=datetime(2028,1,1,tzinfo=UTC))
facts=[row('demand',{'mw':'20'}),row('unsuitable_supply',{'mw':'2'}),row('timing',{'start_date':'2027-01-01','end_date':'2027-02-01','duration_days':30}),row('suitable_supply',{'mw':'5','quality':'suitable'}),row('buyer',{'organization':'Northstar Electric','role':'electrical contractor'})]
print('int',_activity_interval(facts[2].value)); print('covers',[(f.fact_type,_fact_covers_interval(f,_activity_interval(facts[2].value))) for f in facts]); print(qualification_from_facts({'tier':'Signal','reason':'src'},facts,need=need,project=project))
t=qualify_official_power(text='Test City construction requires 20 MW. Power supply for Test City construction is insufficient.',site='Test City',activity_key='construction',location='Test City'); print(t); ff=[row('timing',{'start_date':'2027-01-01','end_date':'2027-02-01','duration_days':31}),row('suitable_supply',{'mw':'5','quality':'suitable'}),row('buyer',{'organization':'Northstar Electric','role':'electrical contractor'})]; print(qualification_from_facts(t,ff,need=need,project=project))
