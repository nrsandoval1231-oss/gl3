import hashlib

import json

import subprocess

import sys

from pathlib import Path



root = Path(__file__).resolve().parents[1]

def git(*args):

    return subprocess.check_output(['git', '-C', str(root), *args])

head = git('rev-parse', 'HEAD').decode().strip()

assert head == sys.argv[1]

assert not git('status', '--porcelain').strip()

old = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-TIMING-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())

old_by_path = {x['path']: x for x in old['entries']}

paths = set(old_by_path) | set(git('ls-files', 'backend/src', 'backend/tests', 'web/src', 'web/tests').decode().splitlines())

packet_paths = ['.agent/packets/GL3-AUDIT-A6-TIMING-PROJECTION-INTEGRATION-REPAIR.md', '.agent/packets/GL3-AUDIT-A6-LOWER-TIER-TIMING-PROJECTION-AMENDMENT.md']
paths.update(packet_paths)
entries = []

for path in sorted(paths):

    entries.append({'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()})

changed = [x['path'] for x in entries if x['path'] not in old_by_path or x != old_by_path[x['path']]]

allowed = {'backend/src/gridlens/domain/call_facts.py', 'backend/src/gridlens/domain/power_qualification.py', 'backend/tests/unit/test_power_qualification.py', 'backend/src/gridlens/domain/commercial_presentation.py', 'backend/src/gridlens/ingestion/service.py', 'backend/src/gridlens/api/app.py', 'backend/tests/unit/test_call_facts.py', 'backend/tests/unit/test_commercial_presentation.py', 'backend/tests/integration/test_call_fact_workflow_integration.py', 'backend/tests/integration/test_ingestion.py'}

allowed.update(packet_paths)
assert set(changed) <= allowed, changed
source_changes = [path for path in changed if path.startswith(('backend/', 'web/'))]

output = root / '.agent/artifacts/GL3-AUDIT-A6-TIMING-R1-CONTROLLER'

output.mkdir(exist_ok=False)

with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as stream:

    json.dump({'tested_head': head, 'rejected_head': '80a5cf51ea21ddd879b7345c65d36c5717d7e383', 'source_changes': source_changes, 'governing_packet_inputs': packet_paths, 'entries': entries}, stream, indent=2)

print(json.dumps({'tested_head': head, 'entries': len(entries), 'source_changes': source_changes, 'governing_packet_inputs': packet_paths}))

