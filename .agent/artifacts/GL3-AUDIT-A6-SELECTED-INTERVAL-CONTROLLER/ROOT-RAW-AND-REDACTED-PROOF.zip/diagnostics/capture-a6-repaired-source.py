import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
head = git('rev-parse', 'HEAD').decode().strip()
assert head == sys.argv[1]
assert not git('diff', '--name-only').strip()
prior = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())
entries = []
changes = []
for old in prior['entries']:
    path = old['path']
    item = {'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()}
    entries.append(item)
    if item != old:
        changes.append(path)
assert changes == ['backend/tests/integration/test_call_fact_workflow_integration.py'], changes
output = root / '.agent/artifacts/GL3-AUDIT-A6-REPAIRED-CONTROLLER'
output.mkdir(exist_ok=False)
with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as target:
    json.dump({'tested_head': head, 'prior_tested_head': prior['tested_head'], 'changed_inputs': changes, 'entries': entries}, target, indent=2)
print(json.dumps({'tested_head': head, 'source_entries': len(entries), 'changed_inputs': changes}))
