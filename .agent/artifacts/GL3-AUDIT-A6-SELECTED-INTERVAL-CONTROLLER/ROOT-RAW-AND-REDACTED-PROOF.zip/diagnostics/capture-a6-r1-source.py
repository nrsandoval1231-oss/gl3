import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
head = git('rev-parse', 'HEAD').decode().strip()
assert head == sys.argv[1]
assert not git('status', '--porcelain').strip(), 'Freeze requires clean worktree'
old = json.loads((root / '.agent/artifacts/GL3-AUDIT-A6-REPAIRED-CONTROLLER/TESTED-SOURCE-MANIFEST.json').read_text())
paths = [x['path'] for x in old['entries']]
for path in ('docs/product/PRD.md', '.agent/FINISH_CONTRACT.md', 'docs/design/references/canonical-ui-reference.json'):
    if path not in paths:
        paths.append(path)
entries = []
for path in sorted(paths):
    entries.append({'path': path, 'working_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(), 'git_content_sha256': hashlib.sha256(git('show', f'HEAD:{path}')).hexdigest(), 'git_blob_oid': git('rev-parse', f'HEAD:{path}').decode().strip()})
old_by_path = {x['path']: x for x in old['entries']}
changed = [x['path'] for x in entries if x['path'] in old_by_path and x != old_by_path[x['path']]]
allowed = {'backend/src/gridlens/domain/call_facts.py', 'backend/tests/unit/test_call_facts.py', 'backend/tests/integration/test_call_fact_workflow_integration.py', 'backend/src/gridlens/ingestion/service.py'}
assert set(changed) <= allowed, changed
output = root / '.agent/artifacts/GL3-AUDIT-A6-R1-CONTROLLER'
output.mkdir(exist_ok=False)
with (output / 'TESTED-SOURCE-MANIFEST.json').open('x') as stream:
    json.dump({'tested_head': head, 'rejected_head': 'c3c60dfedcc68d5b33594363a334989b42e8e57f', 'source_changes': changed, 'added_governing_inputs': sorted(set(paths) - set(old_by_path)), 'entries': entries}, stream, indent=2)
print(json.dumps({'tested_head': head, 'entries': len(entries), 'source_changes': changed}))
