param(
 [Parameter(Mandatory=$true)][string[]]$ToolArguments,
 [Parameter(Mandatory=$true)][ValidatePattern('^[a-zA-Z0-9_-]+$')][string]$Label
)
$ErrorActionPreference='Stop'
$providerNames=@('FIRECRAWL_API_KEY','OPENAI_API_KEY','TYPESAFE_API_KEY')
foreach($providerName in $providerNames){[Environment]::SetEnvironmentVariable($providerName,'','Process')}
$env:WORKER_AUTO_REFRESH='false'; $env:AUTONOMOUS_RESEARCH_ENABLED='false'
$env:SESSION_SECRET='gl3-a6-synthetic-nonproduction-test-session-secret'
$env:APP_PASSWORD_HASH='$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxNQSZBlN/1VGziLI9YCVWVBzJu'
$env:DATABASE_URL='postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_migration'
$env:TEST_DATABASE_URL='postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_final_test'
$env:MIGRATION_TEST_DATABASE_URL='postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_migration'
$env:TRUSTED_ORIGINS='http://127.0.0.1:5173'; $env:COOKIE_SECURE='false'
foreach($providerName in $providerNames){if(-not [string]::IsNullOrEmpty([Environment]::GetEnvironmentVariable($providerName,'Process'))){throw 'Provider environment preflight failed; values are never emitted'}}
$candidateRoot=Split-Path $PSScriptRoot -Parent
if(Test-Path -LiteralPath (Join-Path $candidateRoot '.env')){throw 'Focused wrapper requires no candidate .env; synthetic credentials only'}
$env:PYTHONPATH=Join-Path $candidateRoot 'backend/src'
$utcStamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')
$taskLog=Join-Path $PSScriptRoot "$Label-$utcStamp-$([Guid]::NewGuid().ToString('N'))-pytest.log"
New-Item -ItemType File -Path $taskLog -ErrorAction Stop | Out-Null
Set-Location (Join-Path $candidateRoot 'backend')
& 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' run --locked --extra dev pytest @ToolArguments *> $taskLog
$taskExit=$LASTEXITCODE
Write-Output "Provider preflight passed; synthetic test authentication; exit=$taskExit; log=$taskLog"
Get-Content -LiteralPath $taskLog -Tail 24
exit $taskExit
