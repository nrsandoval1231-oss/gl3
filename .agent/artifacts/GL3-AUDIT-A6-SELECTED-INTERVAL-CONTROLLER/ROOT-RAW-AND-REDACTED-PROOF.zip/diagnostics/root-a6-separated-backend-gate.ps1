param([Parameter(Mandatory=$true)][string]$Candidate,[Parameter(Mandatory=$true)][string]$Label,[Parameter(Mandatory=$true)][string]$TestDatabase,[Parameter(Mandatory=$true)][string]$MigrationDatabase,[Parameter(Mandatory=$true)][string]$Gate)
$ErrorActionPreference='Stop'
$env:DATABASE_URL="postgresql+psycopg://gl3audit@127.0.0.1:55437/gl3audit_a6_final_application"
$env:TEST_DATABASE_URL="postgresql+psycopg://gl3audit@127.0.0.1:55437/$TestDatabase"
$env:MIGRATION_TEST_DATABASE_URL="postgresql+psycopg://gl3audit@127.0.0.1:55437/$MigrationDatabase"
$env:FIRECRAWL_API_KEY='';$env:OPENAI_API_KEY='';$env:TYPESAFE_API_KEY=''
$env:WORKER_AUTO_REFRESH='false';$env:AUTONOMOUS_RESEARCH_ENABLED='false'
$env:TRUSTED_ORIGINS='http://127.0.0.1:5173'
Get-Content 'C:/Users/nrsan/Nucleus/02_Projects/GridLens/gl3-audit-repair-20261007/.env' | ForEach-Object { if($_ -match '^(APP_PASSWORD_HASH|SESSION_SECRET)=(.*)$'){[Environment]::SetEnvironmentVariable($Matches[1],$Matches[2],'Process')} }
$taskLog=Join-Path $Candidate ".artifacts/$Label-$Gate.log"
if(Test-Path -LiteralPath $taskLog){throw 'Refusing overwrite'}
Set-Location (Join-Path $Candidate 'backend')
switch($Gate){
 'full' { & 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' run --locked --extra dev pytest -q -rs *> $taskLog }
 'ruff' { & 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' run --locked --extra dev ruff check src tests ../scripts *> $taskLog }
 'mypy' { & 'C:/Users/nrsan/AppData/Local/hermes/bin/uv.exe' run --locked --extra dev mypy src *> $taskLog }
 default {throw 'Unknown gate'}
}
$taskExit=$LASTEXITCODE
Get-Content -LiteralPath $taskLog -Tail 14
exit $taskExit



