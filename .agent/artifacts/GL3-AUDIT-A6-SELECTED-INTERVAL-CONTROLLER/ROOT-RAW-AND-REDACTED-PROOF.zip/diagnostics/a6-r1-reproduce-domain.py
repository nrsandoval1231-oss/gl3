from datetime import UTC, datetime
from decimal import Decimal
from types import SimpleNamespace
from uuid import uuid4
from gridlens.domain.call_facts import qualification_from_facts

need_id, project_id = uuid4(), uuid4()
need = SimpleNamespace(id=need_id, project_id=project_id, activity_key='construction')
project = SimpleNamespace(id=project_id, location='Test City')

def row(fact_type, value, until='2028-01-01T00:00:00+00:00'):
    return SimpleNamespace(id=uuid4(), need_id=need_id, project_id=project_id,
        activity_key='construction', facility_scope='Test City', fact_type=fact_type,
        value=value, content_hash=fact_type, effective_from=datetime(2026, 1, 1, tzinfo=UTC),
        effective_until=datetime.fromisoformat(until))

facts = [row('demand', {'mw':'20'}), row('unsuitable_supply', {'mw':'1'}),
    row('timing', {'start_date':'2027-01-01','end_date':'2027-02-01','duration_days':31}),
    row('suitable_supply', {'mw':'5','quality':'suitable'}),
    row('buyer', {'organization':'Northstar Electric','role':'electrical contractor'})]
prospect = {'tier':'Prospect','demand_mw':'20 MW','supply_quote':'Power supply for Test City construction is insufficient.', 'reason':'Current official scope'}
print('prospect reproduction:', qualification_from_facts(prospect, facts, need=need, project=project))
interval_facts = [row(x.fact_type, x.value, '2026-10-09T00:00:00+00:00') if x.fact_type == 'suitable_supply' else x for x in facts]
print('interval reproduction:', qualification_from_facts({'tier':'Signal','reason':'Admitted exact site source'}, interval_facts, need=need, project=project))
