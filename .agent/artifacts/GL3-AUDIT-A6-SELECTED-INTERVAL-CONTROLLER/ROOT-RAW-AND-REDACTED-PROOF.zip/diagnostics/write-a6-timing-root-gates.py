import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8', errors='replace')
output = root / '.agent/artifacts/GL3-AUDIT-A6-TIMING-CONTROLLER'
manifest = json.loads((output / 'TESTED-SOURCE-MANIFEST.json').read_text())
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
assert manifest['tested_head'] == head
backend = read(root / '.artifacts/root-a6-timing-final-full.log')
matches = re.findall(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', backend)
assert matches and not re.search(r'^FAILED |^ERROR ', backend, re.M)
passed, skipped, warnings, seconds = matches[-1]
browser = read(root / '.artifacts/root-a6-timing-final-browser.log')
browser_matches = re.findall(r'(\d+) passed \(([\d.]+)s\)', browser)
assert browser_matches and not re.search(r'\d+ failed', browser)
for entry in manifest['entries']:
    assert hashlib.sha256((root / entry['path']).read_bytes()).hexdigest() == entry['working_sha256']
receipt = {'status': 'DETERMINISTIC_GATES_PASS_PENDING_INDEPENDENT_REVIEW', 'parent_complete': False, 'tested_head': head, 'utc_recorded': datetime.now(timezone.utc).isoformat(), 'backend': {'passed': int(passed), 'skipped': int(skipped), 'warnings': int(warnings), 'seconds': float(seconds)}, 'browser': {'passed': int(browser_matches[-1][0]), 'seconds': float(browser_matches[-1][1])}, 'source_inputs': len(manifest['entries']), 'source_changes': manifest['source_changes'], 'prior_independent_verdict': 'FIX', 'new_independent_review': 'PENDING', 'deployment': False, 'tokens': 'UNKNOWN', 'config_identity': 'UNKNOWN', 'limitations': ['No real customer Lead or production SLO claim', 'Protected canonical UI originals and authentic feed/quality/seven-day gates remain OPEN', 'Known-private original failed browser trace remains private; separately attributed redacted copy retained']}
with (output / 'COMPLETION.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
with (output / 'GATES.md').open('x') as stream:
    stream.write(f'# A6 timing controller gates\n\nTested `{head}`. Backend{passed}passed/{skipped}skipped/{warnings}warnings/{seconds}s; browser{browser_matches[-1][0]}passed/{browser_matches[-1][1]}s. Source manifest binds {len(manifest["entries"])} exact working/Git inputs, including actual canonical PRD/finish/protected reference manifest.\n\nBoth rejected-source qualification repros and raw independent FIX remain preserved. Current timing compatibility, explicit correction and full-window mechanics require fresh independent review despite green gates. Other mandatory static/migration/OpenAPI/dependency/retained semantic/page/payload/fingerprint receipts are included in the root archive. No independent acceptance or parent completion claim.\n')
print(json.dumps(receipt))
