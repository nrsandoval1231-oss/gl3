import json,sys,time
from pathlib import Path
import pytest
root=Path('/workspace/gl3-handoff-research')
name=sys.argv[1]
ids=json.loads((root/f'{name}-selection.json').read_text())
class Receipt:
    def pytest_runtest_logreport(self,report):
        with (root/f'{name}-reports.jsonl').open('a') as f:
            f.write(json.dumps({'nodeid':report.nodeid,'when':report.when,'outcome':report.outcome,'duration':report.duration,'timestamp':time.time(),'pid':__import__('os').getpid(),'report_type':type(report).__name__})+'\n')
    def pytest_sessionfinish(self,session,exitstatus):
        (root/f'{name}-exit.json').write_text(json.dumps({'exitstatus':int(exitstatus),'collected':session.testscollected,'failed':session.testsfailed,'finished_at':time.time()}))
if __name__ == '__main__':
    raise SystemExit(pytest.main([*ids,'-q','--tb=short'],plugins=[Receipt()]))
